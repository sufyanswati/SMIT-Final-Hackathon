# Ladoo HCM Lite

Professional role-based HRMS (Admin / HR / Employee): organization setup, employee lifecycle, attendance and GPS geofencing, corrections, leave approvals, payroll drafts/finalization and PDF payslips, operational dashboards, notifications, announcements, audit log, explainable anomaly/attrition signals, Roman Urdu UI support, PWA shell and an optional AI assistant.
Stack: React + Vite + recharts (client), Express + Mongoose (server), MongoDB, JWT.

> **Status:** see `HANDOFF.md` and `docs/project-status.md` for what has and has not been verified. At the time of writing the Vite build, the API integration tests and any browser test had **not** been run (no network in the authoring environment).

## Requirements
Node 20+, a MongoDB instance (local or Atlas).

## Run locally
```bash
cd server && cp .env.example .env     # set MONGODB_URI and JWT_SECRET (32+ random chars)
npm install && npm run dev            # API on :4000
cd ../client && npm install && npm run dev   # UI on :5173 (proxies /api to :4000)
```
Open http://localhost:5173. The first visit shows **Set up Ladoo**, which creates the company and the first Admin (no default password exists). Alternatively set `ADMIN_EMAIL` + `ADMIN_PASSWORD` in `server/.env`.

Typical flow: Admin creates departments/designations (Organization), creates an HR account (Accounts) → HR adds employees (a one-time temporary password is shown; the employee must change it at first login) → employees check in, apply for leave → HR approves → HR drafts payroll → Admin finalizes → employees download payslips.

## Tests
```bash
cd server && npm run test:offline   # core rules + new rules + client/server route contract; no DB (32 tests; passed in the authoring sandbox)
npm run test:api                    # API integration (mongodb-memory-server downloads a MongoDB binary on first run) — never run yet
npm test                            # everything above
cd ../client && npm run test:render # SSR render smoke against fixtures (needs npm install) — ran once in the sandbox with stand-in React/esbuild
```
Full manual walkthrough: `docs/demo-testing-checklist.md`.

## Configuration
Server: `PORT NODE_ENV MONGODB_URI JWT_SECRET JWT_EXPIRES_IN CLIENT_ORIGIN ADMIN_EMAIL ADMIN_PASSWORD ADMIN_NAME COMPANY_NAME AI_BASE_URL AI_API_KEY AI_MODEL`. Client: `VITE_API_URL` (empty in dev).
AI features use any OpenAI-compatible chat-completions endpoint with tool calling; without `AI_API_KEY` they return a clear fallback message and the rest of the app is unaffected. Never commit `.env`.

## Deployment
`render.yaml` (API + static client), `client/vercel.json` / `client/public/_redirects` (SPA rewrites), and `.github/workflows/ci.yml` (offline tests + Vite build) are provided as **not-yet-executed deployment/CI templates**. Set `CLIENT_ORIGIN` on the API to the exact deployed client origin(s) and `VITE_API_URL` on the client to the API origin. Production `JWT_SECRET` must be at least 32 characters. A MongoDB Atlas URI is required. `/health` is liveness; `/ready` checks database readiness. No deployment has been performed.

## Notes
- Tax uses the illustrative slabs from the challenge brief; not tax advice.
- Attendance location check is a GPS geofence. There is **no** face recognition; the `faceCount` API field exists but no client sends it.
- Only an Admin can mark an employee as exited (this also disables their login).

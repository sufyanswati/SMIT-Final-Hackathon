# CONTINUE PROMPT — Ladoo HCM Lite (latest checkpoint)

Continue from this repository and its current code. **Do not restart the project, rewrite it as a toy demo, remove existing modules, or replace live API flows with mock/dummy data.** The target is a substantial, professional, production-style HRMS with premium UI polish and a real backend.

## Product and architecture to preserve
- React 18 + Vite client; Express 4 + Mongoose 8 + MongoDB server; JWT authentication and strict role-based access for Admin, HR, and Employee.
- Real workflows: first-run setup, password change, organization settings, departments/designations, employees and lifecycle, CSV import/export, attendance/geofence/corrections, leave and approvals, payroll draft/finalize/PDF payslips, dashboards/charts, announcements, notifications, audit log, AI assistant, anomaly flags, explainable attrition-risk signals, Roman Urdu navigation/common strings, camera face-count helper and PWA shell.
- Preserve the Ladoo brand and sticky/translucent navbar with multicolour scroll-progress ribbon. A real reference screenshot and official Saylani brief have not been available; do not pretend visual comparison was done.
- No Firebase integration was agreed. Do not switch auth/database architecture without an explicit requirement.
- Never claim face recognition or AI attrition prediction. Face UI is a helper only; attrition score is heuristic/explainable.

## Current checkpoint: updated from uploaded `lado-11(1).zip`
Read `HANDOFF.md`, `docs/project-status.md`, `docs/requirements-checklist.md`, `docs/assumptions-and-ambiguities.md`, and `docs/demo-testing-checklist.md` before coding.

This checkpoint includes a premium global UI-system redesign, corrected offline test script, production env checks, separate `/health` and DB-aware `/ready` endpoints, safer index initialization, graceful shutdown, GitHub Actions CI workflow, and a readiness integration test.

## Verified in the authoring environment
- `cd server && npm run test:offline`: **37/37 passed**.
- `node --check` on `server/src/app.js`, `server/src/config/env.js`, and `server/src/server.js`: passed.
- TypeScript transpile parser check for all 23 client JS/JSX source files: zero syntax errors.
- `npm install` for the client timed out. Consequently, Vite build, API integration tests, actual database workflows, GitHub Actions execution, live deployment and full browser E2E are **not verified**.

## Required next steps — work in this order
1. On an internet-connected Node 20+ environment, run `cd server && npm install && npm run test:offline && npm run test:api`. Fix every real failure; do not merely report it.
2. Run `cd client && npm install && npm run build`. Fix all Vite/Rollup/import errors.
3. Run the app with a real MongoDB database and walk through `docs/demo-testing-checklist.md` for all three roles. Check mobile widths, errors/loading/empty states, every create/edit/approve/finalize flow, security boundaries, PDFs and CSV.
4. Review the correction approval workflow for atomicity and add real integration tests for all security-sensitive rules and insights/late penalty.
5. Provision MongoDB Atlas, push the code to GitHub, run `.github/workflows/ci.yml`, deploy API and static client, configure production secrets/origins, and verify `/health` and `/ready` live.
6. Keep the UI professional and dense-but-readable; prefer real workflow improvements over decorative screens. Never seed dummy business data in a fresh install.
7. If the official brief and true `page 1.png`/navbar screenshot are provided, inspect them and reconcile requirements and visuals.

## When stopping
Update `HANDOFF.md`, `docs/project-status.md`, and this file with exact tests actually run, exact blockers and next steps. Create a fresh ZIP excluding `node_modules`, `.env`, `.git`, and build output; test archive integrity before sharing. Do not say the app is live unless it has actually been deployed and smoke-tested.

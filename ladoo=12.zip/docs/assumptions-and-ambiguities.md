# Assumptions and ambiguities
1. **PDF and sketch were not available.** Anything not restated in the master prompt is unverified. Re-check against the PDF's 25-functionality checklist when it is available.
2. **Tax:** marginal interpretation (fixed amount = tax at previous bracket top). Annualized gross = earned monthly gross × 12; monthly tax = annual tax ÷ 12; computed before absence deductions. Labeled illustrative. Boundary values tested.
3. **Per-day rate** = full monthly gross ÷ working days in the month; joiners/leavers: earned gross = gross × employedDays ÷ monthWorkingDays; absences counted only inside the employment period.
4. **Status precedence:** missing_checkout (day closed, no check-out) > half_day (<5h) > late > present. Open session today is not "missing_checkout".
5. Missing-checkout days are not deducted in payroll (brief gives no rule).
6. Check-in on weekends/holidays is allowed (record kept, day status stays weekend/holiday); check-in on approved-leave day is rejected (422).
7. Zero denominators in analytics return 0. Leave utilization counts whole approved requests overlapping the range (not clipped to it); unpaid quota excluded.
8. Leave spanning two calendar years must be split; pending leave reserves balance; rejection requires a comment.
9. Timezone: company setting, default Asia/Karachi; server clock only. Business dates are `YYYY-MM-DD` strings.
10. Payroll finalization uses an atomic conditional update (`status:'draft'`), not multi-document transactions (works without a replica set).
11. HR (not Admin) creates drafts and decides leave/corrections, per the permission list.
12. No file uploads exist, so no cloud storage was configured; payslip PDFs are generated on demand.
13. **UI sketch unknown:** flame shape/size, exact navbar layout, and timings are my interpretation of the prompt text (flames 1.4s each, Ladoo 2s).
14. **Exit/reinstate (session 4):** only Admin may exit an employee, set an exit date, or reinstate; exit always disables the login, reinstating re-enables it and clears the exit date. HR edits everything else.
15. **Location (session 4):** if location is not required and the office coordinates are not configured, a supplied location is ignored. If the office is set and a location is sent (or location is required), the geofence/accuracy rules apply.
16. **Report ranges** are limited to 400 days; invalid dates/department ids return 400.
17. Leave cannot start before the employee's joining date; exited employees cannot apply.
18. 'Welcome' speech plays once per browser session (not once per reload).

## Session 6 rules (documented, adjustable)
- **Late-arrival penalty** (`server/src/core/insights.js::latePenaltyDays`): OPT-IN (`settings.latePenalty.enabled`, default false so no policy is imposed silently). Defaults when enabled: first 3 late days/month free; every full block of 3 further late days deducts 0.5 day's pay (added to `deductionDays`, shown on the payslip). Changeable via PUT /settings (admin). No UI field for it yet.
- **Anomaly flags**: 3 consecutive late days; 3+ missing check-outs; 3+ absences adjacent to a weekend/holiday; 3 absences inside any 7-day window; 3+ short days (<5h). Window = last 90 days (GET /insights/employees, admin+HR).
- **Per-employee attrition RISK** is a transparent heuristic score (0-100: absenteeism ≤30, lateness ≤20, anomalies ≤20, tenure <1y 15, pay <80% of dept average 15), NOT a trained model, and distinct from the company attrition RATE on the Admin dashboard. Under 5 working days of data => score 0, `enoughData:false`.
- **Camera**: browser-native face DETECTION (count of faces via `window.FaceDetector`, Chromium only). It is not face recognition; it does not identify anyone. Server rejects faceCount ≠ 1 when sent.
- **Roman Urdu**: navigation, intro, sign-out and a few action labels only (`client/src/lib/i18n.js`); most page text is still English.

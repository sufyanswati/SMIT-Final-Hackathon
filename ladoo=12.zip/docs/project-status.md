# Project status — Ladoo HCM Lite (current uploaded checkpoint, updated 2026-10-25)

## Product direction
This is intended to be a substantial, role-based HRMS rather than a static demo. Keep the existing React/Vite + Express/Mongoose + MongoDB + JWT architecture and real workflows; do not replace it with dummy-data screens or restart the project. Preserve Admin, HR, and Employee role boundaries.

## Current source scope
- Auth/setup/password change, JWT sessions, role guards and account management.
- Organization settings, departments, designations, holidays and leave policies.
- Employee directory, registration/editing, exit/reinstate, CSV import dry-run/commit and export.
- Attendance, optional GPS/geofence proof, daily board, summaries and correction workflow.
- Leave requests, balances, approvals and optional AI-assisted prefill.
- Payroll drafts/finalization lock, deductions and PDF payslips.
- Admin/HR/employee dashboards, notifications, announcements, audit logs and AI assistant.
- Rule-based attendance anomaly/attrition signals, Roman Urdu navigation/common strings, camera face-count UI, and PWA shell.

## Work performed in this checkpoint
- Reworked the application-wide visual system: premium typography, refined orange/neutral palette, stronger hierarchy, dense operational tables, metric cards, input/button states, responsive grids, mobile navigation and reduced-motion handling. Existing semantic classes and workflows were retained.
- Fixed duplicate execution of `tests/insights.test.js` in `server/package.json`'s offline test command.
- Added `/ready` readiness endpoint which reports MongoDB connectivity separately from `/health` liveness.
- Tightened production JWT secret minimum to 32 characters and requires explicit production `CLIENT_ORIGIN` values (no wildcard origins).
- Changed startup index initialization from `syncIndexes()` (which may drop schema-absent indexes) to `createIndexes()` (creates missing schema indexes without automatic drops).
- Added graceful SIGTERM/SIGINT shutdown for the API process.
- Added a GitHub Actions workflow for server offline tests and client Vite build, plus a readiness integration test.
- Refreshed this status file and README to separate tested facts from unverified deployment steps.

## Verified in this environment
| Check | Result | Scope |
|---|---|---|
| ZIP integrity | PASS | `unzip -t` on uploaded `lado-11(1).zip` before changes; output archive integrity also checked after packaging |
| Server offline tests | PASS: 37/37 | Pure business rules, source-level client/server route contract, insights and rule/security checks |
| `node --check` server files changed | PASS | `app.js`, `config/env.js`, `server.js` |
| Client JSX/JS syntax | To be rechecked before packaging | Syntax-only; not equivalent to Vite build |
| Client `npm install` | BLOCKED/TIMEOUT | Dependency install did not finish in this environment |
| Vite production build | NOT RUN | Dependencies unavailable because install timed out |
| MongoDB API integration suite | NOT RUN | Requires dependencies and MongoDB memory-server binary |
| GitHub Actions run | NOT RUN | Workflow added but not pushed/executed here |
| Browser end-to-end test | NOT RUN in this checkpoint | Requires dependencies/browser runtime |
| Live deployment | NOT DONE | Requires user-controlled GitHub/hosting/MongoDB accounts and production environment variables |

## Important limits / gaps
- `page 1.png` and the official Saylani brief PDF have not been available to this workspace. The navbar's sticky/glass/multicolour scroll line follows the written description, not a visual comparison.
- Do not claim face recognition: the camera UI is a face-count/proof helper, not biometric identity verification.
- Heuristic attrition risk is an explainable signal only, not a prediction or HR decision.
- Tax slabs are illustrative challenge logic, not tax advice.
- The CI workflow will only prove the Vite build when it is actually run in GitHub Actions.
- Before production use, run integration tests, browser workflows, review security settings, configure backups/monitoring, and validate payroll calculations with the organization.

## Next critical steps
1. Run `cd server && npm install && npm run test:offline && npm run test:api` on a machine with internet.
2. Run `cd client && npm install && npm run build` and fix any build errors.
3. Test all roles in a real browser using `docs/demo-testing-checklist.md`.
4. Provision MongoDB Atlas, push the repository to GitHub, deploy API/static client, set secrets and origins, and test `/health` + `/ready` against the live deployment.
5. Compare against the actual official brief and UI reference image when supplied.

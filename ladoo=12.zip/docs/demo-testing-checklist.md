# Demo & testing checklist (UNEXECUTED — nobody has run this yet)

Prerequisites: server and client running (see README), empty MongoDB. Tick each item as you verify it; note failures in HANDOFF.md.

## 0. Automated first
- [ ] `cd server && npm run test:offline` → 32 pass
- [ ] `npm run test:api` → all pass (fix failures first)
- [ ] `cd ../client && npm run build` succeeds; `npm run test:render` passes

## 1. First run & auth
- [ ] Fresh DB shows intro animation once, then **Set up Ladoo**; no default credentials exist
- [ ] Create company + Admin; lands on Admin dashboard (empty states, no dummy data)
- [ ] Reload: still signed in; Sign out → Login; wrong password shows an error and does NOT sign out an already-signed-in user (change-password with wrong current password shows an error, stays signed in)
- [ ] Setup screen no longer appears; `POST /api/setup` again → 409
- [ ] "Welcome" is spoken once per browser session, "Ladoo" once during intro; Skip and Sound toggle work; Replay intro works

## 2. Admin
- [ ] Organization: add departments + designations; delete one that is in use → blocked
- [ ] Settings: change office start/grace/weekends, add a holiday, edit leave quotas; save; reload keeps values
- [ ] Set office lat/lng + radius; tick "Require location"; saving without lat/lng is refused
- [ ] Accounts: create an HR account → temporary password shown once; deactivate/activate/reset
- [ ] Audit log lists actions with before/after details; Admin cannot approve leave/corrections (read-only message)

## 3. HR
- [ ] Sign in with the temp password → forced to change it; no other page/links reachable until changed
- [ ] Add employee (temp password shown once); duplicate code/email → clear error
- [ ] CSV import: dry run shows row errors; invalid file imports nothing; valid file shows temp passwords once
- [ ] Export CSV opens in a spreadsheet; a name starting with `=` appears as text
- [ ] Edit employee salary; try to mark Exited as HR → option disabled/403. (API: `PUT /employees/:id {exitDate:...}` as HR → 403)
- [ ] As Admin: mark Exited → login disabled, exit date set; reinstate → login re-enabled, exit date cleared
- [ ] Announcement posted → visible to employees

## 4. Employee: attendance
- [ ] First login forces password change
- [ ] Check in (location off): status Present before 09:15, Late after; second check-in → error
- [ ] Check out; hours show; check-out stays possible on weekend/holiday if you checked in
- [ ] With "Require location": allow GPS inside radius → OK; deny permission → clear message; outside radius → rejected with correction hint
- [ ] Request correction → HR sees it, approves/rejects; employee gets a notification; record updates
- [ ] Past month view; "future" days hidden

## 5. Leave
- [ ] Balances correct; apply leave over a weekend/holiday counts working days only
- [ ] Overlap, over-balance, cross-year, start-before-joining-date → each refused with a clear message
- [ ] Smart leave box (needs AI key): fills the form, submits nothing; works without key → friendly error
- [ ] HR approves (comment optional) / rejects (comment required); employee notified; balance updates; cancel works rules (approved + started → refused)

## 6. Payroll
- [ ] HR drafts a past month; figures: gross = 1.5 × basic, deductions for absent/unpaid/half-days, tax per slab
- [ ] Re-drafting refreshes; Admin finalizes → locked; re-draft/finalize again refused
- [ ] Employee sees payslip only after finalization; PDF downloads and opens; cannot fetch another employee's

## 7. Dashboards & AI
- [ ] Admin/HR charts render with and without data; filters (dates, department) work; absurd ranges (>400 days) show an error
- [ ] AI chat (needs key): employee asks colleague's salary → refused; HR asks late-comers → answer from data; no key → fallback message, app unaffected
- [ ] AI summary labelled "AI-generated"

## 8. Security spot checks (curl/Postman)
- [ ] `GET /api/employees?status[$ne]=x` → 400
- [ ] Employee token on `/api/employees`, `/api/audit-logs`, `/api/payroll` → 403
- [ ] Deactivated user's old token → 401
- [ ] `PUT /api/employees/me {basicSalary: 1}` → 400

## 9. Responsive / accessibility
- [ ] Mobile width: hamburger menu, tables scroll, chat panel usable
- [ ] Dark mode (OS setting) readable; reduced-motion skips flame animation
- [ ] Keyboard-only: skip intro, open nav, submit forms

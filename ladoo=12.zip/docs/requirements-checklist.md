# Requirements checklist — current source inventory

The official assignment PDF and the visual reference screenshot have not been available in this workspace. This checklist reflects the current project source and the written requirements retained in prior handoffs; it is not a claim of full runtime verification.

## Core product modules
| Module | Source implementation | Offline tests | Live/runtime verification |
|---|---|---|---|
| M1 Auth & access | First-run setup, login, JWT, forced password change, role/ownership checks, user activation/reset | Some pure rules/static route contract | API integration not run in this environment |
| M2 Organization | Company settings, departments, designations, holidays, leave types, geofence settings, late policy schema/UI | Static contract/core rules only | MongoDB workflow not run |
| M3 Employees | Directory, employee creation/edit, lifecycle exit/reinstate, CSV dry-run/import/export | Exit rules, query guard and CSV rules tested | DB/browser workflow not run |
| M4 Attendance | Check-in/out, timezone-aware daily status, GPS/geofence proof, correction requests/decisions, summaries/board, camera face-count helper | Geo/date/rules tested; route contract tested | DB and camera/browser workflows not run; no biometric identity recognition |
| M5 Leave | Requests, overlap/balance validation, approvals/cancellation, balances, optional AI prefill | Core leave rules tested | DB and AI-provider workflows not run |
| M6 Payroll | Drafts, calculation, late penalty days, finalization lock, payslip PDF | Payroll/tax/late-penalty rules tested | PDF/database workflow not run in this environment |
| M7 Dashboards | Admin/HR/employee dashboards and charts; attendance anomalies and explainable attrition-risk heuristics | Analytics/insight rules tested | Live data/browser rendering not verified |
| M8 AI | Optional chat/tools and AI-assisted leave prefill with fallback | Pure rule tests do not verify provider calls | Needs API key and live provider test |
| M9 Communication/governance | Announcements, notifications, audit logs | Static route contract only | DB/browser workflow not run |

## Cross-cutting UI and delivery
| Area | Current state | Verification |
|---|---|---|
| Login/setup/password-change design | Implemented | Prior handoff reports browser checks against simulated API; not re-run in current pass |
| Shared premium UI system | Updated this checkpoint: typography, cards, tables, forms, alerts, responsive layouts, reduced motion | Client JS/JSX syntax check passed; Vite build not run |
| Sticky/glass navbar + multicolour scroll ribbon | Implemented from written description | Reference screenshot absent, so not compared visually |
| Roman Urdu toggle | Implemented for navigation/common labels; body translations are partial | Browser test not run in this checkpoint |
| PWA shell | Manifest, SVG icon, service worker; API calls excluded from cache | Production/browser install test not run |
| Offline server tests | 37 tests | 37/37 passed in current environment |
| Client source syntax | 27 JS/JSX source/test files | TypeScript transpile check: zero syntax errors |
| Vite build | Not verified | Dependency install timed out |
| MongoDB/API integration | Not verified | Requires dependencies and MongoDB memory-server binary |
| CI | Workflow added | GitHub Actions has not run yet |
| Production deployment | Templates and instructions exist | Not deployed; requires Atlas, hosting, secrets and smoke tests |

## Important limits
- Do not claim all modules are production-ready until API integration, Vite build, browser workflows, security review, and live deployment smoke tests pass.
- Fresh installation must start empty and use first-run setup; do not add dummy company/employee records.
- Attrition score is heuristic and explainable, not a prediction. Camera helper is not face recognition.
- Tax calculation follows illustrative challenge rules and is not tax advice.

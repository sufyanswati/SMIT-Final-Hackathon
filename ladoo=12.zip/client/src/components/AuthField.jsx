import { useState } from 'react';
import { MailIcon, LockIcon, UserIcon, BuildingIcon, EyeIcon, EyeOffIcon } from './icons.jsx';

const ICONS = { mail: MailIcon, lock: LockIcon, user: UserIcon, building: BuildingIcon };

// Floating-label input with a leading icon and (for passwords) a show/hide toggle.
// Themed through CSS variables, so it works on the glass auth card and on normal app cards.
export default function AuthField({ id, label, icon, type = 'text', hint, value, onChange, ...rest }) {
  const [show, setShow] = useState(false);
  const Icon = ICONS[icon];
  const isPw = type === 'password';
  const hintId = hint ? `${id}-hint` : undefined;
  return (
    <div className="af-wrap">
      <div className="af">
        {Icon && <span className="af__icon"><Icon /></span>}
        <input id={id} className={`af__input${Icon ? ' af__input--icon' : ''}`} type={isPw && show ? 'text' : type} value={value} onChange={onChange} placeholder=" " aria-describedby={hintId} {...rest} />
        <label htmlFor={id} className={`af__label${Icon ? ' af__label--icon' : ''}`}>{label}</label>
        {isPw && (
          <button type="button" className="af__toggle" aria-label={show ? 'Hide password' : 'Show password'} aria-pressed={show} onClick={() => setShow((s) => !s)}>
            {show ? <EyeOffIcon /> : <EyeIcon />}
          </button>
        )}
      </div>
      {hint && <small id={hintId} className="af__hint">{hint}</small>}
    </div>
  );
}

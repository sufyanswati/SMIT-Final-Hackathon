import { useState, useRef, useEffect } from 'react';
import { api } from '../lib/api.js';
import { AiLabel } from './ui.jsx';

export default function ChatPanel() {
  const [open, setOpen] = useState(false);
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }); }, [msgs, open]);

  const send = async (e) => {
    e.preventDefault(); const message = text.trim(); if (!message || busy) return;
    setText(''); setMsgs((m) => [...m, { role: 'user', text: message }]); setBusy(true);
    try { const r = await api('/ai/chat', { method: 'POST', body: { message } }); setMsgs((m) => [...m, { role: 'ai', text: r.answer, ai: r.aiGenerated, fallback: r.fallback }]); }
    catch (err) { setMsgs((m) => [...m, { role: 'ai', text: err.message, error: true }]); }
    finally { setBusy(false); }
  };

  return (
    <>
      <button className="chat-fab" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="chat-panel">💬 Ask Ladoo AI</button>
      {open && <aside id="chat-panel" className="chat" aria-label="AI assistant">
        <header className="chat__head"><strong>AI assistant</strong><button className="icon-btn" onClick={() => setOpen(false)} aria-label="Close assistant">✕</button></header>
        <div className="chat__body" aria-live="polite">
          {!msgs.length && <p className="muted small">Ask about your leave balance, attendance, or company policy. Answers use only data you are allowed to see.</p>}
          {msgs.map((m, i) => <div key={i} className={`chat__msg chat__msg--${m.role} ${m.error ? 'is-error' : ''}`}>{m.text}{m.ai && <div><AiLabel /></div>}{m.fallback && <div className="muted small">Fallback response</div>}</div>)}
          {busy && <div className="chat__msg chat__msg--ai muted"><span className="spinner" /> Thinking…</div>}
          <div ref={end} />
        </div>
        <form className="chat__form" onSubmit={send}><input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a question…" aria-label="Your question" maxLength={1000} /><button className="btn btn--primary" disabled={busy || !text.trim()}>Send</button></form>
      </aside>}
    </>
  );
}

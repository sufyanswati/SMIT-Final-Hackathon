// Ladoo mark: a round golden laddu with a gradient and grain dots. Pure SVG, no external assets.
export default function LadooLogo({ size = 32, id = 'lg' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" role="img" aria-label="Ladoo logo" focusable="false">
      <defs>
        <radialGradient id={`${id}-b`} cx="35%" cy="30%" r="75%"><stop offset="0" stopColor="#ffd166" /><stop offset=".55" stopColor="#f59f00" /><stop offset="1" stopColor="#e8590c" /></radialGradient>
      </defs>
      <circle cx="32" cy="32" r="28" fill={`url(#${id}-b)`} />
      <g fill="#fff3c4" opacity=".75">{[[22,22],[34,16],[44,26],[18,36],[30,30],[42,40],[26,46],[36,50],[48,34]].map(([x, y]) => <circle key={`${x}-${y}`} cx={x} cy={y} r="2" />)}</g>
      <ellipse cx="24" cy="18" rx="9" ry="5" fill="#fff" opacity=".28" transform="rotate(-25 24 18)" />
    </svg>
  );
}

import { useFetch } from '../lib/auth.jsx';
import { Card, Spinner, ErrorBox, Empty } from './ui.jsx';

/** Per-employee attendance anomalies + attrition RISK (heuristic score, not the company attrition rate). Staff only. */
export default function InsightsPanel() {
  const { data, loading, error, reload } = useFetch('/insights/employees');
  const rows = data?.items?.filter((i) => i.flags.length || i.risk.score >= 30) || [];
  return (
    <Card title="Attendance anomalies & attrition risk">
      <p className="muted small">Rule-based score from the last 90 days of attendance, tenure and pay. It is a prompt to talk to the person, not a prediction or a decision. {data?.window && `Window: ${data.window.from} to ${data.window.to}.`}</p>
      <ErrorBox message={error} onRetry={reload} />
      {loading && !data ? <Spinner /> : !rows.length ? <Empty title="No anomalies or elevated risk found" /> :
        <div className="table-wrap"><table><thead><tr><th>Employee</th><th>Department</th><th>Risk</th><th>Why</th><th>Anomalies</th></tr></thead>
          <tbody>{rows.slice(0, 15).map((r) => <tr key={r.employee}>
            <td>{r.name} <span className="muted small">{r.code}</span></td><td>{r.department || '—'}</td>
            <td><span className={`risk--${r.risk.level}`}>{r.risk.level} ({r.risk.score})</span></td>
            <td className="wrap">{r.risk.factors.map((f) => f.label).join('; ') || '—'}</td>
            <td className="wrap">{r.flags.map((f) => f.message).join('; ') || '—'}</td></tr>)}</tbody></table></div>}
    </Card>
  );
}

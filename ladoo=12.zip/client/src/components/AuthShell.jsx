import { useEffect, useState } from 'react';

// Rotating background + copy from the supplied login/signup design, adapted to Ladoo HCM.
// Photos are the ones from the supplied ZIP (resized to /public/auth).
const SLIDES = [
  { img: '/auth/bg-1.jpg', kicker: 'People operations', title: 'Welcome to the Lado', text: 'One place for your employees, attendance, leave and payroll.' },
  { img: '/auth/bg-2.jpg', kicker: 'Attendance', title: 'Every day, accounted for', text: 'Check in with an optional location check, and request a correction when something goes wrong.' },
  { img: '/auth/bg-3.jpg', kicker: 'Leave', title: 'Time off, without the paperwork', text: 'Apply, approve and track balances in a single flow.' },
  { img: '/auth/bg-4.jpg', kicker: 'Payroll', title: 'Payslips you can trust', text: 'Draft, finalize and download PDF payslips each month.' },
  { img: '/auth/bg-5.jpg', kicker: 'Dashboards', title: 'The right view for every role', text: 'Admin, HR and employees each see what matters to them.' },
];
const INTERVAL_MS = 8000;

function usePrefersReducedMotion() {
  const [reduce, setReduce] = useState(() => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false);
  useEffect(() => {
    const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    if (!mq) return undefined;
    const on = () => setReduce(mq.matches);
    mq.addEventListener?.('change', on);
    return () => mq.removeEventListener?.('change', on);
  }, []);
  return reduce;
}

export default function AuthShell({ children, onReplay }) {
  const [i, setI] = useState(0);
  const reduce = usePrefersReducedMotion();

  useEffect(() => {
    if (reduce) return undefined; // no auto-rotation for people who prefer reduced motion
    const t = setInterval(() => setI((x) => (x + 1) % SLIDES.length), INTERVAL_MS);
    return () => clearInterval(t);
  }, [reduce]);

  const s = SLIDES[i];
  return (
    <div className="authx">
      <div className="authx__bg" aria-hidden="true">
        {SLIDES.map((sl, k) => <img key={sl.img} src={sl.img} alt="" className={k === i ? 'is-active' : ''} decoding="async" />)}
      </div>
      <header className="authx__header">
        <div className="authx__brand"><span aria-hidden="true">🍯</span> Ladoo</div>
      </header>
      <main id="main" className="authx__main">
        <section className="authx__hero" key={i} aria-label="About Ladoo">
          <p className="authx__kicker">{s.kicker}</p>
          <h2 className="authx__title">{s.title}</h2>
          <p className="authx__text">{s.text}</p>
        </section>
        <div className="authx__card">{children}</div>
      </main>
      <footer className="authx__footer">
        <span>Ladoo HCM Lite</span>
        {onReplay && <button type="button" className="authx__link" onClick={onReplay}>Replay intro</button>}
      </footer>
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';

/**
 * Camera preview with browser-native FACE DETECTION (counts faces). This is NOT face recognition: it never identifies who the person is.
 * Uses the Shape Detection API (`window.FaceDetector`, Chromium only). Where it is missing the user is told, and no faceCount is sent.
 */
export default function FaceCamera({ onCount, onClose }) {
  const video = useRef(null); const stream = useRef(null);
  const [state, setState] = useState({ phase: 'starting', msg: '', count: null });
  const supported = typeof window !== 'undefined' && 'FaceDetector' in window;

  useEffect(() => {
    let dead = false;
    (async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) throw new Error('Camera is not available in this browser.');
        stream.current = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
        if (dead) return stream.current.getTracks().forEach((t) => t.stop());
        video.current.srcObject = stream.current; await video.current.play();
        setState({ phase: 'ready', msg: '', count: null });
      } catch (e) { setState({ phase: 'error', msg: e.name === 'NotAllowedError' ? 'Camera permission was denied.' : e.message || 'Camera could not be started.', count: null }); }
    })();
    return () => { dead = true; stream.current?.getTracks().forEach((t) => t.stop()); };
  }, []);

  const detect = async () => {
    try {
      const faces = await new window.FaceDetector({ fastMode: true, maxDetectedFaces: 5 }).detect(video.current);
      setState({ phase: 'done', msg: '', count: faces.length });
      onCount(faces.length);
    } catch { setState({ phase: 'error', msg: 'Face detection failed in this browser.', count: null }); }
  };

  return (
    <div className="face-cam" role="group" aria-label="Camera check">
      <video ref={video} muted playsInline aria-label="Camera preview" />
      {state.phase === 'error' && <p className="alert alert--error" role="alert">{state.msg}</p>}
      {!supported && state.phase !== 'error' && <p className="muted small">Face detection is not supported by this browser (try Chrome or Edge). Without it the check-in cannot include a face check.</p>}
      {state.phase === 'done' && <p role="status">{state.count === 1 ? 'One face detected.' : state.count === 0 ? 'No face detected — look at the camera and try again.' : `${state.count} faces detected — only you should be in view.`}</p>}
      <div className="row">
        <button type="button" className="btn btn--sm btn--primary" disabled={!supported || state.phase === 'starting' || state.phase === 'error'} onClick={detect}>Detect face</button>
        <button type="button" className="btn btn--sm" onClick={onClose}>Close camera</button>
      </div>
      <p className="muted small">Face <em>detection</em> only (counts faces). It does not identify or store who you are; no image leaves your device.</p>
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useAuth, useFetch } from '../lib/auth.jsx';
import { api } from '../lib/api.js';
import { useLang } from '../lib/i18n.js';
import LadooLogo from './LadooLogo.jsx';
import { BellIcon, MenuIcon, CloseIcon } from './icons.jsx';

const LINKS = {
  admin: [['/', 'Dashboard'], ['/employees', 'Employees'], ['/attendance', 'Attendance'], ['/leave', 'Leave'], ['/payroll', 'Payroll'], ['/announcements', 'Announcements'], ['/settings', 'Organization'], ['/users', 'Accounts'], ['/audit', 'Audit log']],
  hr: [['/', 'Dashboard'], ['/employees', 'Employees'], ['/attendance', 'Attendance'], ['/leave', 'Leave'], ['/payroll', 'Payroll'], ['/announcements', 'Announcements']],
  employee: [['/', 'Dashboard'], ['/attendance', 'Attendance'], ['/leave', 'Leave'], ['/payroll', 'Payslips'], ['/announcements', 'Announcements'], ['/profile', 'My profile']],
};

function Bell() {
  const { data, reload } = useFetch('/notifications');
  const [open, setOpen] = useState(false);
  const markRead = async () => { await api('/notifications/read-all', { method: 'POST' }); reload(); };
  return (
    <div className="bell">
      <button className="icon-btn" aria-label={`Notifications${data?.unread ? `, ${data.unread} unread` : ''}`} aria-expanded={open} onClick={() => { setOpen(!open); if (!open && data?.unread) markRead(); }}>
        <BellIcon />{data?.unread > 0 && <span className="bell__count">{data.unread}</span>}
      </button>
      {open && <div className="bell__panel" role="region" aria-label="Notifications">
        {data?.items?.length ? data.items.slice(0, 8).map((n) => <div key={n._id} className="bell__item">{n.message}<small className="muted"> {new Date(n.createdAt).toLocaleString()}</small></div>) : <p className="muted small">No notifications yet.</p>}
      </div>}
    </div>
  );
}

export default function Navbar() {
  const { user, settings, logout } = useAuth();
  const [scrolled, setScrolled] = useState(window.scrollY > 8);
  const [menu, setMenu] = useState(false);
  const stripRef = useRef(null);
  const nav = useNavigate();
  const { t, lang, toggle } = useLang();

  useEffect(() => {
    // Solid at the top, translucent after scrolling. The multicolour line's fill follows scroll progress; it is written
    // straight to a CSS variable inside requestAnimationFrame, so scrolling never triggers a React re-render.
    let raf = 0;
    const update = () => {
      raf = 0;
      const max = document.documentElement.scrollHeight - window.innerHeight;
      const progress = max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0;
      stripRef.current?.style.setProperty('--p', progress.toFixed(4));
      setScrolled(window.scrollY > 8);
    };
    const on = () => { if (!raf) raf = requestAnimationFrame(update); };
    window.addEventListener('scroll', on, { passive: true });
    window.addEventListener('resize', on);
    const ro = typeof ResizeObserver === 'function' ? new ResizeObserver(on) : null; // page height changes as content loads
    ro?.observe(document.body);
    update();
    return () => { window.removeEventListener('scroll', on); window.removeEventListener('resize', on); ro?.disconnect(); if (raf) cancelAnimationFrame(raf); };
  }, []);

  const locked = !!user?.mustChangePassword; // forced password change: nothing else is reachable
  const links = user && !locked ? LINKS[user.role] : [];
  return (
    <header className={`navbar ${scrolled ? 'navbar--glass' : 'navbar--solid'}`}>
      <div className="navbar__inner">
        <Link to="/" className="navbar__brand" aria-label="Ladoo home"><LadooLogo size={26} /> <span>Ladoo</span><small>{settings?.companyName}</small></Link>
        {user && <>
          {!locked && <button className="icon-btn navbar__toggle" aria-label="Toggle navigation menu" aria-expanded={menu} aria-controls="main-nav" onClick={() => setMenu(!menu)}>{menu ? <CloseIcon /> : <MenuIcon />}</button>}
          <nav id="main-nav" className={`navbar__links ${menu ? 'is-open' : ''}`} aria-label="Main">
            {links.map(([to, label]) => <NavLink key={to} to={to} end={to === '/'} onClick={() => setMenu(false)} className={({ isActive }) => (isActive ? 'active' : '')}>{t(label)}</NavLink>)}
          </nav>
          <div className="navbar__user">
            {!locked && <Bell />}
            <span className="navbar__who" title={user.email}>{user.name} <span className="pill">{user.role}</span></span>
            <button className="btn btn--sm" onClick={toggle} aria-label="Language" title="English / Roman Urdu">{lang === 'ur' ? 'EN' : 'اردو'}</button>
            <button className="btn btn--sm" onClick={() => { logout(); nav('/login'); }}>{t('Sign out')}</button>
          </div>
        </>}
      </div>
      <div ref={stripRef} className="navbar__strip" aria-hidden="true" />
    </header>
  );
}

import { useEffect, useRef, useState } from 'react';
import LadooLogo from './LadooLogo.jsx';
import { useLang } from '../lib/i18n.js';

export const soundEnabled = () => localStorage.getItem('ladoo.sound') !== 'off';
const spoken = new Set(); // each phrase is spoken at most once per page load
const sessionKey = (t) => `ladoo.spoken.${t}`;
export const resetSpoken = () => { spoken.clear(); sessionStorage.removeItem(sessionKey('Welcome to Ladoo')); };
export function speakOnce(text, { perSession = false } = {}) {
  if (spoken.has(text) || !soundEnabled() || !('speechSynthesis' in window)) return;
  if (perSession) { if (sessionStorage.getItem(sessionKey(text))) return; sessionStorage.setItem(sessionKey(text), '1'); }
  spoken.add(text);
  try { const u = new SpeechSynthesisUtterance(text); u.rate = 0.95; window.speechSynthesis.speak(u); } catch { /* blocked by browser: silent fallback */ }
}

const Flame = ({ delay, lane }) => {
  const gid = `fg-${lane}-${String(delay).replace('.', '')}`; // unique per flame: duplicate ids are invalid HTML
  return (
  <svg className="flame" style={{ animationDelay: `${delay}s` }} viewBox="0 0 64 96" aria-hidden="true">
    <defs><linearGradient id={gid} x1="0" y1="1" x2="0" y2="0"><stop offset="0" stopColor="#ff3d00" /><stop offset=".55" stopColor="#ff9100" /><stop offset="1" stopColor="#ffe082" /></linearGradient></defs>
    <path d="M32 2c4 18 26 30 26 54a26 26 0 0 1-52 0c0-12 6-18 12-26 1 8 5 12 9 13C24 28 28 16 32 2z" fill={`url(#${gid})`} />
    <path d="M32 50c3 10 12 14 12 26a12 12 0 0 1-24 0c0-8 6-12 12-26z" fill="#fff3c4" opacity=".85" />
  </svg>
  );
};

/**
 * Sequence: flames right→left (1.4s) → flames left→right (1.4s) → centered "Ladoo" gradient (2s) → app.
 * Plays once per browser session; "Replay intro" in the footer clears the flag.
 */
export default function Intro({ onDone }) {
  const reduced = useRef(window.matchMedia?.('(prefers-reduced-motion: reduce)').matches).current;
  const [phase, setPhase] = useState(reduced ? 'brand' : 'fire-rtl');
  const [sound, setSound] = useState(soundEnabled());
  const finished = useRef(false);
  const { t } = useLang();

  const finish = () => { if (finished.current) return; finished.current = true; window.speechSynthesis?.cancel(); sessionStorage.setItem('ladoo.intro', '1'); sessionStorage.setItem(sessionKey('Welcome to Ladoo'), '1'); onDone(); };

  useEffect(() => {
    const t = [];
    if (!reduced) { t.push(setTimeout(() => setPhase('fire-ltr'), 1400)); t.push(setTimeout(() => setPhase('brand'), 2800)); }
    t.push(setTimeout(() => setPhase('out'), (reduced ? 0 : 2800) + (reduced ? 900 : 2000)));
    t.push(setTimeout(finish, (reduced ? 0 : 2800) + (reduced ? 900 : 2000) + 450));
    return () => t.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { if (phase === 'brand') speakOnce('Welcome to Ladoo'); }, [phase]);
  const toggle = () => { const n = !sound; setSound(n); localStorage.setItem('ladoo.sound', n ? 'on' : 'off'); if (!n) window.speechSynthesis?.cancel(); };

  return (
    <div className={`intro ${phase === 'out' ? 'intro--out' : ''}`} role="dialog" aria-label="Welcome to Ladoo">
      <div className="intro__controls">
        <button className="btn btn--ghost btn--sm" onClick={toggle} aria-pressed={sound}>{sound ? `🔊 ${t('Sound on')}` : `🔇 ${t('Sound off')}`}</button>
        <button className="btn btn--ghost btn--sm" onClick={finish}>{t('Skip')}</button>
      </div>
      {phase === 'fire-rtl' && <div className="intro__lane intro__lane--rtl" data-testid="fire-right-to-left">{[0, 0.12, 0.24, 0.36].map((d) => <Flame key={d} delay={d} lane="rtl" />)}</div>}
      {phase === 'fire-ltr' && <div className="intro__lane intro__lane--ltr" data-testid="fire-left-to-right">{[0, 0.12, 0.24, 0.36].map((d) => <Flame key={d} delay={d} lane="ltr" />)}</div>}
      {(phase === 'brand' || phase === 'out') && <div className="intro__logo"><LadooLogo size={96} id="intro" /><h1 className={`intro__brand ${reduced ? 'intro__brand--static' : ''}`}>Ladoo</h1><p className="intro__tag">{t('Welcome to Ladoo')}</p></div>}
    </div>
  );
}

import { useEffect, useState } from 'react';
import { Routes, Route, Navigate, Link } from 'react-router-dom';
import { useAuth } from './lib/auth.jsx';
import Intro, { speakOnce, resetSpoken } from './components/Intro.jsx';
import Navbar from './components/Navbar.jsx';
import AuthShell from './components/AuthShell.jsx';
import ChatPanel from './components/ChatPanel.jsx';
import { Spinner } from './components/ui.jsx';
import { Setup, Login, ChangePassword } from './pages/Auth.jsx';
import Dashboard from './pages/Dashboard.jsx';
import { Employees, EmployeeDetail } from './pages/Employees.jsx';
import Attendance from './pages/Attendance.jsx';
import Leave from './pages/Leave.jsx';
import Payroll from './pages/Payroll.jsx';
import { Settings, Users, Audit, Announcements, Profile } from './pages/Admin.jsx';

// Module-level so it keeps its identity between renders (no remounting of Navbar/page on every state change).
function Shell({ children, onReplay }) {
  return <><Navbar /><main className="page" id="main">{children}</main><footer className="footer"><button className="link-btn" onClick={onReplay}>Replay intro</button><span>Ladoo HCM Lite</span></footer></>;
}

export default function App() {
  const { loading, initialized, user, error } = useAuth();
  const [introDone, setIntroDone] = useState(sessionStorage.getItem('ladoo.intro') === '1');

  // "Welcome" is spoken once, only after the real app is visible.
  useEffect(() => { if (introDone && !loading) speakOnce('Welcome to Ladoo', { perSession: true }); }, [introDone, loading]);

  const replay = () => { sessionStorage.removeItem('ladoo.intro'); resetSpoken(); setIntroDone(false); };
  let body;
  if (loading) body = <Shell onReplay={replay}><Spinner /></Shell>;
  else if (!initialized) body = <AuthShell onReplay={replay}><Setup /></AuthShell>;
  else if (!user) body = <AuthShell onReplay={replay}><Routes><Route path="*" element={<Login error={error} />} /></Routes></AuthShell>;
  else if (user.mustChangePassword) body = <AuthShell onReplay={replay}><ChangePassword forced /></AuthShell>;
  else {
    const staff = user.role !== 'employee';
    body = <Shell onReplay={replay}>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        {staff && <Route path="/employees" element={<Employees />} />}
        <Route path="/employees/:id" element={<EmployeeDetail />} />
        <Route path="/attendance" element={<Attendance />} />
        <Route path="/leave" element={<Leave />} />
        <Route path="/payroll" element={<Payroll />} />
        <Route path="/announcements" element={<Announcements />} />
        <Route path="/change-password" element={<ChangePassword />} />
        {user.role === 'employee' && <Route path="/profile" element={<Profile />} />}
        {user.role === 'admin' && <><Route path="/settings" element={<Settings />} /><Route path="/users" element={<Users />} /><Route path="/audit" element={<Audit />} /></>}
        <Route path="/login" element={<Navigate to="/" replace />} />
        <Route path="*" element={<div className="card"><h2>Page not found</h2><Link to="/">Back to dashboard</Link></div>} />
      </Routes>
      <ChatPanel />
    </Shell>;
  }
  return <>{!introDone && <Intro onDone={() => setIntroDone(true)} />}{body}</>;
}

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../lib/api.js';
import { useAuth } from '../lib/auth.jsx';
import { ErrorBox, useForm, Success } from '../components/ui.jsx';
import AuthField from '../components/AuthField.jsx';

function useSubmit(fn) {
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const submit = async (e) => { e.preventDefault(); setBusy(true); setError(''); try { await fn(); } catch (err) { setError(err.message); } finally { setBusy(false); } };
  return { busy, error, submit };
}

const PW_HINT = 'At least 8 characters, with a letter and a digit.';
const SubmitButton = ({ busy, idle, working }) => <button className="authbtn" disabled={busy}>{busy ? <><span className="spinner" aria-hidden="true" /> {working}</> : idle}</button>;

// First-run "sign up": creates the organisation and the first Admin (POST /api/setup). Shown once.
export function Setup() {
  const { startSession } = useAuth();
  const [v, bind] = useForm({ companyName: '', name: '', email: '', password: '', confirm: '' });
  const { busy, error, submit } = useSubmit(async () => {
    if (v.password !== v.confirm) throw new Error('Password and confirmation do not match');
    const d = await api('/setup', { method: 'POST', body: { companyName: v.companyName, name: v.name, email: v.email, password: v.password } });
    await startSession(d);
  });
  return (
    <>
      <h1 className="authx__h1">Set up Ladoo</h1>
      <p className="authx__sub">Create your organisation and the first administrator account. This screen only appears once.</p>
      <form className="authx__form" onSubmit={submit} noValidate={false}>
        <AuthField id="companyName" label="Company name" icon="building" required minLength={2} {...bind('companyName')} />
        <AuthField id="name" label="Your full name" icon="user" required minLength={2} autoComplete="name" {...bind('name')} />
        <AuthField id="email" label="Admin email" icon="mail" type="email" required autoComplete="username" {...bind('email')} />
        <AuthField id="password" label="Password" icon="lock" type="password" required minLength={8} autoComplete="new-password" hint={PW_HINT} {...bind('password')} />
        <AuthField id="confirm" label="Confirm password" icon="lock" type="password" required minLength={8} autoComplete="new-password" {...bind('confirm')} />
        <ErrorBox message={error} />
        <SubmitButton busy={busy} idle="Create organisation" working="Creating…" />
      </form>
    </>
  );
}

export function Login({ error: bootError }) {
  const { startSession } = useAuth();
  const [v, bind] = useForm({ email: '', password: '', remember: true });
  const { busy, error, submit } = useSubmit(async () => {
    const d = await api('/auth/login', { method: 'POST', body: { email: v.email, password: v.password } });
    await startSession(d, { remember: v.remember });
  });
  return (
    <>
      <h1 className="authx__h1">Sign in</h1>
      <p className="authx__sub">Accounts are created by your administrator.</p>
      <form className="authx__form" onSubmit={submit}>
        <AuthField id="email" label="Email" icon="mail" type="email" required autoComplete="username" {...bind('email')} />
        <AuthField id="password" label="Password" icon="lock" type="password" required autoComplete="current-password" {...bind('password')} />
        <label className="authx__check"><input type="checkbox" checked={v.remember} onChange={bind('remember').onChange} /> Remember me</label>
        <ErrorBox message={error || bootError} />
        <SubmitButton busy={busy} idle="Sign in" working="Signing in…" />
      </form>
      <p className="authx__note">Forgot your password? Ask an administrator to reset it.</p>
    </>
  );
}

export function ChangePassword({ forced }) {
  const { startSession, logout } = useAuth(); const nav = useNavigate();
  const [done, setDone] = useState('');
  const [v, bind, setV] = useForm({ currentPassword: '', newPassword: '', confirm: '' });
  const { busy, error, submit } = useSubmit(async () => {
    if (v.newPassword !== v.confirm) throw new Error('New password and confirmation do not match');
    const d = await api('/auth/change-password', { method: 'POST', body: { currentPassword: v.currentPassword, newPassword: v.newPassword } });
    setV({ currentPassword: '', newPassword: '', confirm: '' }); await startSession(d); setDone('Password updated.'); if (!forced) nav('/');
  });
  const form = (
    <>
      <h1 className={forced ? 'authx__h1' : undefined}>{forced ? 'Choose a new password' : 'Change password'}</h1>
      {forced && <p className="authx__sub">For security you must replace your temporary password before continuing.</p>}
      <form className={forced ? 'authx__form' : 'form form--narrow'} onSubmit={submit}>
        <AuthField id="currentPassword" label={forced ? 'Temporary password' : 'Current password'} icon="lock" type="password" required autoComplete="current-password" {...bind('currentPassword')} />
        <AuthField id="newPassword" label="New password" icon="lock" type="password" required minLength={8} autoComplete="new-password" hint={PW_HINT} {...bind('newPassword')} />
        <AuthField id="confirm" label="Confirm new password" icon="lock" type="password" required autoComplete="new-password" {...bind('confirm')} />
        <ErrorBox message={error} /><Success message={done} />
        {forced
          ? <><SubmitButton busy={busy} idle="Update password" working="Saving…" /><button type="button" className="authx__link authx__link--block" onClick={() => { logout(); nav('/login'); }}>Sign out</button></>
          : <button className="btn btn--primary" disabled={busy}>{busy ? 'Saving…' : 'Update password'}</button>}
      </form>
    </>
  );
  return forced ? form : <div className="card auth">{form}</div>;
}

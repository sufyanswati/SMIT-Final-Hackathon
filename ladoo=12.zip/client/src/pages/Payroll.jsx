import { useState } from 'react';
import { api, download } from '../lib/api.js';
import { useAuth, useFetch, fmtMoney2 } from '../lib/auth.jsx';
import { Card, Spinner, ErrorBox, Success, Empty, Badge, Confirm, Field } from '../components/ui.jsx';

function EmployeeView() {
  const { data, loading, error, reload } = useFetch('/payroll/mine'); const [err, setErr] = useState('');
  const get = async (i) => { setErr(''); try { await download(`/payroll/${i.runId}/payslip`, `payslip-${i.month}.pdf`); } catch (e) { setErr(e.message); } };
  return (
    <div className="stack"><h1>My payslips</h1>
      <ErrorBox message={err || error} onRetry={reload} />
      <Card>{loading && !data ? <Spinner /> : data?.items.length ? <div className="table-wrap"><table><thead><tr><th>Month</th><th className="num">Gross earned</th><th className="num">Net pay</th><th /></tr></thead>
        <tbody>{data.items.map((i) => <tr key={i.runId}><td>{i.month}</td><td className="num">{fmtMoney2(i.gross)}</td><td className="num">{fmtMoney2(i.net)}</td><td><button className="btn btn--sm" onClick={() => get(i)}>Download PDF</button></td></tr>)}</tbody></table></div> : <Empty title="No payslips yet" hint="Payslips appear after HR runs and an administrator finalizes payroll." />}</Card>
    </div>
  );
}

function RunDetail({ id, onChanged }) {
  const { user } = useAuth();
  const { data: run, loading, error, reload } = useFetch(`/payroll/${id}`); const [err, setErr] = useState(''); const [ok, setOk] = useState('');
  const finalize = async () => { setErr(''); try { await api(`/payroll/${id}/finalize`, { method: 'POST' }); setOk('Payroll finalized and locked. Employees were notified.'); reload(); onChanged(); } catch (e) { setErr(e.message); } };
  const slip = async (i) => { setErr(''); try { await download(`/payroll/${id}/payslip/${i.employee}`, `payslip-${run.month}-${i.code}.pdf`); } catch (e) { setErr(e.message); } };
  if (loading && !run) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  return (
    <Card title={`Payroll ${run.month}`} actions={<span className="row"><Badge status={run.status} />{user.role === 'admin' && run.status === 'draft' && <Confirm className="btn btn--primary btn--sm" message={`Finalize payroll for ${run.month}? It will be locked and can no longer be recalculated.`} onConfirm={finalize}>Finalize</Confirm>}</span>}>
      <ErrorBox message={err} /><Success message={ok} />
      <p>Totals — gross <strong>{fmtMoney2(run.totals.gross)}</strong>, deductions {fmtMoney2(run.totals.deduction)}, tax {fmtMoney2(run.totals.tax)}, net <strong>{fmtMoney2(run.totals.net)}</strong></p>
      {run.status === 'draft' && <p className="muted small">Draft: figures reflect attendance and leave as of the last calculation. {user.role === 'hr' ? 'Run the draft again to refresh it.' : 'HR prepares drafts; administrators finalize them.'}</p>}
      <div className="table-wrap"><table><thead><tr><th>Code</th><th>Employee</th><th>Dept</th><th className="num">Gross</th><th className="num">Absent</th><th className="num">Unpaid leave</th><th className="num">Half</th><th className="num">Deduction</th><th className="num">Tax</th><th className="num">Net</th><th /></tr></thead>
        <tbody>{run.items.map((i) => <tr key={i.employee}><td>{i.code}</td><td>{i.name}</td><td>{i.department}</td><td className="num">{fmtMoney2(i.earnedGross)}</td><td className="num">{i.absent}</td><td className="num">{i.unpaidLeave}</td><td className="num">{i.halfDays}</td><td className="num">{fmtMoney2(i.deduction)}</td><td className="num">{fmtMoney2(i.tax)}</td><td className="num"><strong>{fmtMoney2(i.net)}</strong></td><td><button className="btn btn--sm" onClick={() => slip(i)}>PDF</button></td></tr>)}</tbody></table></div>
      <p className="muted small">Tax uses the illustrative slabs from the challenge brief; it is not official tax advice.</p>
    </Card>
  );
}

function StaffView() {
  const { user, settings } = useAuth();
  const { data, loading, error, reload } = useFetch('/payroll');
  const [sel, setSel] = useState(null); const [month, setMonth] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const [k, setK] = useState(0);
  const draft = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try { const r = await api('/payroll/drafts', { method: 'POST', body: { month } }); setSel(r._id); setK(k + 1); reload(); } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  return (
    <div className="stack"><h1>Payroll</h1>
      <ErrorBox message={error || err} onRetry={reload} />
      {user.role === 'hr' && <Card title="Prepare a draft"><form className="row" onSubmit={draft}><Field label="Month"><input type="month" required value={month} onChange={(e) => setMonth(e.target.value)} /></Field><button className="btn btn--primary" disabled={busy || !month}>{busy ? 'Calculating…' : 'Create / refresh draft'}</button></form>
        <p className="muted small">Uses attendance, approved leave and salaries as of now{settings ? ` (${settings.timezone})` : ''}. Finalized months are locked.</p></Card>}
      <Card title="Payroll runs">{loading && !data ? <Spinner /> : data?.items.length ? <div className="table-wrap"><table><thead><tr><th>Month</th><th>Status</th><th className="num">Gross</th><th className="num">Net</th><th /></tr></thead>
        <tbody>{data.items.map((r) => <tr key={r._id}><td>{r.month}</td><td><Badge status={r.status} /></td><td className="num">{fmtMoney2(r.totals?.gross)}</td><td className="num">{fmtMoney2(r.totals?.net)}</td><td><button className="btn btn--sm" onClick={() => setSel(r._id)}>Open</button></td></tr>)}</tbody></table></div> : <Empty title="No payroll runs yet" hint={user.role === 'hr' ? 'Create a draft for a month above.' : 'HR creates drafts; you finalize them here.'} />}</Card>
      {sel && <RunDetail key={`${sel}-${k}`} id={sel} onChanged={reload} />}
    </div>
  );
}

export default function Payroll() { const { user } = useAuth(); return user.role === 'employee' ? <EmployeeView /> : <StaffView />; }

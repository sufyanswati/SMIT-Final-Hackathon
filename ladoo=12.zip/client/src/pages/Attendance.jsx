import { useState } from 'react';
import { api } from '../lib/api.js';
import { useAuth, useFetch, fmtTime } from '../lib/auth.jsx';
import { Card, Spinner, ErrorBox, Success, Empty, Badge, Field, useForm, Stat } from '../components/ui.jsx';

const hm = (m) => (m ? `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m` : '—');

function CorrectionForm({ onDone }) {
  const [v, bind, setV] = useForm({ date: '', checkIn: '', checkOut: '', reason: '' });
  const [error, setError] = useState(''); const [ok, setOk] = useState('');
  const submit = async (e) => {
    e.preventDefault(); setError(''); setOk('');
    try { const body = { ...v }; if (!body.checkOut) delete body.checkOut; await api('/attendance/corrections', { method: 'POST', body }); setOk('Correction submitted for HR review.'); setV({ date: '', checkIn: '', checkOut: '', reason: '' }); onDone(); }
    catch (err) { setError(err.message); }
  };
  return (
    <form className="form" onSubmit={submit}>
      <Field label="Date"><input type="date" required {...bind('date')} /></Field>
      <Field label="Check-in time"><input type="time" required {...bind('checkIn')} /></Field>
      <Field label="Check-out time"><input type="time" {...bind('checkOut')} /></Field>
      <Field label="Reason"><input required minLength={5} maxLength={500} {...bind('reason')} /></Field>
      <div className="form__wide"><ErrorBox message={error} /><Success message={ok} /><button className="btn btn--primary">Submit correction</button></div>
    </form>
  );
}

function CorrectionList({ canDecide, refreshKey, onChanged }) {
  const [status, setStatus] = useState(canDecide ? 'pending' : '');
  const { data, loading, error, reload } = useFetch('/attendance/corrections', { status }, [refreshKey]);
  const [comment, setComment] = useState({}); const [err, setErr] = useState('');
  const decide = async (id, approve) => {
    setErr('');
    try { await api(`/attendance/corrections/${id}/decision`, { method: 'POST', body: { approve, comment: comment[id] || undefined } }); reload(); onChanged?.(); }
    catch (e) { setErr(e.message); }
  };
  return (
    <Card title="Corrections" actions={<select aria-label="Filter by status" value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option></select>}>
      <ErrorBox message={error || err} onRetry={reload} />
      {loading && !data ? <Spinner /> : data?.items.length ? <div className="table-wrap"><table><thead><tr><th>Employee</th><th>Date</th><th>In</th><th>Out</th><th>Reason</th><th>Status</th>{canDecide && <th>Decision</th>}</tr></thead>
        <tbody>{data.items.map((c) => <tr key={c._id}><td>{c.employee ? `${c.employee.firstName} ${c.employee.lastName}` : '—'}</td><td>{c.date}</td><td>{c.checkIn}</td><td>{c.checkOut || '—'}</td><td className="wrap">{c.reason}{c.comment && <div className="muted small">Reviewer: {c.comment}</div>}</td><td><Badge status={c.status} /></td>
          {canDecide && <td>{c.status === 'pending' && <div className="row"><input aria-label="Comment" placeholder="Comment (optional)" value={comment[c._id] || ''} onChange={(e) => setComment({ ...comment, [c._id]: e.target.value })} style={{ width: 150 }} /><button className="btn btn--sm btn--primary" onClick={() => decide(c._id, true)}>Approve</button><button className="btn btn--sm btn--danger" onClick={() => decide(c._id, false)}>Reject</button></div>}</td>}</tr>)}</tbody></table></div> : <Empty title="No corrections" />}
    </Card>
  );
}

function EmployeeView() {
  const { settings } = useAuth(); const tz = settings?.timezone;
  const [month, setMonth] = useState('');
  const { data, loading, error, reload } = useFetch('/attendance/me', { month });
  const [k, setK] = useState(0);
  const cur = month || data?.today?.slice(0, 7) || '';
  return (
    <div className="stack">
      <div className="row spread"><h1>My attendance</h1><label className="field"><span>Month</span><input type="month" value={cur} max={data?.today?.slice(0, 7)} onChange={(e) => e.target.value && setMonth(e.target.value)} /></label></div>
      <ErrorBox message={error} onRetry={reload} />
      {loading && !data ? <Spinner /> : data && <>
        <div className="grid grid--4"><Stat label="Present" value={data.summary.present} /><Stat label="Late" value={data.summary.late} /><Stat label="Absent" value={data.summary.absent} /><Stat label="On leave" value={data.summary.on_leave} /><Stat label="Half-days" value={data.summary.half_day} /><Stat label="Missing check-out" value={data.summary.missing_checkout} /></div>
        <Card title="Daily record"><div className="table-wrap"><table><thead><tr><th>Date</th><th>Status</th><th>Check-in</th><th>Check-out</th><th className="num">Worked</th></tr></thead>
          <tbody>{data.days.filter((d) => d.status !== 'n/a' && d.status !== 'future').map((d) => <tr key={d.date}><td>{d.date}</td><td><Badge status={d.status} /></td><td>{fmtTime(d.checkIn, tz)}</td><td>{fmtTime(d.checkOut, tz)}</td><td className="num">{hm(d.workedMinutes)}</td></tr>)}</tbody></table></div></Card>
      </>}
      <Card title="Request an attendance correction"><p className="muted small">Forgot to check in or out, or the location check failed? Submit the correct times; HR will review and approve or reject.</p><CorrectionForm onDone={() => { setK(k + 1); reload(); }} /></Card>
      <CorrectionList canDecide={false} refreshKey={k} />
    </div>
  );
}

function StaffView() {
  const { user, settings } = useAuth(); const tz = settings?.timezone;
  const [date, setDate] = useState(''); const [dept, setDept] = useState('');
  const [range, setRange] = useState({ from: '', to: '' });
  const depts = useFetch('/departments');
  const board = useFetch('/attendance/board', { date, department: dept });
  const sum = useFetch('/attendance/summary', { ...range, department: dept });
  return (
    <div className="stack">
      <div className="row spread"><h1>Attendance</h1>
        <label className="field"><span>Department</span><select value={dept} onChange={(e) => setDept(e.target.value)}><option value="">All</option>{depts.data?.items.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></label></div>
      <Card title={`Daily board — ${board.data?.date || ''}`} actions={<input type="date" aria-label="Board date" value={date || board.data?.date || ''} onChange={(e) => e.target.value && setDate(e.target.value)} />}>
        <ErrorBox message={board.error} onRetry={board.reload} />
        {board.loading && !board.data ? <Spinner /> : board.data?.items.length ? <div className="table-wrap"><table><thead><tr><th>Code</th><th>Name</th><th>Department</th><th>Status</th><th>In</th><th>Out</th></tr></thead>
          <tbody>{board.data.items.map((r) => <tr key={r.employee}><td>{r.code}</td><td>{r.name}</td><td>{r.department}</td><td><Badge status={r.status} /></td><td>{fmtTime(r.checkIn, tz)}</td><td>{fmtTime(r.checkOut, tz)}</td></tr>)}</tbody></table></div> : <Empty title="No employees for this date" />}
      </Card>
      <Card title={`Summary ${sum.data ? `(${sum.data.from} → ${sum.data.to})` : ''}`} actions={<div className="row"><input type="date" aria-label="From" value={range.from || sum.data?.from || ''} onChange={(e) => setRange({ ...range, from: e.target.value })} /><input type="date" aria-label="To" value={range.to || sum.data?.to || ''} onChange={(e) => setRange({ ...range, to: e.target.value })} /></div>}>
        <ErrorBox message={sum.error} onRetry={sum.reload} />
        {sum.loading && !sum.data ? <Spinner /> : sum.data && <>
          <div className="grid grid--4"><Stat label="Attendance rate" value={`${sum.data.attendanceRate}%`} /><Stat label="Late %" value={`${sum.data.latePercentage}%`} /><Stat label="Absenteeism" value={`${sum.data.absenteeismRate}%`} /></div>
          {sum.data.employees.length > 0 && <div className="table-wrap" style={{ marginTop: '1rem' }}><table><thead><tr><th>Code</th><th>Name</th><th>Department</th><th className="num">Present</th><th className="num">Late</th><th className="num">Half</th><th className="num">Absent</th><th className="num">Leave</th></tr></thead>
            <tbody>{sum.data.employees.map((e) => <tr key={e.employee}><td>{e.code}</td><td>{e.name}</td><td>{e.department}</td><td className="num">{e.present}</td><td className="num">{e.late}</td><td className="num">{e.half_day}</td><td className="num">{e.absent}</td><td className="num">{e.on_leave}</td></tr>)}</tbody></table></div>}
        </>}
      </Card>
      <CorrectionList canDecide={user.role === 'hr'} />
      {user.role === 'admin' && <p className="muted small">Administrators can review corrections; approval is performed by HR.</p>}
    </div>
  );
}

export default function Attendance() {
  const { user } = useAuth();
  return user.role === 'employee' ? <EmployeeView /> : <StaffView />;
}

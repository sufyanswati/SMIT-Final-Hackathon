import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ResponsiveContainer, BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend } from 'recharts';
import { api } from '../lib/api.js';
import { useAuth, useFetch, fmtMoney, fmtTime } from '../lib/auth.jsx';
import InsightsPanel from '../components/InsightsPanel.jsx';
import FaceCamera from '../components/FaceCamera.jsx';
import { Card, Stat, Spinner, ErrorBox, Empty, Badge, AiLabel, Success } from '../components/ui.jsx';

const COLORS = ['#e8590c', '#f59f00', '#2b8a3e', '#1971c2', '#9c36b5', '#868e96'];
const Chart = ({ children }) => <div className="chart-box"><ResponsiveContainer width="100%" height="100%">{children}</ResponsiveContainer></div>;
const BarBox = ({ data, x, y, name }) => !data?.length ? <Empty title="No data yet" /> : <Chart><BarChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey={x} /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey={y} name={name || y} fill="#e8590c" /></BarChart></Chart>;
const LineBox = ({ data, x, lines }) => !data?.length ? <Empty title="No data yet" /> : <Chart><LineChart data={data}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey={x} /><YAxis /><Tooltip /><Legend />{lines.map(([k, n, c]) => <Line key={k} type="monotone" dataKey={k} name={n} stroke={c} dot={false} />)}</LineChart></Chart>;
const PieBox = ({ obj }) => { const data = Object.entries(obj || {}).filter(([, v]) => v > 0).map(([name, value]) => ({ name, value })); return !data.length ? <Empty title="No data yet" /> : <Chart><PieChart><Pie data={data} dataKey="value" nameKey="name" outerRadius={90} label>{data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Tooltip /><Legend /></PieChart></Chart>; };

function Filters({ value, onChange, showFrom = true, defaults }) {
  const { data } = useFetch('/departments');
  return (
    <form className="row no-print" onSubmit={(e) => e.preventDefault()} aria-label="Dashboard filters">
      {showFrom && <><label className="field"><span>From</span><input type="date" value={value.from || defaults?.from || ''} onChange={(e) => onChange({ ...value, from: e.target.value })} /></label>
      <label className="field"><span>To</span><input type="date" value={value.to || defaults?.to || ''} onChange={(e) => onChange({ ...value, to: e.target.value })} /></label></>}
      <label className="field"><span>Department</span><select value={value.department} onChange={(e) => onChange({ ...value, department: e.target.value })}><option value="">All</option>{data?.items.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></label>
    </form>
  );
}

function AiSummary({ filters }) {
  const [s, setS] = useState({ busy: false, out: null, error: '' });
  const run = async () => { setS({ busy: true, out: null, error: '' }); try { setS({ busy: false, out: await api('/ai/summarize', { method: 'POST', body: Object.fromEntries(Object.entries(filters).filter(([, v]) => v)) }), error: '' }); } catch (e) { setS({ busy: false, out: null, error: e.message }); } };
  return (
    <Card title="AI summary" actions={<button className="btn btn--sm" onClick={run} disabled={s.busy}>{s.busy ? 'Summarizing…' : 'Summarize'}</button>}>
      <ErrorBox message={s.error} />
      {!s.out && !s.error && <p className="muted small">Generates a short narrative of the figures on this dashboard. Requires AI to be configured on the server.</p>}
      {s.out?.bullets?.length > 0 && <><ul>{s.out.bullets.map((b, i) => <li key={i}>{b}</li>)}</ul><AiLabel /></>}
      {s.out?.fallback && <p className="muted">{s.out.message}</p>}
    </Card>
  );
}

function AdminDash() {
  const [f, setF] = useState({ from: '', to: '', department: '' }); // blank = server defaults (company timezone)
  const { data: d, loading, error, reload } = useFetch('/dashboard/admin', f);
  return (
    <div className="stack">
      <div className="row spread"><h1>Admin dashboard</h1><Filters value={f} onChange={setF} defaults={d?.filters} /></div>
      <ErrorBox message={error} onRetry={reload} />
      {loading && !d ? <Spinner /> : d && <>
        <div className="grid grid--4">
          <Stat label="Headcount" value={d.headcount} />
          <Stat label="Attrition (period)" value={`${d.attritionYtd.rate}%`} hint={`${d.attritionYtd.exits} exits`} />
          <Stat label={d.payrollCost ? `Payroll gross (${d.payrollCost.month})` : 'Payroll gross'} value={d.payrollCost ? fmtMoney(d.payrollCost.gross) : 'No finalized run'} />
          <Stat label="Average gross salary" value={fmtMoney(d.averageGrossSalary)} />
        </div>
        <div className="grid grid--2">
          <Card title="Headcount by department"><BarBox data={d.headcountByDepartment} x="department" y="count" name="Employees" /></Card>
          <Card title="Payroll trend (finalized)"><LineBox data={d.payrollTrend} x="month" lines={[['gross', 'Gross', '#e8590c'], ['net', 'Net', '#2b8a3e']]} /></Card>
          <Card title="Payroll cost by department (latest)"><BarBox data={d.payrollCostByDepartment} x="department" y="gross" name="Gross" /></Card>
          <Card title="Average gross by department"><BarBox data={d.averageGrossByDepartment} x="department" y="average" name="Average" /></Card>
          <Card title="Gender distribution"><PieBox obj={d.gender} /></Card>
          <Card title="Tenure"><PieBox obj={d.tenure} /></Card>
        </div>
        <InsightsPanel />
        <Card title="Recent activity" actions={<Link to="/audit">Full audit log</Link>}>
          {d.audit.length ? <div className="table-wrap"><table><thead><tr><th>When</th><th>Who</th><th>Action</th></tr></thead><tbody>{d.audit.map((a) => <tr key={a._id}><td>{new Date(a.createdAt).toLocaleString()}</td><td>{a.actorName || '—'}</td><td>{a.action}</td></tr>)}</tbody></table></div> : <Empty title="No activity yet" />}
        </Card>
      </>}
    </div>
  );
}

function HrDash() {
  const [f, setF] = useState({ department: '' });
  const { data: d, loading, error, reload } = useFetch('/dashboard/hr', f);
  return (
    <div className="stack">
      <div className="row spread"><h1>HR dashboard</h1><Filters value={f} onChange={setF} showFrom={false} /></div>
      <ErrorBox message={error} onRetry={reload} />
      {loading && !d ? <Spinner /> : d && <>
        <p className="muted small">Metrics cover {d.filters.from} to {d.filters.to}.</p>
        <div className="grid grid--4">
          <Stat label="Headcount" value={d.headcount} />
          <Stat label="Present today" value={d.today.present} hint={`${d.today.late} late`} />
          <Stat label="On leave today" value={d.today.onLeave} />
          <Stat label="Absent so far today" value={d.today.absentSoFar} />
          <Stat label="Attendance rate" value={`${d.attendanceRate}%`} />
          <Stat label="Late arrivals" value={`${d.latePercentage}%`} />
          <Stat label="Absenteeism" value={`${d.absenteeismRate}%`} />
          <Stat label="Pending approvals" value={d.pendingApprovals.total} hint={`${d.pendingApprovals.leave} leave · ${d.pendingApprovals.corrections} corrections`} />
        </div>
        <div className="grid grid--2">
          <Card title="Attendance trend"><LineBox data={d.attendanceTrend} x="date" lines={[['attendanceRate', 'Attendance %', '#e8590c']]} /></Card>
          <Card title="Absenteeism by department (%)"><BarBox data={d.absenteeismByDepartment} x="department" y="absenteeismRate" name="Absenteeism %" /></Card>
          <Card title="Leave utilization by type">{d.leaveByType.length ? <div className="table-wrap"><table><thead><tr><th>Type</th><th className="num">Approved days</th><th className="num">Utilization</th></tr></thead><tbody>{d.leaveByType.map((t) => <tr key={t.type}><td>{t.type}</td><td className="num">{t.approvedDays}</td><td className="num">{t.utilization == null ? 'n/a (no quota)' : `${t.utilization}%`}</td></tr>)}</tbody></table></div> : <Empty title="No data yet" />}</Card>
          <Card title="Most frequent late arrivals">{d.topLateComers.length ? <div className="table-wrap"><table><thead><tr><th>Employee</th><th>Department</th><th className="num">Late days</th></tr></thead><tbody>{d.topLateComers.map((t) => <tr key={t.code}><td>{t.name} ({t.code})</td><td>{t.department}</td><td className="num">{t.lateCount}</td></tr>)}</tbody></table></div> : <Empty title="No late arrivals in this period" />}</Card>
        </div>
        <InsightsPanel />
        <AiSummary filters={{ department: f.department }} />
      </>}
    </div>
  );
}

function CheckInCard({ today, onChange }) {
  const { settings } = useAuth();
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [ok, setOk] = useState('');
  const [cam, setCam] = useState(false); const [faces, setFaces] = useState(null);
  const geo = () => new Promise((res, rej) => {
    if (!navigator.geolocation) return rej(new Error('Location is not available in this browser. Request an attendance correction instead.'));
    navigator.geolocation.getCurrentPosition((p) => res({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy }), () => rej(new Error('Location permission is required to mark attendance. Allow it or request a correction.')), { enableHighAccuracy: true, timeout: 15000 });
  });
  const act = async (kind) => {
    setBusy(true); setError(''); setOk('');
    try { if (cam && faces == null) throw new Error('Press "Detect face" first, or close the camera to continue without it.');
      const body = settings?.requireLocation ? await geo() : {}; if (cam && faces != null) body.faceCount = faces; await api(`/attendance/${kind}`, { method: 'POST', body }); setOk(kind === 'check-in' ? 'Checked in.' : 'Checked out.'); setFaces(null); onChange(); }
    catch (e) { setError(e.message); } finally { setBusy(false); }
  };
  const rec = today;
  const hasIn = !!rec?.checkIn; const hasOut = !!rec?.checkOut;
  const canOut = hasIn && !hasOut;                                   // an open session can always be closed
  const blocked = !hasIn && !!rec && ['weekend', 'holiday', 'on_leave'].includes(rec.status);
  const canIn = !hasIn && !blocked;
  return (
    <Card title="Today">
      <div className="row"><Badge status={rec?.status || 'not_checked_in'} /><span>In: {fmtTime(rec?.checkIn, settings?.timezone)}</span><span>Out: {fmtTime(rec?.checkOut, settings?.timezone)}</span></div>
      {settings?.requireLocation && <p className="muted small">Your location is checked against the office geofence when you check in or out.</p>}
      {cam ? <FaceCamera onCount={setFaces} onClose={() => { setCam(false); setFaces(null); }} /> : <button type="button" className="link-btn" onClick={() => setCam(true)}>Use camera face check (optional)</button>}
      <ErrorBox message={error} /><Success message={ok} />
      <div className="row" style={{ marginTop: '.75rem' }}>
        <button className="btn btn--primary" disabled={busy || !canIn} onClick={() => act('check-in')}>Check in</button>
        <button className="btn" disabled={busy || !canOut} onClick={() => act('check-out')}>Check out</button>
        <Link className="btn" to="/attendance">Request correction</Link>
      </div>
      {blocked && <p className="muted small">Today is {rec.status === 'on_leave' ? 'a day of approved leave' : `a ${rec.status}`}; attendance is not required.</p>}
      {hasIn && hasOut && <p className="muted small">You have completed today's attendance.</p>}
    </Card>
  );
}

function EmployeeDash() {
  const { data: d, loading, error, reload } = useFetch('/dashboard/employee');
  if (loading && !d) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  return (
    <div className="stack">
      <h1>Hello, {d.employee.name}</h1>
      <div className="grid grid--2">
        <CheckInCard today={d.today} onChange={reload} />
        <Card title="This week">
          <Stat label={`Hours worked (target ${d.weeklyTargetHours})`} value={d.hoursThisWeek} />
          <div className="bar" aria-hidden="true"><i style={{ width: `${Math.min(100, (d.hoursThisWeek / d.weeklyTargetHours) * 100)}%` }} /></div>
          <p className="muted small">Late arrivals this month: {d.lateCountThisMonth}</p>
        </Card>
      </div>
      <div className="grid grid--2">
        <Card title="Leave balances" actions={<Link to="/leave">Apply for leave</Link>}>
          <div className="table-wrap"><table><thead><tr><th>Type</th><th className="num">Quota</th><th className="num">Used</th><th className="num">Pending</th><th className="num">Remaining</th></tr></thead>
            <tbody>{d.leaveBalances.map((b) => <tr key={b.key}><td>{b.name}</td><td className="num">{b.quota ?? '∞'}</td><td className="num">{b.used}</td><td className="num">{b.pending}</td><td className="num">{b.remaining ?? '∞'}</td></tr>)}</tbody></table></div>
        </Card>
        <Card title="Latest payslip" actions={<Link to="/payroll">All payslips</Link>}>
          {d.lastPayslip ? <p>{d.lastPayslip.month}: net <strong>{fmtMoney(d.lastPayslip.net)}</strong> (gross {fmtMoney(d.lastPayslip.gross)})</p> : <Empty title="No payslip yet" hint="Payslips appear here once payroll is finalized." />}
        </Card>
      </div>
      <Card title="Announcements" actions={<Link to="/announcements">View all</Link>}>
        {d.announcements.length ? d.announcements.map((a) => <div key={a._id} className="announce"><strong>{a.title}</strong><p>{a.body}</p><small className="muted">{a.authorName} · {new Date(a.createdAt).toLocaleDateString()}</small></div>) : <Empty title="No announcements" />}
      </Card>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  return user.role === 'admin' ? <AdminDash /> : user.role === 'hr' ? <HrDash /> : <EmployeeDash />;
}

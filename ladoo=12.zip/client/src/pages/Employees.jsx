import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, download } from '../lib/api.js';
import { useAuth, useFetch, fmtMoney2 } from '../lib/auth.jsx';
import { Card, Spinner, ErrorBox, Success, Empty, Badge, Field, useForm, Pager, Confirm } from '../components/ui.jsx';

const GENDERS = ['', 'male', 'female', 'other'];

function Secret({ title, password, onClose }) {
  return <div className="alert alert--info" role="alert"><span>{title} Temporary password: <span className="secret">{password}</span> — shown once; the user must change it at first sign-in.</span><button className="btn btn--sm" onClick={onClose}>Dismiss</button></div>;
}

function CreateForm({ departments, designations, onCreated }) {
  const [v, bind, setV] = useForm({ code: '', firstName: '', lastName: '', email: '', phone: '', gender: '', department: '', designation: '', joiningDate: '', basicSalary: '', status: 'active' });
  const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const body = { ...v, basicSalary: Number(v.basicSalary) };
      for (const k of ['phone', 'gender', 'designation']) if (!body[k]) delete body[k];
      const r = await api('/employees', { method: 'POST', body });
      setV({ code: '', firstName: '', lastName: '', email: '', phone: '', gender: '', department: '', designation: '', joiningDate: '', basicSalary: '', status: 'active' });
      onCreated(r);
    } catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  return (
    <form className="form" onSubmit={submit}>
      <Field label="Employee code"><input required {...bind('code')} /></Field>
      <Field label="First name"><input required {...bind('firstName')} /></Field>
      <Field label="Last name"><input required {...bind('lastName')} /></Field>
      <Field label="Email"><input type="email" required {...bind('email')} /></Field>
      <Field label="Phone"><input {...bind('phone')} /></Field>
      <Field label="Gender"><select {...bind('gender')}>{GENDERS.map((g) => <option key={g} value={g}>{g || '—'}</option>)}</select></Field>
      <Field label="Department"><select required {...bind('department')}><option value="">Select…</option>{departments.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></Field>
      <Field label="Designation"><select {...bind('designation')}><option value="">—</option>{designations.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></Field>
      <Field label="Joining date"><input type="date" required {...bind('joiningDate')} /></Field>
      <Field label="Basic salary (monthly)"><input type="number" min="1" step="0.01" required {...bind('basicSalary')} /></Field>
      <Field label="Status"><select {...bind('status')}><option value="active">Active</option><option value="probation">Probation</option></select></Field>
      <div className="form__wide"><ErrorBox message={error} /><button className="btn btn--primary" disabled={busy}>{busy ? 'Saving…' : 'Create employee'}</button></div>
    </form>
  );
}

const SAMPLE_HEADER = 'code,firstName,lastName,email,department,designation,joiningDate,basicSalary,gender,phone';

function ImportCard({ onImported }) {
  const [csv, setCsv] = useState(''); const [res, setRes] = useState(null); const [busy, setBusy] = useState(false); const [error, setError] = useState('');
  const run = async (dry) => {
    setBusy(true); setError('');
    try { const r = await api(`/employees/import?dryRun=${dry}`, { method: 'POST', body: { csv } }); setRes(r); if (!dry && !r.errors.length) onImported(); }
    catch (e) { setError(e.message); setRes(null); } finally { setBusy(false); }
  };
  const onFile = async (e) => { const f = e.target.files[0]; if (!f) return; if (f.size > 900000) { setError('File is too large (max ~900 KB).'); return; } setCsv(await f.text()); setRes(null); setError(''); };
  return (
    <div className="stack">
      <p className="muted small">Columns: <code>{SAMPLE_HEADER}</code>. Departments and designations must already exist. Run a dry run first; nothing is saved unless every row is valid.</p>
      <input type="file" accept=".csv,text/csv" onChange={onFile} aria-label="CSV file" />
      <textarea rows={4} placeholder="…or paste CSV here" value={csv} onChange={(e) => { setCsv(e.target.value); setRes(null); }} aria-label="CSV text" />
      <ErrorBox message={error} />
      <div className="row"><button className="btn" disabled={busy || !csv.trim()} onClick={() => run(true)}>Dry run</button>
        <button className="btn btn--primary" disabled={busy || !csv.trim() || !res || !res.dryRun || res.errors.length > 0} onClick={() => run(false)}>Import {res?.dryRun ? res.validRows : ''} rows</button></div>
      {res && <div>
        <p>{res.dryRun ? 'Dry run' : 'Import'}: {res.validRows} of {res.totalRows} rows valid{res.errors.length ? `, ${res.errors.length} problem(s)` : ''}.</p>
        {res.message && <p className="muted">{res.message}</p>}
        {res.errors.length > 0 && <div className="table-wrap"><table><thead><tr><th>Row</th><th>Field</th><th>Problem</th></tr></thead><tbody>{res.errors.map((e, i) => <tr key={i}><td>{e.row}</td><td>{e.field}</td><td className="wrap">{e.reason}</td></tr>)}</tbody></table></div>}
        {!res.dryRun && res.created.length > 0 && <div className="table-wrap"><p><strong>Imported — record these temporary passwords now; they will not be shown again.</strong></p><table><thead><tr><th>Code</th><th>Email</th><th>Temporary password</th></tr></thead><tbody>{res.created.map((c) => <tr key={c.code}><td>{c.code}</td><td>{c.email}</td><td><span className="secret">{c.temporaryPassword}</span></td></tr>)}</tbody></table></div>}
      </div>}
    </div>
  );
}

export function Employees() {
  const { user } = useAuth();
  const [f, setF] = useState({ q: '', department: '', status: '', page: 1 });
  const [panel, setPanel] = useState(null);
  const [secret, setSecret] = useState(null); const [error, setError] = useState('');
  const set = (patch) => setF((x) => ({ ...x, page: 1, ...patch }));
  const { data, loading, error: loadErr, reload } = useFetch('/employees', { ...f, limit: 15 });
  const depts = useFetch('/departments'); const desigs = useFetch('/designations');
  const exportCsv = async () => { try { await download('/employees/export', 'employees.csv'); } catch (e) { setError(e.message); } };
  return (
    <div className="stack">
      <div className="row spread"><h1>Employees</h1>
        <div className="row"><button className="btn" onClick={exportCsv}>Export CSV</button><button className="btn" onClick={() => setPanel(panel === 'import' ? null : 'import')}>Import CSV</button><button className="btn btn--primary" onClick={() => setPanel(panel === 'new' ? null : 'new')}>Add employee</button></div></div>
      <ErrorBox message={error || loadErr} onRetry={reload} />
      {secret && <Secret title={secret.title} password={secret.password} onClose={() => setSecret(null)} />}
      {panel === 'new' && <Card title="New employee">
        {depts.data && !depts.data.items.length ? <p>No departments exist yet. {user.role === 'admin' ? <Link to="/settings">Create departments in Organization settings.</Link> : 'Ask an administrator to create departments first.'}</p>
          : <CreateForm departments={depts.data?.items || []} designations={desigs.data?.items || []} onCreated={(r) => { setSecret({ title: `${r.employee.firstName} ${r.employee.lastName} created.`, password: r.temporaryPassword }); setPanel(null); reload(); }} />}
      </Card>}
      {panel === 'import' && <Card title="Import employees from CSV"><ImportCard onImported={reload} /></Card>}
      <Card>
        <form className="row" onSubmit={(e) => e.preventDefault()} role="search">
          <label className="field"><span>Search</span><input type="search" placeholder="Name, code or email" value={f.q} onChange={(e) => set({ q: e.target.value })} /></label>
          <label className="field"><span>Department</span><select value={f.department} onChange={(e) => set({ department: e.target.value })}><option value="">All</option>{depts.data?.items.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></label>
          <label className="field"><span>Status</span><select value={f.status} onChange={(e) => set({ status: e.target.value })}><option value="">All</option><option value="active">Active</option><option value="probation">Probation</option><option value="exited">Exited</option></select></label>
        </form>
        {loading && !data ? <Spinner /> : data?.items.length ? <>
          <div className="table-wrap"><table><thead><tr><th>Code</th><th>Name</th><th>Email</th><th>Department</th><th>Designation</th><th>Joined</th><th>Status</th></tr></thead>
            <tbody>{data.items.map((e) => <tr key={e._id}><td>{e.code}</td><td><Link to={`/employees/${e._id}`}>{e.firstName} {e.lastName}</Link></td><td>{e.email}</td><td>{e.department?.name}</td><td>{e.designation?.name || '—'}</td><td>{e.joiningDate}</td><td><Badge status={e.status} /></td></tr>)}</tbody></table></div>
          <p className="muted small">{data.total} employee(s)</p>
          <Pager page={data.page} pages={data.pages} onPage={(p) => setF((x) => ({ ...x, page: p }))} />
        </> : <Empty title="No employees found" hint={f.q || f.department || f.status ? 'Try changing the filters.' : 'Add your first employee or import a CSV.'} />}
      </Card>
    </div>
  );
}

export function EmployeeDetail() {
  const { id } = useParams(); const { user } = useAuth();
  const staff = user.role !== 'employee'; const isAdmin = user.role === 'admin';
  const { data: e, loading, error, reload } = useFetch(`/employees/${id}`);
  const depts = useFetch('/departments'); const desigs = useFetch('/designations');
  const [edit, setEdit] = useState(false); const [v, bind, setV] = useForm({});
  const [msg, setMsg] = useState(''); const [err, setErr] = useState(''); const [secret, setSecret] = useState(null);
  if (loading && !e) return <Spinner />;
  if (error) return <ErrorBox message={error} onRetry={reload} />;
  const start = () => { setV({ firstName: e.firstName, lastName: e.lastName, email: e.email, phone: e.phone || '', address: e.address || '', gender: e.gender || '', department: e.department?._id, designation: e.designation?._id || '', joiningDate: e.joiningDate, basicSalary: e.basicSalary, status: e.status }); setEdit(true); setMsg(''); setErr(''); };
  const save = async (ev) => {
    ev.preventDefault(); setErr('');
    try {
      const body = { ...v, basicSalary: Number(v.basicSalary) }; if (!body.designation) delete body.designation;
      if (body.status === e.status) delete body.status; // unchanged status is not re-sent (exit is admin-only)
      await api(`/employees/${id}`, { method: 'PUT', body }); setEdit(false); setMsg('Employee updated.'); reload();
    } catch (x) { setErr(x.message); }
  };
  const act = async (a) => { setErr(''); try { const r = await api(`/employees/${id}/${a}`, { method: 'POST' }); setMsg(`Login ${a === 'reset-password' ? 'password reset' : a + 'd'}.`); if (r.temporaryPassword) setSecret(r.temporaryPassword); } catch (x) { setErr(x.message); } };
  const s = e.salaryStructure;
  return (
    <div className="stack">
      <div className="row spread"><h1>{e.firstName} {e.lastName} <Badge status={e.status} /></h1>{staff && <Link to="/employees">← All employees</Link>}</div>
      <ErrorBox message={err} /><Success message={msg} />
      {secret && <Secret title="Password reset." password={secret} onClose={() => setSecret(null)} />}
      <div className="grid grid--2">
        <Card title="Details" actions={staff && !edit && <button className="btn btn--sm" onClick={start}>Edit</button>}>
          {edit ? <form className="form" onSubmit={save}>
            <Field label="First name"><input required {...bind('firstName')} /></Field><Field label="Last name"><input required {...bind('lastName')} /></Field>
            <Field label="Email"><input type="email" required {...bind('email')} /></Field><Field label="Phone"><input {...bind('phone')} /></Field>
            <Field label="Gender"><select {...bind('gender')}>{GENDERS.map((g) => <option key={g} value={g}>{g || '—'}</option>)}</select></Field>
            <Field label="Department"><select required {...bind('department')}>{depts.data?.items.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></Field>
            <Field label="Designation"><select {...bind('designation')}><option value="">—</option>{desigs.data?.items.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}</select></Field>
            <Field label="Joining date"><input type="date" required {...bind('joiningDate')} /></Field>
            <Field label="Basic salary"><input type="number" min="1" step="0.01" required {...bind('basicSalary')} /></Field>
            <Field label="Status"><select {...bind('status')}><option value="active">Active</option><option value="probation">Probation</option>{(isAdmin || e.status === 'exited') && <option value="exited" disabled={!isAdmin}>Exited (admin only)</option>}</select></Field>
            <div className="form__wide row"><button className="btn btn--primary">Save</button><button type="button" className="btn" onClick={() => setEdit(false)}>Cancel</button></div>
          </form> : <dl className="stack">
            {[['Code', e.code], ['Email', e.email], ['Phone', e.phone], ['Gender', e.gender], ['Address', e.address], ['Department', e.department?.name], ['Designation', e.designation?.name], ['Joined', e.joiningDate], ['Exit date', e.exitDate]].filter(([, x]) => x).map(([k, x]) => <div key={k}><dt className="muted small">{k}</dt><dd style={{ margin: 0 }}>{x}</dd></div>)}
          </dl>}
        </Card>
        <Card title="Salary structure (monthly)">
          <table><tbody><tr><td>Basic</td><td className="num">{fmtMoney2(s.basic)}</td></tr><tr><td>House rent (40%)</td><td className="num">{fmtMoney2(s.hra)}</td></tr><tr><td>Medical (10%)</td><td className="num">{fmtMoney2(s.medical)}</td></tr><tr><th>Gross</th><td className="num"><strong>{fmtMoney2(s.gross)}</strong></td></tr></tbody></table>
          {isAdmin && e.user && <div className="row" style={{ marginTop: '1rem' }}>
            <Confirm className="btn btn--sm" message="Reset this employee's password? A new temporary password will be generated." onConfirm={() => act('reset-password')}>Reset password</Confirm>
            <Confirm message="Deactivate this login? The employee will be signed out and unable to sign in." onConfirm={() => act('deactivate')}>Deactivate login</Confirm>
            <button className="btn btn--sm" onClick={() => act('activate')}>Activate login</button>
          </div>}
        </Card>
      </div>
    </div>
  );
}

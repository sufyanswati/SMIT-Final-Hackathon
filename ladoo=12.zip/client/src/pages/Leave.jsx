import { useState } from 'react';
import { api } from '../lib/api.js';
import { useAuth, useFetch } from '../lib/auth.jsx';
import { Card, Spinner, ErrorBox, Success, Empty, Badge, Field, useForm, Pager, Confirm, AiLabel } from '../components/ui.jsx';

function Balances({ balances }) {
  return <div className="table-wrap"><table><thead><tr><th>Type</th><th className="num">Quota</th><th className="num">Used</th><th className="num">Pending</th><th className="num">Remaining</th></tr></thead>
    <tbody>{balances.map((b) => <tr key={b.key}><td>{b.name}</td><td className="num">{b.quota ?? '∞'}</td><td className="num">{b.used}</td><td className="num">{b.pending}</td><td className="num">{b.remaining ?? '∞'}</td></tr>)}</tbody></table></div>;
}

function ApplyForm({ types, onDone }) {
  const [v, bind, setV] = useForm({ type: types[0]?.key || '', start: '', end: '', reason: '' });
  const [text, setText] = useState(''); const [ai, setAi] = useState({ busy: false, note: '', error: '' });
  const [error, setError] = useState(''); const [ok, setOk] = useState('');
  const smart = async () => {
    setAi({ busy: true, note: '', error: '' });
    try { const r = await api('/leave/smart', { method: 'POST', body: { text } }); setV((x) => ({ ...x, ...r.prefill })); setAi({ busy: false, note: r.note, error: '' }); }
    catch (e) { setAi({ busy: false, note: '', error: e.message }); }
  };
  const submit = async (e) => {
    e.preventDefault(); setError(''); setOk('');
    try { const body = { ...v }; if (!body.reason) delete body.reason; await api('/leave', { method: 'POST', body }); setOk('Leave request submitted.'); setV({ type: types[0]?.key || '', start: '', end: '', reason: '' }); onDone(); }
    catch (err) { setError(err.message); }
  };
  return (
    <div className="stack">
      <div>
        <Field label="Describe your leave in plain words (optional, AI)" hint="Example: “sick leave tomorrow and Friday”. The form below is filled in for you to review; nothing is submitted automatically.">
          <div className="row"><input style={{ flex: 1 }} value={text} onChange={(e) => setText(e.target.value)} maxLength={500} /><button type="button" className="btn" disabled={ai.busy || text.trim().length < 3} onClick={smart}>{ai.busy ? 'Reading…' : 'Fill form'}</button></div>
        </Field>
        <ErrorBox message={ai.error} />{ai.note && <p className="small">{ai.note} <AiLabel /></p>}
      </div>
      <form className="form" onSubmit={submit}>
        <Field label="Leave type"><select required {...bind('type')}>{types.map((t) => <option key={t.key} value={t.key}>{t.name}</option>)}</select></Field>
        <Field label="First day"><input type="date" required {...bind('start')} /></Field>
        <Field label="Last day"><input type="date" required min={v.start} {...bind('end')} /></Field>
        <Field label="Reason"><input maxLength={500} {...bind('reason')} /></Field>
        <div className="form__wide"><ErrorBox message={error} /><Success message={ok} /><button className="btn btn--primary">Submit request</button></div>
      </form>
    </div>
  );
}

function EmployeeView() {
  const { settings } = useAuth(); const [page, setPage] = useState(1); const [err, setErr] = useState('');
  const bal = useFetch('/leave/balance'); const mine = useFetch('/leave/mine', { page, limit: 10 });
  const refresh = () => { bal.reload(); mine.reload(); };
  const cancel = async (id) => { setErr(''); try { await api(`/leave/${id}/cancel`, { method: 'POST' }); refresh(); } catch (e) { setErr(e.message); } };
  return (
    <div className="stack">
      <h1>Leave</h1>
      <Card title="Balances (this year)">{bal.loading && !bal.data ? <Spinner /> : <><ErrorBox message={bal.error} onRetry={bal.reload} />{bal.data && <Balances balances={bal.data.balances} />}</>}</Card>
      <Card title="Apply for leave">{settings ? <ApplyForm types={settings.leaveTypes} onDone={refresh} /> : <Spinner />}</Card>
      <Card title="My requests">
        <ErrorBox message={err || mine.error} onRetry={mine.reload} />
        {mine.loading && !mine.data ? <Spinner /> : mine.data?.items.length ? <>
          <div className="table-wrap"><table><thead><tr><th>Type</th><th>From</th><th>To</th><th className="num">Days</th><th>Status</th><th>Reviewer comment</th><th /></tr></thead>
            <tbody>{mine.data.items.map((l) => <tr key={l._id}><td>{l.type}</td><td>{l.start}</td><td>{l.end}</td><td className="num">{l.days}</td><td><Badge status={l.status} /></td><td className="wrap">{l.comment || '—'}</td>
              <td>{['pending', 'approved'].includes(l.status) && <Confirm message="Cancel this leave request?" onConfirm={() => cancel(l._id)}>Cancel</Confirm>}</td></tr>)}</tbody></table></div>
          <Pager page={page} pages={Math.ceil(mine.data.total / 10)} onPage={setPage} />
        </> : <Empty title="No leave requests yet" />}
      </Card>
    </div>
  );
}

function StaffView() {
  const { user } = useAuth(); const canDecide = user.role === 'hr';
  const [status, setStatus] = useState('pending'); const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useFetch('/leave', { status, page, limit: 15 });
  const [comment, setComment] = useState({}); const [err, setErr] = useState('');
  const decide = async (id, approve) => {
    setErr('');
    if (!approve && !(comment[id] || '').trim()) { setErr('Enter a comment before rejecting a request.'); return; }
    try { await api(`/leave/${id}/decision`, { method: 'POST', body: { approve, comment: comment[id]?.trim() || undefined } }); reload(); } catch (e) { setErr(e.message); }
  };
  return (
    <div className="stack">
      <div className="row spread"><h1>Leave requests</h1>
        <label className="field"><span>Status</span><select value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}><option value="">All</option><option value="pending">Pending</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="cancelled">Cancelled</option></select></label></div>
      <ErrorBox message={err || error} onRetry={reload} />
      <Card>
        {loading && !data ? <Spinner /> : data?.items.length ? <>
          <div className="table-wrap"><table><thead><tr><th>Employee</th><th>Type</th><th>From</th><th>To</th><th className="num">Days</th><th>Reason</th><th>Status</th>{canDecide && <th>Decision</th>}</tr></thead>
            <tbody>{data.items.map((l) => <tr key={l._id}><td>{l.employeeName} <span className="muted small">{l.employee?.code}</span></td><td>{l.type}</td><td>{l.start}</td><td>{l.end}</td><td className="num">{l.days}</td><td className="wrap">{l.reason || '—'}{l.comment && <div className="muted small">Reviewer: {l.comment}</div>}</td><td><Badge status={l.status} /></td>
              {canDecide && <td>{l.status === 'pending' && <div className="row"><input aria-label="Comment" placeholder="Comment (required to reject)" value={comment[l._id] || ''} onChange={(e) => setComment({ ...comment, [l._id]: e.target.value })} style={{ width: 190 }} /><button className="btn btn--sm btn--primary" onClick={() => decide(l._id, true)}>Approve</button><button className="btn btn--sm btn--danger" onClick={() => decide(l._id, false)}>Reject</button></div>}</td>}</tr>)}</tbody></table></div>
          <Pager page={page} pages={Math.ceil(data.total / 15)} onPage={setPage} />
        </> : <Empty title="No leave requests" hint={status ? 'Nothing matches this status.' : undefined} />}
      </Card>
      {!canDecide && <p className="muted small">Approvals are performed by HR; administrators have read-only access.</p>}
    </div>
  );
}

export default function Leave() { const { user } = useAuth(); return user.role === 'employee' ? <EmployeeView /> : <StaffView />; }

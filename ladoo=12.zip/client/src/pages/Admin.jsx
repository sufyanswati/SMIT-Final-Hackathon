import { Fragment, useState } from 'react';
import { api } from '../lib/api.js';
import { useAuth, useFetch } from '../lib/auth.jsx';
import { Card, Spinner, ErrorBox, Success, Empty, Badge, Field, useForm, Pager, Confirm } from '../components/ui.jsx';

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function NameList({ path, label }) {
  const { data, loading, error, reload } = useFetch(path); const [name, setName] = useState(''); const [err, setErr] = useState('');
  const add = async (e) => { e.preventDefault(); setErr(''); try { await api(path, { method: 'POST', body: { name } }); setName(''); reload(); } catch (x) { setErr(x.message); } };
  const del = async (id) => { setErr(''); try { await api(`${path}/${id}`, { method: 'DELETE' }); reload(); } catch (x) { setErr(x.message); } };
  return (
    <Card title={`${label}s`}>
      <ErrorBox message={err || error} />
      <form className="row" onSubmit={add}><input aria-label={`New ${label.toLowerCase()} name`} placeholder={`New ${label.toLowerCase()}`} required minLength={2} value={name} onChange={(e) => setName(e.target.value)} /><button className="btn btn--primary">Add</button></form>
      {loading && !data ? <Spinner /> : data?.items.length ? <ul>{data.items.map((d) => <li key={d._id} className="row spread" style={{ padding: '.3rem 0' }}>{d.name}<Confirm message={`Delete ${d.name}?`} onConfirm={() => del(d._id)}>Delete</Confirm></li>)}</ul> : <Empty title={`No ${label.toLowerCase()}s yet`} />}
    </Card>
  );
}

export function Settings() {
  const { settings } = useAuth();
  return settings ? <SettingsForm settings={settings} /> : <div className="stack"><h1>Organization settings</h1><ErrorBox message="Settings could not be loaded. Reload the page to try again." /></div>;
}

function SettingsForm({ settings }) {
  const { refreshSettings } = useAuth();
  const [v, setV] = useState(() => ({ ...settings, weekendDays: settings.weekendDays || [], leaveTypes: settings.leaveTypes || [], holidays: settings.holidays || [], office: { lat: '', lng: '', radiusMeters: 100, ...(settings.office || {}) } }));
  const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  const set = (k, val) => setV((x) => ({ ...x, [k]: val }));
  const setLt = (i, k, val) => set('leaveTypes', v.leaveTypes.map((t, j) => (j === i ? { ...t, [k]: val } : t)));
  const save = async (e) => {
    e.preventDefault(); setErr(''); setMsg('');
    try {
      const num = (x) => (x === '' || x == null ? undefined : Number(x));
      const body = { companyName: v.companyName, timezone: v.timezone, officeStart: v.officeStart, graceMinutes: Number(v.graceMinutes), weekendDays: v.weekendDays, requireLocation: !!v.requireLocation,
        leaveTypes: v.leaveTypes.map((t) => ({ key: t.key, name: t.name, quota: t.quota === '' || t.quota == null ? null : Number(t.quota), paid: !!t.paid })), holidays: v.holidays.map((h) => ({ date: h.date, name: h.name })) };
      if (num(v.office.lat) != null && num(v.office.lng) != null) body.office = { lat: num(v.office.lat), lng: num(v.office.lng), radiusMeters: Number(v.office.radiusMeters) };
      else if (v.requireLocation) throw new Error('Set the office latitude and longitude before requiring location for attendance.');
      await api('/settings', { method: 'PUT', body }); await refreshSettings(); setMsg('Settings saved.');
    } catch (x) { setErr(x.message); }
  };
  const [h, setH] = useState({ date: '', name: '' });
  return (
    <div className="stack"><h1>Organization settings</h1>
      <form className="stack" onSubmit={save}>
        <Card title="General & attendance rules"><div className="form">
          <Field label="Company name"><input required minLength={2} value={v.companyName} onChange={(e) => set('companyName', e.target.value)} /></Field>
          <Field label="Time zone (IANA)"><input required value={v.timezone} onChange={(e) => set('timezone', e.target.value)} /></Field>
          <Field label="Office start"><input type="time" required value={v.officeStart} onChange={(e) => set('officeStart', e.target.value)} /></Field>
          <Field label="Grace minutes"><input type="number" min="0" max="240" required value={v.graceMinutes} onChange={(e) => set('graceMinutes', e.target.value)} /></Field>
          <div className="field"><span>Weekend days</span><div className="row">{DAYS.map((d, i) => <label key={d} className="checkline"><input type="checkbox" checked={v.weekendDays.includes(i)} onChange={(e) => set('weekendDays', e.target.checked ? [...v.weekendDays, i] : v.weekendDays.filter((x) => x !== i))} />{d}</label>)}</div></div>
          <Field label="Office latitude"><input type="number" step="any" value={v.office.lat ?? ''} onChange={(e) => set('office', { ...v.office, lat: e.target.value })} /></Field>
          <Field label="Office longitude"><input type="number" step="any" value={v.office.lng ?? ''} onChange={(e) => set('office', { ...v.office, lng: e.target.value })} /></Field>
          <Field label="Geofence radius (m)"><input type="number" min="10" max="5000" value={v.office.radiusMeters ?? 100} onChange={(e) => set('office', { ...v.office, radiusMeters: e.target.value })} /></Field>
          <label className="checkline"><input type="checkbox" checked={!!v.requireLocation} onChange={(e) => set('requireLocation', e.target.checked)} />Require location for check-in/out</label>
        </div></Card>
        <Card title="Leave types"><div className="table-wrap"><table><thead><tr><th>Key</th><th>Name</th><th>Annual quota (blank = unlimited)</th><th>Paid</th></tr></thead>
          <tbody>{v.leaveTypes.map((t, i) => <tr key={t.key}><td>{t.key}</td><td><input aria-label="Name" value={t.name} onChange={(e) => setLt(i, 'name', e.target.value)} /></td><td><input aria-label="Quota" type="number" min="0" value={t.quota ?? ''} onChange={(e) => setLt(i, 'quota', e.target.value)} /></td><td><input aria-label="Paid" type="checkbox" checked={!!t.paid} onChange={(e) => setLt(i, 'paid', e.target.checked)} /></td></tr>)}</tbody></table></div></Card>
        <Card title="Public holidays">
          {v.holidays.length ? <ul>{[...v.holidays].sort((a, b) => a.date.localeCompare(b.date)).map((x) => <li key={x.date} className="row spread">{x.date} — {x.name}<button type="button" className="btn btn--sm" onClick={() => set('holidays', v.holidays.filter((y) => y.date !== x.date))}>Remove</button></li>)}</ul> : <p className="muted">No holidays configured.</p>}
          <div className="row"><input type="date" aria-label="Holiday date" value={h.date} onChange={(e) => setH({ ...h, date: e.target.value })} /><input aria-label="Holiday name" placeholder="Name" value={h.name} onChange={(e) => setH({ ...h, name: e.target.value })} />
            <button type="button" className="btn" disabled={!h.date || h.name.trim().length < 2 || v.holidays.some((y) => y.date === h.date)} onClick={() => { set('holidays', [...v.holidays, { date: h.date, name: h.name.trim() }]); setH({ date: '', name: '' }); }}>Add holiday</button></div>
        </Card>
        <ErrorBox message={err} /><Success message={msg} />
        <div><button className="btn btn--primary">Save settings</button></div>
      </form>
      <div className="grid grid--2"><NameList path="/departments" label="Department" /><NameList path="/designations" label="Designation" /></div>
    </div>
  );
}

export function Users() {
  const { user } = useAuth();
  const { data, loading, error, reload } = useFetch('/users'); const [v, bind, setV] = useForm({ name: '', email: '', role: 'hr' });
  const [err, setErr] = useState(''); const [secret, setSecret] = useState(null);
  const create = async (e) => { e.preventDefault(); setErr(''); try { const r = await api('/users', { method: 'POST', body: v }); setSecret({ who: r.user.email, pw: r.temporaryPassword }); setV({ name: '', email: '', role: 'hr' }); reload(); } catch (x) { setErr(x.message); } };
  const act = async (id, a, email) => { setErr(''); try { const r = await api(`/users/${id}/${a}`, { method: 'POST' }); if (r.temporaryPassword) setSecret({ who: email, pw: r.temporaryPassword }); reload(); } catch (x) { setErr(x.message); } };
  return (
    <div className="stack"><h1>Accounts</h1>
      <ErrorBox message={err || error} onRetry={reload} />
      {secret && <div className="alert alert--info" role="alert"><span>Temporary password for {secret.who}: <span className="secret">{secret.pw}</span> — shown once.</span><button className="btn btn--sm" onClick={() => setSecret(null)}>Dismiss</button></div>}
      <Card title="Create HR or admin account"><form className="form" onSubmit={create}>
        <Field label="Name"><input required minLength={2} {...bind('name')} /></Field><Field label="Email"><input type="email" required {...bind('email')} /></Field>
        <Field label="Role"><select {...bind('role')}><option value="hr">HR</option><option value="admin">Admin</option></select></Field><div><button className="btn btn--primary">Create</button></div></form>
        <p className="muted small">Employee accounts are created from the Employees page.</p></Card>
      <Card title="All accounts">{loading && !data ? <Spinner /> : <div className="table-wrap"><table><thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th /></tr></thead>
        <tbody>{data?.items.map((u) => <tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td><span className="pill">{u.role}</span></td><td><Badge status={u.active ? 'active' : 'exited'} /></td>
          <td className="row">{u.id !== user.id && <>{u.active ? <Confirm message={`Deactivate ${u.email}?`} onConfirm={() => act(u.id, 'deactivate', u.email)}>Deactivate</Confirm> : <button className="btn btn--sm" onClick={() => act(u.id, 'activate', u.email)}>Activate</button>}</>}
            <Confirm className="btn btn--sm" message={`Reset password for ${u.email}?`} onConfirm={() => act(u.id, 'reset-password', u.email)}>Reset password</Confirm></td></tr>)}</tbody></table></div>}</Card>
    </div>
  );
}

export function Audit() {
  const [action, setAction] = useState(''); const [page, setPage] = useState(1);
  const { data, loading, error, reload } = useFetch('/audit-logs', { action, page, limit: 25 });
  const [open, setOpen] = useState(null);
  return (
    <div className="stack"><div className="row spread"><h1>Audit log</h1><label className="field"><span>Action prefix</span><input placeholder="e.g. leave, payroll" value={action} onChange={(e) => { setAction(e.target.value); setPage(1); }} /></label></div>
      <ErrorBox message={error} onRetry={reload} />
      <Card>{loading && !data ? <Spinner /> : data?.items.length ? <><div className="table-wrap"><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Entity</th><th /></tr></thead>
        <tbody>{data.items.map((a) => <Fragment key={a._id}><tr><td>{new Date(a.createdAt).toLocaleString()}</td><td>{a.actorName || '—'}</td><td>{a.action}</td><td>{a.entity} {a.entityId && <span className="muted small">{String(a.entityId).slice(-6)}</span>}</td><td><button className="btn btn--sm" aria-expanded={open === a._id} onClick={() => setOpen(open === a._id ? null : a._id)}>Details</button></td></tr>
          {open === a._id && <tr><td colSpan={5} className="wrap"><pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{JSON.stringify({ before: a.before, after: a.after }, null, 2)}</pre></td></tr>}</Fragment>)}</tbody></table></div>
        <Pager page={page} pages={Math.ceil(data.total / 25)} onPage={setPage} /></> : <Empty title="No audit entries" />}</Card>
    </div>
  );
}

export function Announcements() {
  const { user } = useAuth(); const staff = user.role !== 'employee';
  const { data, loading, error, reload } = useFetch('/announcements'); const [v, bind, setV] = useForm({ title: '', body: '' }); const [err, setErr] = useState('');
  const post = async (e) => { e.preventDefault(); setErr(''); try { await api('/announcements', { method: 'POST', body: v }); setV({ title: '', body: '' }); reload(); } catch (x) { setErr(x.message); } };
  return (
    <div className="stack"><h1>Announcements</h1>
      {staff && <Card title="Post an announcement"><form className="stack" onSubmit={post}><Field label="Title"><input required minLength={2} maxLength={120} {...bind('title')} /></Field><Field label="Message"><textarea required rows={4} minLength={2} maxLength={2000} {...bind('body')} /></Field><ErrorBox message={err} /><div><button className="btn btn--primary">Post</button></div></form></Card>}
      <ErrorBox message={error} onRetry={reload} />
      <Card>{loading && !data ? <Spinner /> : data?.items.length ? data.items.map((a) => <div key={a._id} className="announce"><h3>{a.title}</h3><p>{a.body}</p><small className="muted">{a.authorName} · {new Date(a.createdAt).toLocaleString()}</small></div>) : <Empty title="No announcements yet" />}</Card>
    </div>
  );
}

export function Profile() {
  const { data: e, loading, error, reload } = useFetch('/employees/me'); const [v, bind, setV] = useForm({}); const [edit, setEdit] = useState(false); const [msg, setMsg] = useState(''); const [err, setErr] = useState('');
  if (loading && !e) return <Spinner />; if (error) return <ErrorBox message={error} onRetry={reload} />;
  const save = async (ev) => { ev.preventDefault(); setErr(''); try { await api('/employees/me', { method: 'PUT', body: { phone: v.phone || '', address: v.address || '' } }); setEdit(false); setMsg('Profile updated.'); reload(); } catch (x) { setErr(x.message); } };
  return (
    <div className="stack"><h1>My profile</h1><Success message={msg} /><ErrorBox message={err} />
      <Card title={`${e.firstName} ${e.lastName}`} actions={!edit && <button className="btn btn--sm" onClick={() => { setV({ phone: e.phone || '', address: e.address || '' }); setEdit(true); setMsg(''); }}>Edit contact details</button>}>
        <dl className="stack">{[['Employee code', e.code], ['Email', e.email], ['Department', e.department?.name], ['Designation', e.designation?.name], ['Joined', e.joiningDate]].map(([k, x]) => <div key={k}><dt className="muted small">{k}</dt><dd style={{ margin: 0 }}>{x || '—'}</dd></div>)}</dl>
        {edit ? <form className="form" onSubmit={save}><Field label="Phone"><input maxLength={30} {...bind('phone')} /></Field><Field label="Address"><input maxLength={300} {...bind('address')} /></Field><div className="row"><button className="btn btn--primary">Save</button><button type="button" className="btn" onClick={() => setEdit(false)}>Cancel</button></div></form>
          : <dl className="stack" style={{ marginTop: '1rem' }}>{[['Phone', e.phone], ['Address', e.address]].map(([k, x]) => <div key={k}><dt className="muted small">{k}</dt><dd style={{ margin: 0 }}>{x || '—'}</dd></div>)}</dl>}
      </Card>
      <p className="muted small">Name, department and salary can only be changed by HR or an administrator.</p>
    </div>
  );
}

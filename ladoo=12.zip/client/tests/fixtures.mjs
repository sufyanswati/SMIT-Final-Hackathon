// Hand-built API response fixtures, written from the shapes the server code returns. They are NOT captured from a
// running server, so they can only prove the UI tolerates these shapes, not that the server really returns them.
const id = (n) => String(n).padStart(24, '0');
const dept = [{ _id: id(1), name: 'Engineering' }, { _id: id(2), name: 'Sales' }];
const desig = [{ _id: id(3), name: 'Developer' }];
const emp = (n, extra = {}) => ({ _id: id(10 + n), code: `E00${n}`, firstName: `First${n}`, lastName: 'Last', email: `e${n}@x.test`, department: dept[0], designation: desig[0], joiningDate: '2026-01-05', status: 'active', basicSalary: 100000, gender: 'female', ...extra });
const settings = { companyName: 'Acme', timezone: 'Asia/Karachi', officeStart: '09:00', graceMinutes: 15, weekendDays: [0, 6], office: { radiusMeters: 100 }, requireLocation: false,
  leaveTypes: [{ key: 'annual', name: 'Annual', quota: 14, paid: true }, { key: 'unpaid', name: 'Unpaid', quota: null, paid: false }], holidays: [{ date: '2026-03-23', name: 'Pakistan Day' }] };
const bal = [{ key: 'annual', name: 'Annual', quota: 14, used: 2, pending: 1, remaining: 11 }, { key: 'unpaid', name: 'Unpaid', quota: null, used: 0, pending: 0, remaining: null }];
const sal = { basic: 100000, hra: 40000, medical: 10000, gross: 150000 };
const day = (date, status, extra = {}) => ({ date, status, checkIn: null, checkOut: null, workedMinutes: 0, ...extra });
const run = { _id: id(50), month: '2026-02', status: 'draft', totals: { gross: 150000, deduction: 0, tax: 20000, net: 130000 }, items: [{ employee: id(11), code: 'E001', name: 'First1 Last', department: 'Engineering', earnedGross: 150000, absent: 0, unpaidLeave: 0, halfDays: 0, deduction: 0, tax: 20000, net: 130000 }] };
const adminDash = { filters: { from: '2026-01-01', to: '2026-03-02', department: undefined }, headcount: 3, attritionYtd: { exits: 1, rate: 25 }, payrollCost: { month: '2026-02', gross: 450000, net: 380000 }, payrollTrend: [{ month: '2026-02', gross: 450000, net: 380000 }], averageGrossSalary: 150000,
  headcountByDepartment: [{ department: 'Engineering', count: 3 }], payrollCostByDepartment: [{ department: 'Engineering', gross: 450000 }], averageGrossByDepartment: [{ department: 'Engineering', average: 150000 }], gender: { male: 1, female: 2, other: 0, unknown: 0 }, tenure: { '<1y': 3, '1-3y': 0, '3-5y': 0, '5y+': 0 },
  audit: [{ _id: id(60), createdAt: '2026-03-02T04:00:00Z', actorName: 'Root', action: 'setup.initialize' }] };
const hrDash = { filters: { from: '2026-02-01', to: '2026-03-02' }, headcount: 3, today: { present: 2, onLeave: 1, late: 1, absentSoFar: 0 }, pendingApprovals: { leave: 1, corrections: 2, total: 3 }, attendanceRate: 91.5, latePercentage: 10, absenteeismRate: 4.2,
  attendanceTrend: [{ date: '2026-03-02', attendanceRate: 90, present: 2, absent: 0 }], absenteeismByDepartment: [{ department: 'Engineering', absenteeismRate: 4.2 }], leaveByType: [{ type: 'Annual', approvedDays: 2, utilization: 4.76 }, { type: 'Unpaid', approvedDays: 0, utilization: null }], topLateComers: [{ code: 'E001', name: 'First1 Last', department: 'Engineering', lateCount: 2 }] };
const empDash = { employee: { name: 'First1 Last', code: 'E001' }, today: day('2026-03-02', 'present', { checkIn: '2026-03-02T04:10:00Z' }), todayDate: '2026-03-02', hoursThisWeek: 8.5, weeklyTargetHours: 40, lateCountThisMonth: 0, leaveBalances: bal, lastPayslip: { month: '2026-02', net: 130000, gross: 150000 }, announcements: [{ _id: id(70), title: 'Eid holiday', body: 'Office closed', authorName: 'HR', createdAt: '2026-03-01T00:00:00Z' }] };

export const full = {
  '/departments': { items: dept }, '/designations': { items: desig }, '/notifications': { items: [{ _id: id(80), message: 'Payslip ready', createdAt: '2026-03-01T00:00:00Z' }], unread: 1 },
  '/dashboard/admin': adminDash, '/dashboard/hr': hrDash, '/dashboard/employee': empDash,
  '/employees': { items: [emp(1), emp(2, { status: 'exited', exitDate: '2026-02-10' })], total: 2, page: 1, pages: 1 },
  '/employees/emp1': { ...emp(1), user: id(90), salaryStructure: sal }, '/employees/me': { ...emp(1), phone: '123', address: 'Karachi' },
  '/attendance/me': { today: '2026-03-02', summary: { present: 1, late: 0, absent: 0, on_leave: 0, half_day: 0, missing_checkout: 0 }, days: [day('2026-03-01', 'weekend'), day('2026-03-02', 'present', { checkIn: '2026-03-02T04:10:00Z', checkOut: '2026-03-02T12:30:00Z', workedMinutes: 500 }), day('2026-03-03', 'future')] },
  '/attendance/board': { date: '2026-03-02', items: [{ employee: id(11), code: 'E001', name: 'First1 Last', department: 'Engineering', status: 'late', checkIn: '2026-03-02T04:30:00Z', checkOut: null }] },
  '/attendance/summary': { from: '2026-03-01', to: '2026-03-02', attendanceRate: 90, latePercentage: 10, absenteeismRate: 0, totals: {}, employees: [{ employee: id(11), code: 'E001', name: 'First1 Last', department: 'Engineering', present: 1, late: 1, half_day: 0, absent: 0, on_leave: 0 }] },
  '/attendance/corrections': { items: [{ _id: id(30), employee: { firstName: 'First1', lastName: 'Last' }, date: '2026-03-01', checkIn: '09:00', checkOut: '17:00', reason: 'Forgot to check in', status: 'pending' }] },
  '/leave/balance': { balances: bal }, '/leave/mine': { items: [{ _id: id(40), type: 'annual', start: '2026-03-09', end: '2026-03-10', days: 2, status: 'pending', comment: '' }], total: 1 },
  '/leave': { items: [{ _id: id(40), employeeName: 'First1 Last', employee: { code: 'E001' }, type: 'annual', start: '2026-03-09', end: '2026-03-10', days: 2, status: 'pending', reason: 'Trip' }], total: 1 },
  '/payroll': { items: [{ _id: id(50), month: '2026-02', status: 'draft', totals: run.totals }] }, '/payroll/mine': { items: [{ runId: id(50), month: '2026-02', gross: 150000, net: 130000 }] },
  '/users': { items: [{ id: id(90), name: 'Root', email: 'admin@x.test', role: 'admin', active: true }, { id: id(91), name: 'Hana', email: 'hr@x.test', role: 'hr', active: false }] },
  '/audit-logs': { items: [{ _id: id(61), createdAt: '2026-03-02T04:00:00Z', actorName: 'Root', action: 'user.create', entity: 'User', entityId: id(91), before: null, after: { role: 'hr' } }], total: 1, page: 1 },
  '/announcements': { items: [{ _id: id(70), title: 'Eid holiday', body: 'Office closed', authorName: 'HR', createdAt: '2026-03-01T00:00:00Z' }] },
};

// Same endpoints with nothing in them: the first-run (empty system) experience.
export const empty = {
  ...full,
  '/employees': { items: [], total: 0, page: 1, pages: 0 }, '/departments': { items: [] }, '/designations': { items: [] }, '/notifications': { items: [], unread: 0 },
  '/dashboard/admin': { ...adminDash, headcount: 0, attritionYtd: { exits: 0, rate: 0 }, payrollCost: null, payrollTrend: [], averageGrossSalary: 0, headcountByDepartment: [], payrollCostByDepartment: [], averageGrossByDepartment: [], gender: { male: 0, female: 0, other: 0, unknown: 0 }, tenure: { '<1y': 0, '1-3y': 0, '3-5y': 0, '5y+': 0 }, audit: [] },
  '/dashboard/hr': { ...hrDash, headcount: 0, today: { present: 0, onLeave: 0, late: 0, absentSoFar: 0 }, pendingApprovals: { leave: 0, corrections: 0, total: 0 }, attendanceTrend: [], absenteeismByDepartment: [], leaveByType: [], topLateComers: [] },
  '/dashboard/employee': { ...empDash, today: null, hoursThisWeek: 0, lastPayslip: null, announcements: [] },
  '/attendance/me': { today: '2026-03-02', summary: { present: 0, late: 0, absent: 0, on_leave: 0, half_day: 0, missing_checkout: 0 }, days: [] },
  '/attendance/board': { date: '2026-03-02', items: [] }, '/attendance/summary': { from: '2026-03-01', to: '2026-03-02', attendanceRate: 0, latePercentage: 0, absenteeismRate: 0, totals: {}, employees: [] }, '/attendance/corrections': { items: [] },
  '/leave/mine': { items: [], total: 0 }, '/leave': { items: [], total: 0 }, '/payroll': { items: [] }, '/payroll/mine': { items: [] }, '/audit-logs': { items: [], total: 0, page: 1 }, '/announcements': { items: [] },
};
export { settings, run };

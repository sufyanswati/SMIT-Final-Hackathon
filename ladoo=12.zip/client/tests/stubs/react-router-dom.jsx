// Test-only stand-in for react-router-dom so pages can be server-rendered without a DOM.
export const Link = ({ to, children, ...p }) => <a href={to} {...p}>{children}</a>;
export const NavLink = ({ to, children, className, ...p }) => <a href={to} className={typeof className === 'function' ? className({ isActive: false }) : className} {...p}>{children}</a>;
export const useNavigate = () => () => {};
export const useParams = () => ({ id: 'emp1' });
export const Navigate = () => null;
export const Routes = ({ children }) => <>{children}</>;
export const Route = () => null;
export const BrowserRouter = ({ children }) => <>{children}</>;

// Test-only stand-in for recharts: renders the data it is given as JSON so tests can see the chart received data.
const mk = (name) => ({ children, data }) => <div data-chart={name} data-points={data ? data.length : undefined}>{children}</div>;
export const ResponsiveContainer = mk('container'); export const BarChart = mk('bar'); export const LineChart = mk('line'); export const PieChart = mk('pie');
export const Bar = () => null; export const Line = () => null; export const Pie = mk('slice'); export const Cell = () => null;
export const XAxis = () => null; export const YAxis = () => null; export const Tooltip = () => null; export const CartesianGrid = () => null; export const Legend = () => null;

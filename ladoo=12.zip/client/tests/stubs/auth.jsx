// Test-only replacement for src/lib/auth.jsx: serves canned data synchronously from globalThis.__fx.
export * from '../../src/lib/format.js';
export const useAuth = () => globalThis.__auth;
export const AuthProvider = ({ children }) => children;
export function useFetch(path) {
  const fx = globalThis.__fx; const data = Object.prototype.hasOwnProperty.call(fx, path) ? fx[path] : null;
  globalThis.__fetched.add(path);
  return { data, loading: data == null, error: data == null ? `NO FIXTURE FOR ${path}` : null, reload() {} };
}

// Server-side render smoke test. Bundles the real client pages with esbuild, swapping ONLY react-router-dom, recharts
// and lib/auth.jsx for test stubs, then renders each page for each role against fixtures (full and empty).
// It proves: the code compiles, imports resolve, and render-time code does not throw on these shapes.
// It does NOT prove: layout, CSS, effects, click handlers, real API behaviour, or the Vite production build.
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import fs from 'node:fs';
import assert from 'node:assert/strict';

const { build } = createRequire(import.meta.url)('esbuild'); // require() so NODE_PATH works offline; after `npm install` it resolves from node_modules
const here = path.dirname(fileURLToPath(import.meta.url));
const out = path.join(fs.mkdtempSync(path.join(process.env.TMPDIR || '/tmp', 'ladoo-smoke-')), 'bundle.mjs');
const stub = (re, file) => ({ filter: re, file: path.join(here, 'stubs', file) });
await build({
  entryPoints: [path.join(here, 'smoke-entry.jsx')], bundle: true, format: 'esm', platform: 'node', outfile: out, jsx: 'automatic', nodePaths: (process.env.NODE_PATH || '').split(path.delimiter).filter(Boolean), logLevel: 'error', nodePaths: (process.env.NODE_PATH || '').split(path.delimiter).filter(Boolean),
  banner: { js: "import { createRequire as __cr } from 'module'; const require = __cr(import.meta.url);" },
  plugins: [{ name: 'stubs', setup(b) {
    b.onResolve({ filter: /^react-router-dom$/ }, () => ({ path: path.join(here, 'stubs/react-router-dom.jsx') }));
    b.onResolve({ filter: /^recharts$/ }, () => ({ path: path.join(here, 'stubs/recharts.jsx') }));
    b.onResolve({ filter: /lib\/auth\.jsx$/ }, () => ({ path: path.join(here, 'stubs/auth.jsx') }));
    b.onLoad({ filter: /\.css$/ }, () => ({ contents: '', loader: 'js' }));
  } }],
  define: { 'import.meta.env.VITE_API_URL': '""' },
});

// Minimal browser globals used during render.
const store = () => { const m = new Map(); return { getItem: (k) => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: (k) => m.delete(k) }; };
globalThis.window = Object.assign(globalThis, { scrollY: 0, addEventListener() {}, removeEventListener() {}, matchMedia: () => ({ matches: false }), localStorage: store(), sessionStorage: store() });
const { render } = await import(pathToFileURL(out).href);
const { full, empty, settings } = await import('./fixtures.mjs');

const users = { admin: { id: 'a', name: 'Root', email: 'admin@x.test', role: 'admin' }, hr: { id: 'h', name: 'Hana', email: 'hr@x.test', role: 'hr' }, employee: { id: 'e', name: 'First1 Last', email: 'e1@x.test', role: 'employee' } };
const cases = [ // [page, role, text that must appear in the full-data render]
  ['Dashboard', 'admin', 'Admin dashboard'], ['Dashboard', 'hr', 'HR dashboard'], ['Dashboard', 'employee', 'Check in'],
  ['Employees', 'hr', 'First1'], ['Employees', 'admin', 'First1'], ['EmployeeDetail', 'admin', 'Reset password'], ['EmployeeDetail', 'hr', 'Salary structure'], ['EmployeeDetail', 'employee', 'Salary structure'],
  ['Attendance', 'employee', 'My attendance'], ['Attendance', 'hr', 'Daily board'], ['Attendance', 'admin', 'Daily board'],
  ['Leave', 'employee', 'Apply for leave'], ['Leave', 'hr', 'Approve'], ['Leave', 'admin', 'read-only'],
  ['Payroll', 'employee', 'Download PDF'], ['Payroll', 'hr', 'Prepare a draft'], ['Payroll', 'admin', 'Payroll runs'],
  ['Settings', 'admin', 'Organization settings'], ['Users', 'admin', 'Accounts'], ['Audit', 'admin', 'user.create'], ['Announcements', 'hr', 'Post an announcement'], ['Announcements', 'employee', 'Eid holiday'], ['Profile', 'employee', 'My profile'],
  ['Navbar', 'admin', 'Audit log'], ['Navbar', 'employee', 'My profile'], ['ChatPanel', 'employee', 'Ask Ladoo AI'], ['Intro', 'employee', 'Skip'],
];
let n = 0; const failures = [];
for (const [fixName, fx] of [['full', full], ['empty', empty]]) {
  for (const [page, role, must] of cases) {
    globalThis.__fx = fx; globalThis.__fetched = new Set(); globalThis.__auth = { user: users[role], settings, initialized: true, loading: false, startSession() {}, logout() {}, refreshSettings() {} };
    try {
      const html = render(page);
      n++;
      if (html.includes('NO FIXTURE FOR')) failures.push(`${fixName}/${page}/${role}: ${html.match(/NO FIXTURE FOR [^<"]*/)[0]}`);
      if (fixName === 'full' && !html.includes(must)) failures.push(`${fixName}/${page}/${role}: expected text "${must}" not rendered`);
      if (/undefined|NaN|\[object Object\]/.test(html.replace(/<style[\s\S]*?<\/style>/g, ''))) failures.push(`${fixName}/${page}/${role}: suspicious output (${html.match(/.{20}(undefined|NaN|\[object Object\]).{20}/)?.[0]})`);
    } catch (e) { failures.push(`${fixName}/${page}/${role}: THREW ${e.message}`); }
  }
}
// Auth screens and degraded states.
for (const [label, fn] of [
  ['Setup', () => render('Setup')], ['Login', () => render('Login', { error: 'Cannot reach the server.' })], ['ChangePassword forced', () => render('ChangePassword', { forced: true })],
  ['Settings with settings=null does not throw', () => { globalThis.__auth = { ...globalThis.__auth, settings: null }; const h = render('Settings'); assert.match(h, /could not be loaded/); return h; }],
  ['Navbar hides links while password change is forced', () => { globalThis.__auth = { ...globalThis.__auth, user: { ...users.employee, mustChangePassword: true } }; const h = render('Navbar'); assert.ok(!h.includes('My profile')); return h; }],
]) { globalThis.__fx = full; globalThis.__fetched = new Set(); if (!label.startsWith('Settings') && !label.startsWith('Navbar')) globalThis.__auth = { user: null, settings: null, initialized: true, startSession() {} }; try { fn(); n++; } catch (e) { failures.push(`${label}: THREW ${e.message}`); } }

console.log(`${n} renders executed`);
if (failures.length) { console.log('FAILURES:\n' + failures.join('\n')); process.exit(1); }
console.log('render smoke: all passed');

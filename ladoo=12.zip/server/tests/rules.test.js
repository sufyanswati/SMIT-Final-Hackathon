// Offline unit tests for the pure rules added in session 4. No npm dependencies or database needed.
import test from 'node:test';
import assert from 'node:assert/strict';
import { planEmployeeUpdate } from '../src/core/employeeRules.js';
import { firstNonStringParam } from '../src/core/query.js';
import { resolveRange, daysBetween, MAX_RANGE_DAYS } from '../src/core/dates.js';
import { toCsv, neutralizeFormula, parseCsv } from '../src/core/csv.js';
import { decideProof } from '../src/core/geo.js';

const active = { status: 'active', joiningDate: '2026-01-05' };
const exited = { status: 'exited', joiningDate: '2026-01-05', exitDate: '2026-02-10' };
const TODAY = '2026-03-02';
const plan = (actorRole, existing, patch) => planEmployeeUpdate({ actorRole, existing, patch, today: TODAY });

test('employee update: HR cannot exit an employee or set an exit date (permission bypass closed)', () => {
  assert.equal(plan('hr', active, { status: 'exited' }).error.status, 403);
  assert.equal(plan('hr', active, { exitDate: '2026-02-01' }).error.status, 403);
  assert.equal(plan('hr', active, { exitDate: '2026-02-01', status: 'active' }).error.status, 403);
});

test('employee update: HR may edit ordinary fields and keep status unchanged', () => {
  const r = plan('hr', active, { basicSalary: 90000, phone: '1' });
  assert.deepEqual(r.patch, { basicSalary: 90000, phone: '1' });
  assert.equal(r.deactivateUser, false); assert.equal(r.reactivateUser, false);
  assert.equal(plan('hr', exited, { phone: '5' }).error, undefined); // editing an exited record is fine
});

test('employee update: Admin exit sets status, exit date (default today) and deactivates the login', () => {
  const r = plan('admin', active, { status: 'exited' });
  assert.equal(r.patch.status, 'exited'); assert.equal(r.patch.exitDate, TODAY); assert.equal(r.deactivateUser, true);
  const r2 = plan('admin', active, { status: 'exited', exitDate: '2026-02-20' });
  assert.equal(r2.patch.exitDate, '2026-02-20');
});

test('employee update: an exit date alone is treated as an exit; contradictory status is rejected', () => {
  const r = plan('admin', active, { exitDate: '2026-02-20' });
  assert.equal(r.patch.status, 'exited'); assert.equal(r.deactivateUser, true);
  assert.equal(plan('admin', active, { exitDate: '2026-02-20', status: 'probation' }).error.status, 422);
});

test('employee update: exit date cannot precede joining date', () => {
  assert.equal(plan('admin', active, { status: 'exited', exitDate: '2026-01-01' }).error.status, 422);
  assert.equal(plan('admin', active, { joiningDate: '2026-03-01', status: 'exited', exitDate: '2026-02-01' }).error.status, 422);
});

test('employee update: reinstating is Admin-only, clears exit date, re-enables login', () => {
  assert.equal(plan('hr', exited, { status: 'active' }).error.status, 403);
  const r = plan('admin', exited, { status: 'active' });
  assert.equal(r.patch.exitDate, null); assert.equal(r.reactivateUser, true); assert.equal(r.deactivateUser, false);
});

test('query hardening: only plain strings are accepted', () => {
  assert.equal(firstNonStringParam({ status: 'pending', page: '2' }), null);
  assert.equal(firstNonStringParam({ status: { $ne: 'x' } }), 'status');
  assert.equal(firstNonStringParam({ a: ['1', '2'] }), 'a');
  assert.equal(firstNonStringParam(undefined), null);
});

test('report ranges: validation and bounded size', () => {
  assert.deepEqual(resolveRange('2026-01-01', '2026-01-31', {}), { from: '2026-01-01', to: '2026-01-31' });
  assert.deepEqual(resolveRange(undefined, undefined, { today: '2026-03-02', defaultFrom: '2026-01-01' }), { from: '2026-01-01', to: '2026-03-02' });
  assert.ok(resolveRange('2026-02-30', '2026-03-01', {}).error);        // impossible date
  assert.ok(resolveRange('garbage', '2026-03-01', {}).error);
  assert.ok(resolveRange('2026-03-02', '2026-03-01', {}).error);        // reversed
  assert.ok(resolveRange('0001-01-01', '2026-03-01', {}).error);        // would loop ~740k days
  assert.equal(daysBetween('2026-01-01', '2026-01-01'), 1);
  assert.equal(daysBetween('2026-01-01', '2026-12-31'), 365);
  assert.equal(MAX_RANGE_DAYS, 400);
  assert.ok(!resolveRange('2026-01-01', '2026-02-04', {}).error);      // 35 days is fine
  assert.ok(resolveRange('2025-01-01', '2026-02-05', {}).error);       // 401 days is rejected (limit is 400)
});

test('CSV export neutralizes spreadsheet formulas but leaves normal text and numbers alone', () => {
  assert.equal(neutralizeFormula('=SUM(A1)'), "'=SUM(A1)");
  assert.equal(neutralizeFormula('+1'), "'+1"); assert.equal(neutralizeFormula('@cmd'), "'@cmd"); assert.equal(neutralizeFormula('-x'), "'-x");
  assert.equal(neutralizeFormula('Ali'), 'Ali'); assert.equal(neutralizeFormula(-5), -5);
  const csv = toCsv(['name', 'note'], [{ name: '=HYPERLINK("x")', note: 'a,b' }]);
  assert.equal(csv, `name,note\n"'=HYPERLINK(""x"")","a,b"`);
  assert.equal(parseCsv(csv)[0].note, 'a,b');
});

const OFFICE = { lat: 24.8607, lng: 67.0011, radiusMeters: 100 };
test('check-in proof: location optional by default, never blocks when office is unset', () => {
  assert.deepEqual(decideProof({ requireLocation: false, office: {}, body: {} }), { source: 'web' });
  assert.deepEqual(decideProof({ requireLocation: false, office: { radiusMeters: 100 }, body: { lat: 1, lng: 2, accuracy: 5 } }), { source: 'web' });
  assert.deepEqual(decideProof({ requireLocation: false, office: OFFICE, body: {} }), { source: 'web' });
});

test('check-in proof: geofence enforced when supplied or required', () => {
  const near = decideProof({ requireLocation: true, office: OFFICE, body: { lat: 24.8608, lng: 67.0012, accuracy: 10 } });
  assert.equal(near.source, 'web_geo'); assert.ok(near.geo.distance < 100);
  assert.equal(decideProof({ requireLocation: true, office: OFFICE, body: { lat: 25.5, lng: 67, accuracy: 10 } }).error.status, 422);
  assert.equal(decideProof({ requireLocation: true, office: OFFICE, body: { lat: 24.8607, lng: 67.0011, accuracy: 500 } }).error.status, 422);
  assert.equal(decideProof({ requireLocation: true, office: OFFICE, body: {} }).error.status, 422);       // required but missing
  assert.equal(decideProof({ requireLocation: true, office: {}, body: { lat: 1, lng: 2, accuracy: 5 } }).error.status, 422); // required but office unset
  assert.equal(decideProof({ requireLocation: false, office: OFFICE, body: { lat: 25.5, lng: 67, accuracy: 10 } }).error.status, 422); // supplied and outside
  assert.match(decideProof({ requireLocation: true, office: OFFICE, body: { lat: 24.8607, lng: 67.0011, accuracy: 5, faceCount: 0 } }).error.message, /No face/);
  assert.match(decideProof({ requireLocation: true, office: OFFICE, body: { lat: 24.8607, lng: 67.0011, accuracy: 5, faceCount: 2 } }).error.message, /Multiple/);
});

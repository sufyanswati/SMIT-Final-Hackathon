import test from 'node:test';
import assert from 'node:assert/strict';
import { annualTax } from '../src/core/tax.js';
import { computePayroll, salaryStructure } from '../src/core/payroll.js';
import { deriveStatus, isLate, dayStatus } from '../src/core/attendance.js';
import { countWorkingDays, zonedToUtc, toDateStr, addDays, isDateStr, monthRange } from '../src/core/dates.js';
import { validateLeave, leaveDateSet } from '../src/core/leave.js';
import { haversineMeters, validateLocation } from '../src/core/geo.js';
import { attendanceRate, latePercentage, absenteeismRate, attritionRate, leaveUtilization, tally } from '../src/core/analytics.js';
import { parseCsv, toCsv } from '../src/core/csv.js';

const TZ = 'Asia/Karachi';
const at = (date, hhmm) => zonedToUtc(date, hhmm, TZ);

test('tax: exact bracket boundaries and just above', () => {
  assert.equal(annualTax(0), 0);
  assert.equal(annualTax(600000), 0);
  assert.equal(annualTax(600100), 5);          // 5% of 100
  assert.equal(annualTax(1200000), 30000);
  assert.equal(annualTax(1200100), 30015);     // +15% of 100
  assert.equal(annualTax(2400000), 210000);
  assert.equal(annualTax(2400100), 210025);    // +25%
  assert.equal(annualTax(3600000), 510000);
  assert.equal(annualTax(3600100), 510035);    // +35%
  assert.equal(annualTax(5000000), 510000 + 1400000 * 0.35);
});

test('salary structure: gross = 1.5 x basic, HRA 40%, medical 10%', () => {
  const s = salaryStructure(100000);
  assert.deepEqual(s, { basic: 100000, hra: 40000, medical: 10000, gross: 150000 });
  assert.equal(s.basic + s.hra + s.medical, s.gross);
});

test('payroll: full month, no deductions, tax slab on annualized gross', () => {
  const r = computePayroll({ basic: 100000, workingDays: 22, employedDays: 22 });
  assert.equal(r.gross, 150000);
  assert.equal(r.annualGross, 1800000);
  assert.equal(r.tax, Math.round((30000 + 0.15 * 600000) / 12 * 100) / 100);
  assert.equal(r.net, Math.round((150000 - r.tax) * 100) / 100);
});

test('payroll: deduction days = absent + unpaid + 0.5 x half-day; no double counting', () => {
  const r = computePayroll({ basic: 40000, workingDays: 20, employedDays: 20, absent: 1, unpaidLeave: 2, halfDays: 2 });
  assert.equal(r.deductionDays, 4);
  assert.equal(r.perDay, 3000);          // 60000 / 20
  assert.equal(r.deduction, 12000);
  assert.equal(r.tax, 500);              // annual 720000 -> 5% of 120000 = 6000/yr -> 500/month
});

test('payroll: low salary tax slab is 5% above 600k annual', () => {
  const r = computePayroll({ basic: 40000, workingDays: 20, employedDays: 20 });
  assert.equal(r.annualGross, 720000);
  assert.equal(r.tax, 500);              // 6000 / 12
});

test('payroll: joiner proration', () => {
  const r = computePayroll({ basic: 40000, workingDays: 20, employedDays: 10 });
  assert.equal(r.earnedGross, 30000);
  assert.equal(r.annualGross, 360000);
  assert.equal(r.tax, 0);
  assert.equal(r.net, 30000);
});

test('attendance: late after 09:15 only, with 15-minute grace', () => {
  const o = { officeStart: '09:00', graceMinutes: 15, tz: TZ };
  assert.equal(isLate(at('2026-03-02', '09:15'), o), false);
  assert.equal(isLate(at('2026-03-02', '09:16'), o), true);
});

test('attendance: statuses', () => {
  const o = { tz: TZ };
  const d = '2026-03-02';
  assert.equal(deriveStatus({ checkIn: at(d, '09:00'), checkOut: at(d, '17:30') }, o), 'present');
  assert.equal(deriveStatus({ checkIn: at(d, '09:40'), checkOut: at(d, '18:00') }, o), 'late');
  assert.equal(deriveStatus({ checkIn: at(d, '09:00'), checkOut: at(d, '13:59') }, o), 'half_day');
  assert.equal(deriveStatus({ checkIn: at(d, '09:00'), checkOut: at(d, '14:00') }, o), 'present');
  assert.equal(deriveStatus({ checkIn: at(d, '09:00') }, o, true), 'missing_checkout');
  assert.equal(deriveStatus({ checkIn: at(d, '09:00') }, o, false), 'present');
  assert.equal(deriveStatus(null, o), null);
});

test('attendance: dayStatus absent / on_leave / weekend / holiday / future', () => {
  const base = { today: '2026-03-10', weekendDays: [0, 6], holidays: new Set(['2026-03-05']), leaveDates: new Set(['2026-03-04']), opts: { tz: TZ } };
  assert.equal(dayStatus({ ...base, date: '2026-03-03' }), 'absent');
  assert.equal(dayStatus({ ...base, date: '2026-03-04' }), 'on_leave');
  assert.equal(dayStatus({ ...base, date: '2026-03-05' }), 'holiday');
  assert.equal(dayStatus({ ...base, date: '2026-03-07' }), 'weekend'); // Saturday
  assert.equal(dayStatus({ ...base, date: '2026-03-11' }), 'future');
  assert.equal(dayStatus({ ...base, date: '2026-03-02', joiningDate: '2026-03-03' }), 'n/a');
});

test('dates: working-day count excludes weekends and holidays', () => {
  // 2026-03-02 is Monday. Mon..Sun = 5 working days; one holiday on Wed -> 4
  assert.equal(countWorkingDays('2026-03-02', '2026-03-08', [0, 6], new Set()), 5);
  assert.equal(countWorkingDays('2026-03-02', '2026-03-08', [0, 6], new Set(['2026-03-04'])), 4);
  assert.equal(countWorkingDays('2026-03-07', '2026-03-08', [0, 6], new Set()), 0);
});

test('dates: timezone conversion and helpers', () => {
  const d = zonedToUtc('2026-03-02', '09:00', TZ);
  assert.equal(d.toISOString(), '2026-03-02T04:00:00.000Z'); // UTC+5
  assert.equal(toDateStr(new Date('2026-03-01T20:00:00Z'), TZ), '2026-03-02'); // crosses midnight in PKT
  assert.equal(addDays('2026-02-28', 1), '2026-03-01');
  assert.equal(isDateStr('2026-02-30'), false);
  assert.deepEqual(monthRange('2026-02'), { from: '2026-02-01', to: '2026-02-28' });
});

test('leave: overlap and over-balance are rejected, valid passes', () => {
  const lt = { key: 'casual', name: 'Casual', quota: 10 };
  const ok = validateLeave({ start: '2026-03-02', end: '2026-03-03', leaveType: lt, existing: [], usedDays: 0, days: 2 });
  assert.equal(ok, null);
  const overlap = validateLeave({ start: '2026-03-02', end: '2026-03-03', leaveType: lt, existing: [{ start: '2026-03-03', end: '2026-03-04' }], usedDays: 0, days: 2 });
  assert.match(overlap.message, /overlaps/);
  const over = validateLeave({ start: '2026-03-02', end: '2026-03-03', leaveType: lt, existing: [], usedDays: 9, days: 2 });
  assert.match(over.message, /Insufficient/);
  const unpaid = validateLeave({ start: '2026-03-02', end: '2026-03-03', leaveType: { key: 'unpaid', name: 'Unpaid', quota: null }, existing: [], usedDays: 500, days: 2 });
  assert.equal(unpaid, null);
  assert.match(validateLeave({ start: '2026-03-07', end: '2026-03-08', leaveType: lt, existing: [], usedDays: 0, days: 0 }).message, /no working days/);
  assert.match(validateLeave({ start: '2026-12-30', end: '2027-01-02', leaveType: lt, existing: [], usedDays: 0, days: 2 }).message, /split/);
});

test('leave: leaveDateSet skips weekends/holidays', () => {
  const s = leaveDateSet([{ start: '2026-03-06', end: '2026-03-09' }], [0, 6], new Set());
  assert.deepEqual([...s].sort(), ['2026-03-06', '2026-03-09']);
});

test('geo: haversine and location validation', () => {
  const office = { lat: 24.8607, lng: 67.0011, radiusMeters: 150 };
  assert.ok(Math.abs(haversineMeters(0, 0, 0, 1) - 111195) < 200);
  assert.equal(validateLocation({ lat: 24.8607, lng: 67.0011, accuracy: 20 }, office).ok, true);
  assert.equal(validateLocation({ lat: 24.8607, lng: 67.0011, accuracy: 101 }, office).ok, false);
  assert.equal(validateLocation({ lat: 24.87, lng: 67.0011, accuracy: 20 }, office).ok, false); // ~1km north
  assert.equal(validateLocation({ lat: 1, lng: 1 }, office).ok, false);
});

test('analytics formulas and zero denominators', () => {
  assert.equal(attendanceRate({ present: 8, late: 1, missing_checkout: 0, half_day: 2, working: 14, on_leave: 2 }), Math.round((10 / 12) * 10000) / 100);
  assert.equal(attendanceRate({}), 0);
  assert.equal(latePercentage({ present: 9, late: 1 }), 10);
  assert.equal(absenteeismRate({ absent: 2, expected: 40 }), 5);
  assert.equal(attritionRate({ exits: 2, startHeadcount: 18, endHeadcount: 22 }), 10);
  assert.equal(leaveUtilization({ approvedDays: 7, quotaDays: 14 }), 50);
  assert.deepEqual(tally(['present', 'late', 'absent', 'weekend', 'on_leave']), { present: 1, late: 1, half_day: 0, missing_checkout: 0, absent: 1, on_leave: 1, working: 4 });
});

test('csv: parse with quotes, row numbers, and export round trip', () => {
  const rows = parseCsv('code,name\nE1,"Smith, A"\nE2,"Say ""hi"""\n');
  assert.equal(rows.length, 2);
  assert.equal(rows[0].name, 'Smith, A');
  assert.equal(rows[1].name, 'Say "hi"');
  assert.equal(rows[0].__row, 2);
  assert.equal(toCsv(['a', 'b'], [{ a: 'x,y', b: 1 }]), 'a,b\n"x,y",1');
});

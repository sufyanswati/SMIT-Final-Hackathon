// Offline static contract tests: (1) every API call made by the client matches a real server route (method + path),
// (2) no server route is shadowed by an earlier parameterised route, (3) every protected route has authentication.
// This reads source text only; it does NOT execute Express, so it cannot prove the handlers work.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const routesSrc = fs.readFileSync(path.join(here, '../src/routes/index.js'), 'utf8');
const clientDir = path.join(here, '../../client/src');

function serverRoutes() {
  const out = [];
  for (const m of routesSrc.matchAll(/router\.(get|post|put|delete)\(\s*([`'"])(.*?)\2/g)) {
    const [, method, , p] = m; const line = routesSrc.slice(0, m.index).split('\n').length;
    const stmtEnd = routesSrc.indexOf('\n', routesSrc.indexOf(');', m.index)); const stmt = routesSrc.slice(m.index, stmtEnd);
    const paths = p.includes('${path}') ? ['departments', 'designations'].map((n) => p.replace('${path}', n)) : [p];
    for (const rp of paths) out.push({ method: method.toUpperCase(), path: rp, line, stmt });
  }
  return out;
}
const toRegex = (p) => new RegExp('^' + p.replace(/\/:(\w+)\(([^)]+)\)/g, '/($2)').replace(/\/:(\w+)\?/g, '(?:/[^/]+)?').replace(/:(\w+)/g, '[^/]+') + '$');

function walk(d) { return fs.readdirSync(d).flatMap((f) => { const p = path.join(d, f); return fs.statSync(p).isDirectory() ? walk(p) : [p]; }); }
function clientCalls() {
  const calls = [];
  for (const f of walk(clientDir).filter((x) => /\.jsx?$/.test(x))) {
    const src = fs.readFileSync(f, 'utf8');
    const norm = (s) => s.replace(/\$\{[^}]*\}/g, 'X').split('?')[0];
    for (const m of src.matchAll(/\bapi\(\s*([`'"])(\/.*?)\1\s*(?:,\s*\{([^}]*)\})?/g)) calls.push({ file: path.basename(f), method: ((m[3] || '').match(/method:\s*'(\w+)'/)?.[1] || 'GET').toUpperCase(), path: norm(m[2]) });
    for (const m of src.matchAll(/\b(?:useFetch|download|NameList path=)\(?\s*([`'"])(\/.*?)\1/g)) calls.push({ file: path.basename(f), method: 'GET', path: norm(m[2]) });
    for (const m of src.matchAll(/<NameList path="([^"]+)"/g)) { calls.push({ file: path.basename(f), method: 'GET', path: m[1] }); calls.push({ file: path.basename(f), method: 'POST', path: m[1] }); calls.push({ file: path.basename(f), method: 'DELETE', path: m[1] + '/X' }); }
  }
  return calls;
}

test('route table is parsed (sanity)', () => { assert.ok(serverRoutes().length >= 55, `only ${serverRoutes().length} routes found`); });

test('every client API call maps to a server route (method + path)', () => {
  const routes = serverRoutes(); const calls = clientCalls();
  assert.ok(calls.length > 40, `only ${calls.length} client calls found`);
  // A dynamic final segment (e.g. `/users/${id}/${action}`) is checked against the action names the route declares.
  const ACTIONS = ['deactivate', 'activate', 'reset-password', 'check-in', 'check-out', 'cancel', 'decision', 'finalize'];
  const variants = (c) => (c.path.endsWith('/X') ? [c.path, ...ACTIONS.map((a) => c.path.slice(0, -1) + a)] : [c.path]);
  const missing = calls.filter((c) => !routes.some((r) => r.method === c.method && variants(c).some((v) => toRegex(r.path).test(v))));
  assert.deepEqual(missing.map((c) => `${c.file}: ${c.method} ${c.path}`), []);
});

test('no route is shadowed by an earlier parameterised route of the same method', () => {
  const routes = serverRoutes(); const shadowed = [];
  routes.forEach((later, j) => routes.slice(0, j).forEach((earlier) => {
    if (earlier.method !== later.method || earlier.path === later.path || later.path.includes(':')) return;
    if (toRegex(earlier.path).test(later.path)) shadowed.push(`${later.method} ${later.path} (line ${later.line}) is shadowed by ${earlier.path} (line ${earlier.line})`);
  }));
  assert.deepEqual(shadowed, []);
});

test('every route except the public ones requires authentication', () => {
  const PUBLIC = new Set(['GET /setup/status', 'POST /setup', 'POST /auth/login']);
  const open = serverRoutes().filter((r) => !PUBLIC.has(`${r.method} ${r.path}`) && !/\.\.\.protect|authenticate/.test(r.stmt)).map((r) => `${r.method} ${r.path}`);
  assert.deepEqual(open, []);
});

test('mutating employee/payroll/user endpoints have an explicit role guard', () => {
  const need = ['POST /payroll/:id/finalize', 'POST /payroll/drafts', 'POST /users', 'POST /leave/:id/decision', 'POST /attendance/corrections/:id/decision', 'PUT /settings', 'GET /audit-logs', 'PUT /employees/:id', 'POST /employees'];
  const routes = serverRoutes();
  for (const n of need) { const [method, p] = n.split(' '); const r = routes.find((x) => x.method === method && x.path === p); assert.ok(r, `${n} missing`); assert.match(r.stmt, /requireRole|staff/, `${n} has no role guard`); }
});

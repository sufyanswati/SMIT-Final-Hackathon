// Integration tests. REQUIRE: npm install (mongodb-memory-server downloads a MongoDB binary, supertest).
// STATUS: written, NOT RUN in the authoring sandbox (no network / no MongoDB).
import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';
import mongoose from 'mongoose';
import request from 'supertest';
import { MongoMemoryServer } from 'mongodb-memory-server';

process.env.NODE_ENV = 'test';
const { createApp } = await import('../src/app.js');
const { clock } = await import('../src/services/common.js');
const models = await import('../src/models/index.js');
const ai = await import('../src/services/ai.js');

let mongod, app; const T = {};
const MONDAY_0910 = new Date('2026-03-02T04:10:00Z'); // 09:10 in Asia/Karachi
const auth = (t) => ({ Authorization: `Bearer ${t}` });

before(async () => {
  mongod = await MongoMemoryServer.create(); await mongoose.connect(mongod.getUri()); await mongoose.syncIndexes();
  app = createApp(); clock.now = () => MONDAY_0910;
});
after(async () => { await mongoose.disconnect(); await mongod.stop(); });

test('health endpoints distinguish liveness from database readiness', async () => {
  const live = await request(app).get('/health');
  assert.equal(live.status, 200);
  assert.equal(live.body.ok, true);
  const ready = await request(app).get('/ready');
  assert.equal(ready.status, 200);
  assert.equal(ready.body.ready, true);
  assert.equal(ready.body.database, 'connected');
});

test('fresh install is empty and setup is protected against duplicates', async () => {
  assert.deepEqual((await request(app).get('/api/setup/status')).body, { initialized: false });
  const body = { companyName: 'Acme', name: 'Root', email: 'admin@acme.test', password: 'Passw0rdX' };
  const results = await Promise.all([request(app).post('/api/setup').send(body), request(app).post('/api/setup').send({ ...body, email: 'b@acme.test' })]);
  assert.deepEqual(results.map((r) => r.status).sort(), [201, 409]);
  assert.equal(await models.User.countDocuments({ role: 'admin' }), 1);
  assert.equal(await models.Employee.countDocuments(), 0); // no dummy data
  T.admin = (await request(app).post('/api/auth/login').send({ email: 'admin@acme.test', password: 'Passw0rdX' }).then((r) => r.body)).token;
});

test('unauthenticated -> 401; role checks -> 403', async () => {
  assert.equal((await request(app).get('/api/employees')).status, 401);
  const hr = await request(app).post('/api/users').set(auth(T.admin)).send({ name: 'Hana HR', email: 'hr@acme.test', role: 'hr' });
  assert.equal(hr.status, 201);
  const login = await request(app).post('/api/auth/login').send({ email: 'hr@acme.test', password: hr.body.temporaryPassword });
  const pw = await request(app).post('/api/auth/change-password').set(auth(login.body.token)).send({ currentPassword: hr.body.temporaryPassword, newPassword: 'NewPassw0rd' });
  T.hr = pw.body.token;
  assert.equal((await request(app).get('/api/audit-logs').set(auth(T.hr))).status, 403);
  assert.equal((await request(app).put('/api/settings').set(auth(T.hr)).send({ graceMinutes: 5 })).status, 403);
  assert.equal((await request(app).post('/api/users').set(auth(T.hr)).send({ name: 'x y', email: 'x@y.z', role: 'admin' })).status, 403);
  assert.equal((await request(app).get('/api/audit-logs').set(auth(T.admin))).status, 200);
});

async function mkEmployee(code, email, salary = 100000) {
  const dept = (await models.Department.findOne()) || (await request(app).post('/api/departments').set(auth(T.admin)).send({ name: 'Engineering' })).body;
  const r = await request(app).post('/api/employees').set(auth(T.hr)).send({ code, firstName: code, lastName: 'Test', email, department: String(dept._id), joiningDate: '2026-01-01', basicSalary: salary });
  assert.equal(r.status, 201);
  const login = await request(app).post('/api/auth/login').send({ email, password: r.body.temporaryPassword });
  assert.equal(login.body.user.mustChangePassword, true);
  assert.equal((await request(app).get('/api/attendance/me').set(auth(login.body.token))).status, 403); // blocked until password changed
  const pw = await request(app).post('/api/auth/change-password').set(auth(login.body.token)).send({ currentPassword: r.body.temporaryPassword, newPassword: 'Employee123' });
  return { token: pw.body.token, id: r.body.employee._id };
}

test('employee registration, first-login password change, ownership, duplicates', async () => {
  T.e1 = await mkEmployee('E001', 'e1@acme.test'); T.e2 = await mkEmployee('E002', 'e2@acme.test');
  assert.equal((await request(app).get(`/api/employees/${T.e2.id}`).set(auth(T.e1.token))).status, 403); // cannot read colleague
  assert.equal((await request(app).get(`/api/employees/${T.e1.id}`).set(auth(T.e1.token))).status, 200);
  const dup = await request(app).post('/api/employees').set(auth(T.hr)).send({ code: 'E001', firstName: 'a', lastName: 'b', email: 'z@acme.test', department: String((await models.Department.findOne())._id), joiningDate: '2026-01-01', basicSalary: 1 });
  assert.equal(dup.status, 409);
  const mass = await request(app).put('/api/employees/me').set(auth(T.e1.token)).send({ basicSalary: 9999999, phone: '123' });
  assert.equal(mass.status, 400); // salary is not a permitted self-edit field
});

test('check-in: late rule and duplicate -> 409', async () => {
  const a = await request(app).post('/api/attendance/check-in').set(auth(T.e1.token)).send({});
  assert.equal(a.status, 201);
  assert.equal(a.body.status, 'present'); // 09:10 is inside the 15-minute grace period
  assert.equal((await request(app).post('/api/attendance/check-in').set(auth(T.e1.token)).send({})).status, 409);
});

test('leave: overlap and over-balance -> 422; HR approval creates notification and audit', async () => {
  const ok = await request(app).post('/api/leave').set(auth(T.e1.token)).send({ type: 'casual', start: '2026-03-09', end: '2026-03-10' });
  assert.equal(ok.status, 201); assert.equal(ok.body.days, 2);
  assert.equal((await request(app).post('/api/leave').set(auth(T.e1.token)).send({ type: 'sick', start: '2026-03-10', end: '2026-03-11' })).status, 422);
  assert.equal((await request(app).post('/api/leave').set(auth(T.e1.token)).send({ type: 'sick', start: '2026-04-06', end: '2026-04-21' })).status, 422); // > 8 sick days
  assert.equal((await request(app).post(`/api/leave/${ok.body._id}/decision`).set(auth(T.e1.token)).send({ approve: true })).status, 403);
  assert.equal((await request(app).post(`/api/leave/${ok.body._id}/decision`).set(auth(T.hr)).send({ approve: true })).status, 200);
  assert.equal((await request(app).post(`/api/leave/${ok.body._id}/decision`).set(auth(T.hr)).send({ approve: true })).status, 409); // already decided
  assert.ok(await models.Notification.countDocuments({ kind: 'leave' }));
  assert.ok(await models.AuditLog.countDocuments({ action: 'leave.approve' }));
});

test('payroll: HR drafts, only Admin finalizes, finalized run is locked, payslip PDF is own-only', async () => {
  const d = await request(app).post('/api/payroll/drafts').set(auth(T.hr)).send({ month: '2026-02' });
  assert.equal(d.status, 201);
  assert.equal((await request(app).post(`/api/payroll/${d.body._id}/finalize`).set(auth(T.hr))).status, 403);
  assert.equal((await request(app).post(`/api/payroll/${d.body._id}/finalize`).set(auth(T.admin))).status, 200);
  assert.equal((await request(app).post(`/api/payroll/${d.body._id}/finalize`).set(auth(T.admin))).status, 422);
  assert.equal((await request(app).post('/api/payroll/drafts').set(auth(T.hr)).send({ month: '2026-02' })).status, 422);
  const pdf = await request(app).get(`/api/payroll/${d.body._id}/payslip`).set(auth(T.e1.token));
  assert.equal(pdf.status, 200); assert.match(pdf.headers['content-type'], /pdf/);
  const item = d.body.items.find((i) => i.code === 'E001'); assert.equal(item.gross, 150000);
});

test('audit log is append-only', async () => {
  const log = await models.AuditLog.findOne();
  await assert.rejects(() => models.AuditLog.updateOne({ _id: log._id }, { action: 'x' }));
  await assert.rejects(() => models.AuditLog.deleteMany({}));
});

test('AI: tools are scoped; employee cannot access colleague/company data; fallback when provider fails', async () => {
  const e1 = await models.User.findOne({ email: 'e1@acme.test' });
  assert.equal((await ai.runTool('search_employees', { query: 'E002' }, e1)).error, 'forbidden');
  assert.equal((await ai.runTool('get_headcount', {}, e1)).error, 'forbidden');
  assert.ok((await ai.runTool('get_my_leave_balance', {}, e1)).balances.length);
  const hr = await models.User.findOne({ email: 'hr@acme.test' });
  const res = (await ai.runTool('search_employees', { query: 'E002' }, hr)).results; assert.equal(res.length, 1); assert.equal(res[0].salary, undefined);
  ai.setLlmForTests(async () => { throw Object.assign(new Error('boom'), { name: 'AbortError' }); });
  const r = await request(app).post('/api/ai/chat').set(auth(T.e1.token)).send({ message: "What is E002's salary?" });
  assert.equal(r.status, 200); assert.equal(r.body.fallback, true);
  ai.setLlmForTests(null);
  assert.ok(await models.AiLog.countDocuments({ status: 'timeout' }));
});

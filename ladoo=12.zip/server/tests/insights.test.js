import test from 'node:test';
import assert from 'node:assert/strict';
import { latePenaltyDays, anomalyFlags, attritionRisk } from '../src/core/insights.js';

const mk = (list, start = '2026-03-02') => list.map((status, i) => { const t = new Date(`${start}T00:00:00Z`); t.setUTCDate(t.getUTCDate() + i); return { date: t.toISOString().slice(0, 10), status }; });

test('late penalty: disabled by default, free allowance, block deduction', () => {
  assert.equal(latePenaltyDays(10), 0);
  const r = { enabled: true };
  assert.equal(latePenaltyDays(3, r), 0);
  assert.equal(latePenaltyDays(5, r), 0);
  assert.equal(latePenaltyDays(6, r), 0.5);
  assert.equal(latePenaltyDays(9, r), 1);
  assert.equal(latePenaltyDays(9, { enabled: true, freeLates: 0, lateBlock: 3, deductionDaysPerBlock: 1 }), 3);
});

test('anomalies: consecutive late, absence cluster, none for clean record', () => {
  assert.deepEqual(anomalyFlags(mk(['present', 'present', 'present', 'present', 'present'])), []);
  assert.ok(anomalyFlags(mk(['late', 'late', 'late', 'present'])).some((f) => f.code === 'consecutive_late'));
  assert.ok(anomalyFlags(mk(['absent', 'present', 'absent', 'absent'])).some((f) => f.code === 'absence_cluster'));
  assert.ok(anomalyFlags(mk(['present', 'late', 'present', 'late', 'present', 'late'])).every((f) => f.code !== 'consecutive_late'));
});

test('anomalies: weekend-adjacent absences (Mon 2026-03-02 follows weekend 2026-02-28/03-01)', () => {
  const days = [
    ...mk(['weekend', 'weekend', 'absent'], '2026-02-28'),
    ...mk(['present', 'present', 'present', 'absent', 'weekend', 'weekend', 'absent'], '2026-03-03'),
    ...mk(['present', 'present', 'present', 'absent', 'weekend'], '2026-03-10'),
  ];
  assert.ok(anomalyFlags(days).some((f) => f.code === 'weekend_adjacent_absence'));
});

test('attrition risk: explainable, bounded, low for a healthy employee, no signal on thin data', () => {
  const healthy = attritionRisk({ days: mk(Array(10).fill('present')), tenureYears: 4, basicSalary: 100, deptAverageBasic: 100 });
  assert.equal(healthy.level, 'low'); assert.equal(healthy.score, 0);
  const risky = attritionRisk({ days: mk(['absent', 'late', 'absent', 'absent', 'late', 'late', 'absent', 'present']), tenureYears: 0.4, basicSalary: 50, deptAverageBasic: 100 });
  assert.equal(risky.level, 'high'); assert.ok(risky.score <= 100); assert.ok(risky.factors.length >= 3);
  const thin = attritionRisk({ days: mk(['absent', 'absent']), tenureYears: 3, basicSalary: 100, deptAverageBasic: 100 });
  assert.equal(thin.enoughData, false); assert.equal(thin.score, 0);
});

import { computePayroll } from '../src/core/payroll.js';
test('payroll: late-penalty days add to deduction and reduce net', () => {
  const base = computePayroll({ basic: 100000, workingDays: 20, employedDays: 20 });
  const pen = computePayroll({ basic: 100000, workingDays: 20, employedDays: 20, latePenaltyDays: 1 });
  assert.equal(pen.deductionDays, 1);
  assert.equal(pen.deduction, pen.perDay);
  assert.ok(pen.net < base.net);
  assert.equal(base.deduction, 0);
});

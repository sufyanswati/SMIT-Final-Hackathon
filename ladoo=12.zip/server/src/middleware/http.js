import jwt from 'jsonwebtoken';
import { ZodError } from 'zod';
import { env } from '../config/env.js';
import { User } from '../models/index.js';

export class HttpError extends Error {
  constructor(status, message, details) { super(message); this.status = status; this.details = details; }
}
export const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export const signToken = (user) => jwt.sign({ sub: String(user._id), v: user.tokenVersion }, env.jwtSecret, { expiresIn: env.jwtExpiresIn });

/** Authenticate: verifies JWT, loads user, rejects deactivated accounts. Sets req.user. */
export const authenticate = wrap(async (req, _res, next) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) throw new HttpError(401, 'Authentication required');
  let payload;
  try { payload = jwt.verify(token, env.jwtSecret); } catch { throw new HttpError(401, 'Session expired or invalid. Please sign in again.'); }
  const user = await User.findById(payload.sub);
  if (!user || !user.active || user.tokenVersion !== payload.v) throw new HttpError(401, 'Session is no longer valid. Please sign in again.');
  req.user = user;
  next();
});

/** Blocks everything but the password-change route while a temporary password is in use. */
export const requirePasswordChanged = (req, _res, next) => {
  if (req.user.mustChangePassword) return next(new HttpError(403, 'You must change your temporary password first.', { code: 'PASSWORD_CHANGE_REQUIRED' }));
  next();
};

export const requireRole = (...roles) => (req, _res, next) => (roles.includes(req.user.role) ? next() : next(new HttpError(403, 'You do not have permission to perform this action')));

export const validate = (schema, where = 'body') => (req, _res, next) => {
  const r = schema.safeParse(req[where]);
  if (!r.success) return next(r.error);
  req[where] = r.data; // strips unknown keys => no mass assignment
  next();
};

// eslint-disable-next-line no-unused-vars
export const errorHandler = (err, _req, res, _next) => {
  if (err instanceof ZodError) return res.status(400).json({ error: 'Validation failed', details: err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })) });
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message, ...(err.details ? { details: err.details } : {}) });
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body' });
  if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'Request body too large' });
  if (err?.code === 11000) return res.status(409).json({ error: 'Duplicate value violates a uniqueness rule', details: Object.keys(err.keyPattern || {}) });
  if (err?.name === 'CastError') return res.status(404).json({ error: 'Resource not found' });
  if (!env.isTest) console.error('[error]', err?.message);
  res.status(500).json({ error: 'Internal server error' });
};

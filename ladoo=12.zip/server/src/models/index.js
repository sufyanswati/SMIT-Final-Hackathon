import mongoose from 'mongoose';
const { Schema, model } = mongoose;
const ref = (name) => ({ type: Schema.Types.ObjectId, ref: name });

const userSchema = new Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ['admin', 'hr', 'employee'], required: true },
  employee: ref('Employee'),
  mustChangePassword: { type: Boolean, default: false },
  active: { type: Boolean, default: true },
  tokenVersion: { type: Number, default: 0 },
}, { timestamps: true });

const settingSchema = new Schema({
  key: { type: String, default: 'main', unique: true }, // unique key => only one initialisation can win
  companyName: { type: String, required: true },
  timezone: { type: String, default: 'Asia/Karachi' },
  officeStart: { type: String, default: '09:00' },
  graceMinutes: { type: Number, default: 15 },
  weekendDays: { type: [Number], default: [0, 6] },
  office: { lat: Number, lng: Number, radiusMeters: { type: Number, default: 100 } },
  requireLocation: { type: Boolean, default: false },
  latePenalty: { enabled: { type: Boolean, default: false }, freeLates: { type: Number, default: 3 }, lateBlock: { type: Number, default: 3 }, deductionDaysPerBlock: { type: Number, default: 0.5 } },
  leaveTypes: { type: [{ _id: false, key: String, name: String, quota: { type: Number, default: null }, paid: { type: Boolean, default: true } }],
    default: () => [
      { key: 'annual', name: 'Annual', quota: 14, paid: true },
      { key: 'sick', name: 'Sick', quota: 8, paid: true },
      { key: 'casual', name: 'Casual', quota: 10, paid: true },
      { key: 'unpaid', name: 'Unpaid', quota: null, paid: false },
    ] },
  holidays: { type: [{ _id: false, date: String, name: String }], default: [] },
}, { timestamps: true });

const departmentSchema = new Schema({ name: { type: String, required: true, unique: true, trim: true } }, { timestamps: true });
const designationSchema = new Schema({ name: { type: String, required: true, unique: true, trim: true } }, { timestamps: true });

const employeeSchema = new Schema({
  code: { type: String, required: true, unique: true, trim: true },
  user: ref('User'),
  firstName: { type: String, required: true, trim: true },
  lastName: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  phone: String, address: String,
  gender: { type: String, enum: ['male', 'female', 'other', ''], default: '' },
  department: { ...ref('Department'), required: true },
  designation: ref('Designation'),
  joiningDate: { type: String, required: true },
  exitDate: String,
  status: { type: String, enum: ['active', 'probation', 'exited'], default: 'active' },
  basicSalary: { type: Number, required: true, min: 0.01 },
}, { timestamps: true });
employeeSchema.index({ firstName: 'text', lastName: 'text', code: 'text', email: 'text' });

const attendanceSchema = new Schema({
  employee: { ...ref('Employee'), required: true },
  date: { type: String, required: true },
  checkIn: Date, checkOut: Date,
  source: { type: String, enum: ['web', 'web_geo', 'correction'], default: 'web' },
  geo: { lat: Number, lng: Number, accuracy: Number, distance: Number },
  original: { checkIn: Date, checkOut: Date }, // preserved when a correction is applied
}, { timestamps: true });
attendanceSchema.index({ employee: 1, date: 1 }, { unique: true });

const correctionSchema = new Schema({
  employee: { ...ref('Employee'), required: true },
  date: { type: String, required: true },
  checkIn: { type: String, required: true }, // 'HH:MM' company time
  checkOut: String,
  reason: { type: String, required: true },
  status: { type: String, enum: ['pending', 'approved', 'rejected'], default: 'pending' },
  decidedBy: ref('User'), comment: String, decidedAt: Date,
}, { timestamps: true });
correctionSchema.index({ employee: 1, date: 1 }, { unique: true, partialFilterExpression: { status: 'pending' } });

const leaveSchema = new Schema({
  employee: { ...ref('Employee'), required: true },
  type: { type: String, required: true },
  start: { type: String, required: true }, end: { type: String, required: true },
  days: { type: Number, required: true },
  reason: String,
  status: { type: String, enum: ['pending', 'approved', 'rejected', 'cancelled'], default: 'pending' },
  decidedBy: ref('User'), comment: String, decidedAt: Date,
}, { timestamps: true });
leaveSchema.index({ employee: 1, start: 1 });

const payrollSchema = new Schema({
  month: { type: String, required: true, unique: true },
  status: { type: String, enum: ['draft', 'finalized'], default: 'draft' },
  items: [{ _id: false, employee: ref('Employee'), code: String, name: String, department: String, designation: String,
    basic: Number, hra: Number, medical: Number, gross: Number, earnedGross: Number, workingDays: Number, employedDays: Number,
    absent: Number, unpaidLeave: Number, halfDays: Number, latePenaltyDays: Number, deductionDays: Number, perDay: Number, deduction: Number, annualGross: Number, tax: Number, net: Number }],
  totals: { gross: Number, deduction: Number, tax: Number, net: Number },
  createdBy: ref('User'), finalizedBy: ref('User'), finalizedAt: Date,
}, { timestamps: true });

const announcementSchema = new Schema({ title: { type: String, required: true }, body: { type: String, required: true }, author: ref('User'), authorName: String }, { timestamps: true });
const notificationSchema = new Schema({ user: { ...ref('User'), required: true, index: true }, message: String, kind: String, read: { type: Boolean, default: false } }, { timestamps: true });

const auditSchema = new Schema({
  actor: ref('User'), actorName: String, action: { type: String, required: true }, entity: String, entityId: String, before: Schema.Types.Mixed, after: Schema.Types.Mixed,
}, { timestamps: { createdAt: true, updatedAt: false } });
// Audit history is append-only: block updates and deletes at the ODM level.
for (const op of ['updateOne', 'updateMany', 'findOneAndUpdate', 'findOneAndReplace', 'replaceOne', 'deleteOne', 'deleteMany', 'findOneAndDelete']) {
  auditSchema.pre(op, function () { throw new Error('Audit log is append-only'); });
}
auditSchema.pre('save', function (next) { if (!this.isNew) return next(new Error('Audit log is append-only')); next(); });

const aiLogSchema = new Schema({ user: ref('User'), role: String, kind: String, prompt: String, tools: [String], status: String, error: String, ms: Number }, { timestamps: { createdAt: true, updatedAt: false } });
aiLogSchema.index({ user: 1, createdAt: -1 });

export const User = model('User', userSchema);
export const Setting = model('Setting', settingSchema);
export const Department = model('Department', departmentSchema);
export const Designation = model('Designation', designationSchema);
export const Employee = model('Employee', employeeSchema);
export const Attendance = model('Attendance', attendanceSchema);
export const Correction = model('Correction', correctionSchema);
export const LeaveRequest = model('LeaveRequest', leaveSchema);
export const PayrollRun = model('PayrollRun', payrollSchema);
export const Announcement = model('Announcement', announcementSchema);
export const Notification = model('Notification', notificationSchema);
export const AuditLog = model('AuditLog', auditSchema);
export const AiLog = model('AiLog', aiLogSchema);

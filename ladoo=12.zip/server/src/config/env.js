import 'dotenv/config';

const required = (k) => { const v = process.env[k]; if (!v) throw new Error(`Missing required env var ${k}`); return v; };
const isTest = process.env.NODE_ENV === 'test';

export const env = {
  isTest,
  port: Number(process.env.PORT || 4000),
  mongoUri: isTest ? process.env.MONGODB_URI || '' : required('MONGODB_URI'),
  jwtSecret: isTest ? process.env.JWT_SECRET || 'test-secret-test-secret-test-secret' : required('JWT_SECRET'),
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  adminEmail: process.env.ADMIN_EMAIL || '',
  adminPassword: process.env.ADMIN_PASSWORD || '',
  adminName: process.env.ADMIN_NAME || 'Administrator',
  companyName: process.env.COMPANY_NAME || 'My Company',
  ai: { baseUrl: process.env.AI_BASE_URL || '', apiKey: process.env.AI_API_KEY || '', model: process.env.AI_MODEL || '' },
};
if (env.jwtSecret.length < (env.isTest ? 16 : 32)) throw new Error(`JWT_SECRET must be at least ${env.isTest ? 16 : 32} characters`);
if (!env.isTest && process.env.NODE_ENV === 'production') {
  if (!process.env.CLIENT_ORIGIN) throw new Error('CLIENT_ORIGIN must be configured in production');
  const origins = env.clientOrigin.split(',').map((s) => s.trim());
  if (origins.some((origin) => origin === '*' || !/^https?:\/\//i.test(origin))) throw new Error('CLIENT_ORIGIN must contain explicit http(s) origins; wildcards are not allowed');
}

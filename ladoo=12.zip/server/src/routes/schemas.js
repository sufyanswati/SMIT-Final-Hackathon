import { z } from 'zod';
import { isDateStr } from '../core/dates.js';

export const password = z.string().min(8, 'At least 8 characters').regex(/[A-Za-z]/, 'Must contain a letter').regex(/\d/, 'Must contain a digit');
export const email = z.string().trim().toLowerCase().email();
export const dateStr = z.string().refine(isDateStr, 'Must be a valid date (YYYY-MM-DD)');
export const hhmm = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Use HH:MM');
export const oid = z.string().regex(/^[a-f\d]{24}$/i, 'Invalid id');

export const setupSchema = z.object({ companyName: z.string().trim().min(2), name: z.string().trim().min(2), email, password }).strict();
export const loginSchema = z.object({ email, password: z.string().min(1) }).strict();
export const changePwSchema = z.object({ currentPassword: z.string().min(1), newPassword: password }).strict();
export const userCreateSchema = z.object({ name: z.string().trim().min(2), email, role: z.enum(['hr', 'admin']) }).strict();

export const settingsSchema = z.object({
  companyName: z.string().trim().min(2), timezone: z.string().refine((t) => { try { new Intl.DateTimeFormat('en', { timeZone: t }); return true; } catch { return false; } }, 'Unknown timezone'),
  officeStart: hhmm, graceMinutes: z.number().int().min(0).max(240), weekendDays: z.array(z.number().int().min(0).max(6)).max(6),
  office: z.object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180), radiusMeters: z.number().min(10).max(5000) }),
  requireLocation: z.boolean(),
  latePenalty: z.object({ enabled: z.boolean(), freeLates: z.number().int().min(0).max(31), lateBlock: z.number().int().min(1).max(31), deductionDaysPerBlock: z.number().min(0).max(5) }),
  leaveTypes: z.array(z.object({ key: z.string().regex(/^[a-z_]+$/), name: z.string().min(2), quota: z.number().min(0).nullable(), paid: z.boolean() })).min(1),
  holidays: z.array(z.object({ date: dateStr, name: z.string().min(2) })),
}).partial().strict();

export const nameSchema = z.object({ name: z.string().trim().min(2) }).strict();

export const employeeCreateSchema = z.object({
  code: z.string().trim().min(1), firstName: z.string().trim().min(1), lastName: z.string().trim().min(1), email,
  phone: z.string().trim().optional(), address: z.string().trim().optional(), gender: z.enum(['male', 'female', 'other', '']).optional(),
  department: oid, designation: oid.optional(), joiningDate: dateStr, status: z.enum(['active', 'probation']).optional(), basicSalary: z.number().positive(),
}).strict();
export const employeeUpdateSchema = employeeCreateSchema.omit({ code: true }).extend({ status: z.enum(['active', 'probation', 'exited']), exitDate: dateStr }).partial().strict();
export const profileSchema = z.object({ phone: z.string().trim().max(30), address: z.string().trim().max(300) }).partial().strict();
export const csvSchema = z.object({ csv: z.string().min(1).max(1_000_000) }).strict();

export const locationFields = { lat: z.number().optional(), lng: z.number().optional(), accuracy: z.number().optional(), faceCount: z.number().int().min(0).optional() };
export const checkSchema = z.object(locationFields).strict();
export const correctionSchema = z.object({ date: dateStr, checkIn: hhmm, checkOut: hhmm.optional(), reason: z.string().trim().min(5).max(500) }).strict();
export const decisionSchema = z.object({ approve: z.boolean(), comment: z.string().trim().max(500).optional() }).strict();
export const leaveApplySchema = z.object({ type: z.string().min(1), start: dateStr, end: dateStr, reason: z.string().trim().max(500).optional() }).strict();
export const monthSchema = z.object({ month: z.string().regex(/^\d{4}-(0[1-9]|1[0-2])$/) }).strict();
export const announcementSchema = z.object({ title: z.string().trim().min(2).max(120), body: z.string().trim().min(2).max(2000) }).strict();
export const chatSchema = z.object({ message: z.string().trim().min(1).max(1000) }).strict();
export const smartLeaveSchema = z.object({ text: z.string().trim().min(3).max(500) }).strict();

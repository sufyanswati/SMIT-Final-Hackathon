import { Router } from 'express';
import bcrypt from 'bcryptjs';
import rateLimit from 'express-rate-limit';
import { User, Setting, Department, Designation, Employee, Announcement, Notification, AuditLog, PayrollRun, Correction } from '../models/index.js';
import { wrap, HttpError, authenticate, requireRole, requirePasswordChanged, validate, signToken } from '../middleware/http.js';
import { audit, getSettings, ctxFrom, ownEmployee, pageParams } from '../services/common.js';
import { env } from '../config/env.js';
import { initialize, isInitialized } from '../services/setup.js';
import * as emp from '../services/employees.js';
import * as att from '../services/attendance.js';
import * as lv from '../services/leave.js';
import * as pay from '../services/payroll.js';
import * as dash from '../services/dashboard.js';
import * as ai from '../services/ai.js';
import * as insights from '../services/insights.js';
import * as S from './schemas.js';
import { isDateStr, monthRange } from '../core/dates.js';
import { planEmployeeUpdate } from '../core/employeeRules.js';
import { firstNonStringParam } from '../core/query.js';
import { cleanDept, rangeOrThrow } from '../services/common.js';

export const router = Router();
const authLimiter = rateLimit({ skip: () => env.isTest, windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many attempts. Try again later.' } });
const aiLimiter = rateLimit({ skip: () => env.isTest, windowMs: 60 * 60 * 1000, limit: 120, keyGenerator: (req) => String(req.user?._id || req.ip), message: { error: 'Too many AI requests.' } });
const staff = requireRole('admin', 'hr');
const protect = [authenticate, requirePasswordChanged];
const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, mustChangePassword: u.mustChangePassword, employee: u.employee });
const DUMMY = bcrypt.hashSync('not-a-real-password', 10);

// Reject non-string query values (?status[$ne]=x, repeated params) before any handler can use them in a query.
router.use((q, _r, next) => { const bad = firstNonStringParam(q.query); return bad ? next(new HttpError(400, `Invalid query parameter: ${bad}`)) : next(); });

// ---------- setup & auth ----------
router.get('/setup/status', wrap(async (_q, r) => r.json({ initialized: await isInitialized() })));
router.post('/setup', authLimiter, validate(S.setupSchema), wrap(async (q, r) => {
  const u = await initialize(q.body);
  await audit(u, 'setup.initialize', 'Setting', 'main', null, { companyName: q.body.companyName });
  r.status(201).json({ token: signToken(u), user: publicUser(u) });
}));

router.post('/auth/login', authLimiter, validate(S.loginSchema), wrap(async (q, r) => {
  const u = await User.findOne({ email: q.body.email });
  const ok = await bcrypt.compare(q.body.password, u?.passwordHash || DUMMY);
  if (!u || !ok) throw new HttpError(401, 'Invalid email or password');
  if (!u.active) throw new HttpError(403, 'This account has been deactivated. Contact an administrator.');
  r.json({ token: signToken(u), user: publicUser(u) });
}));
router.get('/auth/me', authenticate, wrap(async (q, r) => r.json({ user: publicUser(q.user) })));
router.post('/auth/change-password', authenticate, validate(S.changePwSchema), wrap(async (q, r) => {
  if (!(await bcrypt.compare(q.body.currentPassword, q.user.passwordHash))) throw new HttpError(422, 'Current password is incorrect'); // 422 (not 401) so the client does not treat it as an expired session
  if (q.body.currentPassword === q.body.newPassword) throw new HttpError(422, 'New password must differ from the current one');
  q.user.passwordHash = await bcrypt.hash(q.body.newPassword, 10); q.user.mustChangePassword = false; q.user.tokenVersion += 1; await q.user.save();
  await audit(q.user, 'auth.password.change', 'User', q.user._id);
  r.json({ token: signToken(q.user), user: publicUser(q.user) });
}));

// ---------- users (Admin) ----------
router.post('/users', ...protect, requireRole('admin'), validate(S.userCreateSchema), wrap(async (q, r) => {
  const temp = emp.tempPassword();
  const u = await User.create({ ...q.body, passwordHash: await bcrypt.hash(temp, 10), mustChangePassword: true });
  await audit(q.user, 'user.create', 'User', u._id, null, { email: u.email, role: u.role });
  r.status(201).json({ user: publicUser(u), temporaryPassword: temp });
}));
router.get('/users', ...protect, requireRole('admin'), wrap(async (_q, r) => r.json({ items: (await User.find().sort({ createdAt: 1 }).lean()).map((u) => ({ id: u._id, name: u.name, email: u.email, role: u.role, active: u.active })) })));
router.post('/users/:id/:action(deactivate|activate|reset-password)', ...protect, requireRole('admin'), wrap(async (q, r) => {
  const u = await User.findById(q.params.id); if (!u) throw new HttpError(404, 'User not found');
  const a = q.params.action; let temporaryPassword;
  if (a !== 'reset-password' && String(u._id) === String(q.user._id)) throw new HttpError(422, 'You cannot change your own active status');
  if (a === 'deactivate') { u.active = false; u.tokenVersion += 1; }
  if (a === 'activate') u.active = true;
  if (a === 'reset-password') { temporaryPassword = emp.tempPassword(); u.passwordHash = await bcrypt.hash(temporaryPassword, 10); u.mustChangePassword = true; u.tokenVersion += 1; }
  await u.save(); await audit(q.user, `user.${a}`, 'User', u._id, null, { email: u.email });
  r.json({ user: publicUser(u), ...(temporaryPassword ? { temporaryPassword } : {}) });
}));

// ---------- organisation ----------
router.get('/settings', ...protect, wrap(async (_q, r) => r.json(await getSettings())));
router.put('/settings', ...protect, requireRole('admin'), validate(S.settingsSchema), wrap(async (q, r) => {
  const s = await getSettings(); const before = s.toObject(); Object.assign(s, q.body); await s.save();
  await audit(q.user, 'settings.update', 'Setting', 'main', Object.fromEntries(Object.keys(q.body).map((k) => [k, before[k]])), q.body);
  r.json(s);
}));
for (const [path, Model, label] of [['departments', Department, 'department'], ['designations', Designation, 'designation']]) {
  router.get(`/${path}`, ...protect, wrap(async (_q, r) => r.json({ items: await Model.find().sort({ name: 1 }).lean() })));
  router.post(`/${path}`, ...protect, requireRole('admin'), validate(S.nameSchema), wrap(async (q, r) => { const d = await Model.create(q.body); await audit(q.user, `${label}.create`, Model.modelName, d._id, null, q.body); r.status(201).json(d); }));
  router.delete(`/${path}/:id`, ...protect, requireRole('admin'), wrap(async (q, r) => {
    if (await Employee.exists({ [label]: q.params.id })) throw new HttpError(409, `This ${label} is in use by employees`);
    const d = await Model.findByIdAndDelete(q.params.id); if (!d) throw new HttpError(404, 'Not found');
    await audit(q.user, `${label}.delete`, Model.modelName, d._id, { name: d.name }, null); r.json({ deleted: true });
  }));
}

// ---------- employees ----------
router.get('/employees/me', ...protect, wrap(async (q, r) => r.json(emp.withSalary(await (await ownEmployee(q.user)).populate('department designation')))));
router.put('/employees/me', ...protect, validate(S.profileSchema), wrap(async (q, r) => { const e = await ownEmployee(q.user); r.json(await emp.updateEmployee(q.user, e._id, q.body)); }));
router.get('/employees/export', ...protect, staff, wrap(async (_q, r) => { r.type('text/csv').attachment('employees.csv').send(await emp.exportCsv()); }));
router.post('/employees/import', ...protect, staff, validate(S.csvSchema), wrap(async (q, r) => r.json(await emp.importCsv(q.user, q.body.csv, q.query.dryRun !== 'false'))));
router.get('/employees', ...protect, staff, wrap(async (q, r) => r.json(await emp.listEmployees(q.query))));
router.post('/employees', ...protect, staff, validate(S.employeeCreateSchema), wrap(async (q, r) => { const out = await emp.registerEmployee(q.user, q.body); r.status(201).json({ employee: emp.withSalary(out.employee), temporaryPassword: out.temporaryPassword }); }));
router.get('/employees/:id', ...protect, wrap(async (q, r) => {
  if (!['admin', 'hr'].includes(q.user.role) && String(q.user.employee) !== q.params.id) throw new HttpError(403, 'You can only view your own profile');
  const e = await Employee.findById(q.params.id).populate('department designation'); if (!e) throw new HttpError(404, 'Employee not found');
  r.json(emp.withSalary(e));
}));
router.put('/employees/:id', ...protect, staff, validate(S.employeeUpdateSchema), wrap(async (q, r) => {
  const existing = await Employee.findById(q.params.id).lean(); if (!existing) throw new HttpError(404, 'Employee not found');
  const plan = planEmployeeUpdate({ actorRole: q.user.role, existing, patch: q.body, today: ctxFrom(await getSettings()).today });
  if (plan.error) throw new HttpError(plan.error.status, plan.error.message);
  if (plan.patch.email && plan.patch.email !== existing.email && (await User.exists({ email: plan.patch.email, _id: { $ne: existing.user } }))) throw new HttpError(409, 'That email is already used by another account');
  const e = await emp.updateEmployee(q.user, q.params.id, plan.patch);
  if (plan.deactivateUser) await User.updateOne({ _id: e.user }, { active: false, $inc: { tokenVersion: 1 } });
  if (plan.reactivateUser) await User.updateOne({ _id: e.user }, { active: true });
  r.json(emp.withSalary(e));
}));
router.post('/employees/:id/:action(reset-password|deactivate|activate)', ...protect, requireRole('admin'), wrap(async (q, r) => {
  const e = await Employee.findById(q.params.id); if (!e?.user) throw new HttpError(404, 'Employee not found');
  const u = await User.findById(e.user); const a = q.params.action; let temporaryPassword;
  if (a === 'deactivate') { u.active = false; u.tokenVersion += 1; } if (a === 'activate') u.active = true;
  if (a === 'reset-password') { temporaryPassword = emp.tempPassword(); u.passwordHash = await bcrypt.hash(temporaryPassword, 10); u.mustChangePassword = true; u.tokenVersion += 1; }
  await u.save(); await audit(q.user, `user.${a}`, 'User', u._id, null, { email: u.email }); r.json({ ok: true, ...(temporaryPassword ? { temporaryPassword } : {}) });
}));

// ---------- attendance ----------
router.post('/attendance/check-in', ...protect, requireRole('employee'), validate(S.checkSchema), wrap(async (q, r) => r.status(201).json(await att.checkIn(q.user, q.body))));
router.post('/attendance/check-out', ...protect, requireRole('employee'), validate(S.checkSchema), wrap(async (q, r) => r.json(await att.checkOut(q.user, q.body))));
router.get('/attendance/me', ...protect, requireRole('employee'), wrap(async (q, r) => {
  const ctx = ctxFrom(await getSettings()); const month = /^\d{4}-\d{2}$/.test(q.query.month || '') ? q.query.month : ctx.today.slice(0, 7);
  const { from, to } = monthRange(month); r.json(await att.myMonth(q.user, from, to));
}));
router.get('/attendance/board', ...protect, staff, wrap(async (q, r) => { const ctx = ctxFrom(await getSettings()); const date = isDateStr(q.query.date) ? q.query.date : ctx.today; r.json({ date, items: await att.board(date, cleanDept(q.query.department)) }); }));
router.get('/attendance/summary', ...protect, staff, wrap(async (q, r) => {
  const ctx = ctxFrom(await getSettings()); const to = q.query.to || ctx.today;
  const { from, to: end } = rangeOrThrow(q.query.from, to, { today: ctx.today, defaultFrom: `${to.slice(0, 7)}-01` });
  r.json(await att.summary({ from, to: end, department: cleanDept(q.query.department) }));
}));
router.post('/attendance/corrections', ...protect, requireRole('employee'), validate(S.correctionSchema), wrap(async (q, r) => r.status(201).json(await att.requestCorrection(q.user, q.body))));
router.get('/attendance/corrections', ...protect, wrap(async (q, r) => {
  const f = {}; if (q.query.status) f.status = q.query.status;
  if (q.user.role === 'employee') f.employee = q.user.employee; else if (q.user.role !== 'hr' && q.user.role !== 'admin') throw new HttpError(403, 'Forbidden');
  r.json({ items: await Correction.find(f).sort({ createdAt: -1 }).limit(100).populate('employee', 'code firstName lastName').lean() });
}));
router.post('/attendance/corrections/:id/decision', ...protect, requireRole('hr'), validate(S.decisionSchema), wrap(async (q, r) => r.json(await att.decideCorrection(q.user, q.params.id, q.body))));

// ---------- leave ----------
router.get('/leave/balance', ...protect, requireRole('employee'), wrap(async (q, r) => r.json({ balances: await lv.myBalances(q.user) })));
router.get('/leave/mine', ...protect, requireRole('employee'), wrap(async (q, r) => r.json(await lv.list({ employee: q.user.employee }, pageParams(q.query)))));
router.post('/leave', ...protect, requireRole('employee'), validate(S.leaveApplySchema), wrap(async (q, r) => r.status(201).json(await lv.apply(q.user, q.body))));
router.post('/leave/smart', ...protect, requireRole('employee'), aiLimiter, validate(S.smartLeaveSchema), wrap(async (q, r) => r.json(await ai.smartLeave(q.user, q.body.text))));
router.post('/leave/:id/cancel', ...protect, requireRole('employee'), wrap(async (q, r) => r.json(await lv.cancel(q.user, q.params.id))));
router.get('/leave', ...protect, staff, wrap(async (q, r) => { const f = {}; if (q.query.status) f.status = q.query.status; r.json(await lv.list(f, pageParams(q.query))); }));
router.post('/leave/:id/decision', ...protect, requireRole('hr'), validate(S.decisionSchema), wrap(async (q, r) => r.json(await lv.decide(q.user, q.params.id, q.body))));

// ---------- payroll ----------
router.post('/payroll/drafts', ...protect, requireRole('hr'), validate(S.monthSchema), wrap(async (q, r) => r.status(201).json(await pay.createDraft(q.user, q.body.month))));
router.get('/payroll', ...protect, staff, wrap(async (_q, r) => r.json({ items: await PayrollRun.find().select('-items').sort({ month: -1 }).lean() })));
router.get('/payroll/mine', ...protect, requireRole('employee'), wrap(async (q, r) => r.json({ items: await pay.myPayslips(q.user.employee) })));
router.get('/payroll/:id', ...protect, staff, wrap(async (q, r) => { const run = await PayrollRun.findById(q.params.id); if (!run) throw new HttpError(404, 'Payroll run not found'); r.json(run); }));
router.post('/payroll/:id/finalize', ...protect, requireRole('admin'), wrap(async (q, r) => r.json(await pay.finalize(q.user, q.params.id))));
router.get('/payroll/:id/payslip/:employeeId?', ...protect, wrap(async (q, r) => {
  const own = q.user.role === 'employee';
  const employeeId = own ? String(q.user.employee) : q.params.employeeId;
  if (!employeeId) throw new HttpError(404, 'Employee id required');
  const { run, item, stream } = await pay.payslipPdf(q.params.id, employeeId, (await getSettings()).companyName);
  if (own && run.status !== 'finalized') throw new HttpError(403, 'Payslip is not available yet');
  r.type('application/pdf').set('Content-Disposition', `attachment; filename="payslip-${run.month}-${item.code}.pdf"`); stream.pipe(r);
}));

// ---------- dashboards & AI ----------
router.get('/dashboard/admin', ...protect, requireRole('admin'), wrap(async (q, r) => r.json(await dash.adminDashboard(q.query))));
router.get('/dashboard/hr', ...protect, requireRole('hr'), wrap(async (q, r) => r.json(await dash.hrDashboard(q.query))));
router.get('/dashboard/employee', ...protect, requireRole('employee'), wrap(async (q, r) => r.json(await dash.employeeDashboard(q.user))));
router.get('/insights/employees', ...protect, staff, wrap(async (q, r) => r.json(await insights.employeeInsights(q.query))));
router.post('/ai/chat', ...protect, aiLimiter, validate(S.chatSchema), wrap(async (q, r) => r.json(await ai.chat(q.user, q.body.message))));
router.post('/ai/summarize', ...protect, staff, aiLimiter, wrap(async (q, r) => r.json(await ai.summarizeDashboard(q.user, { from: q.body?.from, to: q.body?.to, department: q.body?.department }))));

// ---------- communications & audit ----------
router.get('/announcements', ...protect, wrap(async (_q, r) => r.json({ items: await Announcement.find().sort({ createdAt: -1 }).limit(50).lean() })));
router.post('/announcements', ...protect, staff, validate(S.announcementSchema), wrap(async (q, r) => {
  const a = await Announcement.create({ ...q.body, author: q.user._id, authorName: q.user.name }); await audit(q.user, 'announcement.create', 'Announcement', a._id, null, q.body); r.status(201).json(a);
}));
router.get('/notifications', ...protect, wrap(async (q, r) => r.json({ items: await Notification.find({ user: q.user._id }).sort({ createdAt: -1 }).limit(50).lean(), unread: await Notification.countDocuments({ user: q.user._id, read: false }) })));
router.post('/notifications/read-all', ...protect, wrap(async (q, r) => { await Notification.updateMany({ user: q.user._id, read: false }, { read: true }); r.json({ ok: true }); }));
router.get('/audit-logs', ...protect, requireRole('admin'), wrap(async (q, r) => {
  const { skip, limit, page } = pageParams(q.query); const f = {}; if (q.query.action) f.action = new RegExp(`^${String(q.query.action).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`);
  const [items, total] = await Promise.all([AuditLog.find(f).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(), AuditLog.countDocuments(f)]);
  r.json({ items, total, page });
}));

// Challenge-brief ILLUSTRATIVE payroll tax. Not official tax advice.
// Marginal interpretation: fixed amount = tax at the previous bracket's upper limit.
export const TAX_BRACKETS = [
  { upTo: 600000, base: 0, rate: 0, lower: 0 },
  { upTo: 1200000, base: 0, rate: 0.05, lower: 600000 },
  { upTo: 2400000, base: 30000, rate: 0.15, lower: 1200000 },
  { upTo: 3600000, base: 210000, rate: 0.25, lower: 2400000 },
  { upTo: Infinity, base: 510000, rate: 0.35, lower: 3600000 },
];

export function annualTax(annualGross) {
  if (!(annualGross > 0)) return 0;
  const b = TAX_BRACKETS.find((x) => annualGross <= x.upTo);
  return b.base + (annualGross - b.lower) * b.rate;
}

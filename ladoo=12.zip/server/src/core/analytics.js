// Metric formulas. Zero denominators return 0 (documented in docs/assumptions-and-ambiguities.md).
const div = (a, b) => (b > 0 ? a / b : 0);
const pct = (a, b) => Math.round(div(a, b) * 10000) / 100;

export const attendanceRate = ({ present = 0, late = 0, missing_checkout = 0, half_day = 0, working = 0, on_leave = 0 }) =>
  pct(present + late + missing_checkout + 0.5 * half_day, working - on_leave);
export const latePercentage = ({ present = 0, late = 0 }) => pct(late, present + late);
export const absenteeismRate = ({ absent = 0, expected = 0 }) => pct(absent, expected);
export const attritionRate = ({ exits = 0, startHeadcount = 0, endHeadcount = 0 }) => pct(exits, (startHeadcount + endHeadcount) / 2);
export const leaveUtilization = ({ approvedDays = 0, quotaDays = 0 }) => pct(approvedDays, quotaDays);

/** Count statuses from an array of per-day status strings. */
export function tally(statuses) {
  const t = { present: 0, late: 0, half_day: 0, missing_checkout: 0, absent: 0, on_leave: 0, working: 0 };
  for (const s of statuses) {
    if (s in t) t[s]++;
    if (['present', 'late', 'half_day', 'missing_checkout', 'absent', 'on_leave'].includes(s)) t.working++;
  }
  return t;
}

const R = 6371000;
const rad = (d) => (d * Math.PI) / 180;

export function haversineMeters(lat1, lng1, lat2, lng2) {
  const dLat = rad(lat2 - lat1), dLng = rad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(rad(lat1)) * Math.cos(rad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(a)));
}

export const MAX_GPS_ACCURACY_M = 100;

/** Returns { ok, reason?, distance } */
export function validateLocation({ lat, lng, accuracy }, office) {
  if (![lat, lng, accuracy].every((v) => typeof v === 'number' && Number.isFinite(v))) return { ok: false, reason: 'Location is missing or invalid.' };
  if (accuracy > MAX_GPS_ACCURACY_M) return { ok: false, reason: 'GPS accuracy is worse than 100 metres.' };
  if (!office || office.lat == null || office.lng == null) return { ok: false, reason: 'Office location is not configured.' };
  const distance = haversineMeters(lat, lng, office.lat, office.lng);
  if (distance > (office.radiusMeters ?? 100)) return { ok: false, reason: 'You are outside the office radius.', distance };
  return { ok: true, distance };
}

/**
 * Decide how a check-in/out request is verified. Pure.
 * Returns { source:'web' } | { source:'web_geo', geo } | { error: { status, message } }.
 * A location is only demanded when the company requires it; if the office is not configured and location is
 * optional, a supplied location is ignored rather than blocking attendance.
 */
export function decideProof({ requireLocation, office, body }) {
  const hasGeo = body && body.lat != null;
  const officeSet = !!office && office.lat != null && office.lng != null;
  if (!requireLocation && (!hasGeo || !officeSet)) return { source: 'web' };
  if (body?.faceCount != null && body.faceCount !== 1) return { error: { status: 422, message: body.faceCount === 0 ? 'No face detected. Use an HR correction if the camera is unavailable.' : 'Multiple faces detected.' } };
  const v = validateLocation({ lat: body?.lat, lng: body?.lng, accuracy: body?.accuracy }, office);
  if (!v.ok) return { error: { status: 422, message: `${v.reason} You can request an attendance correction instead.` } };
  return { source: 'web_geo', geo: { lat: body.lat, lng: body.lng, accuracy: body.accuracy, distance: Math.round(v.distance) } };
}

import { countWorkingDays, eachDate, isWorkingDay, isDateStr } from './dates.js';

export const workingLeaveDays = (start, end, weekendDays, holidays) => countWorkingDays(start, end, weekendDays, holidays);
export const leaveDateSet = (reqs, weekendDays, holidays) => {
  const s = new Set();
  for (const r of reqs) for (const d of eachDate(r.start, r.end)) if (isWorkingDay(d, weekendDays, holidays)) s.add(d);
  return s;
};
export const rangesOverlap = (aStart, aEnd, bStart, bEnd) => aStart <= bEnd && aEnd >= bStart;

/** Returns null if OK, otherwise { status: 422, message } */
export function validateLeave({ start, end, type, leaveType, existing, usedDays, days }) {
  if (!isDateStr(start) || !isDateStr(end)) return { message: 'Dates must be valid ISO dates (YYYY-MM-DD).' };
  if (end < start) return { message: 'End date cannot be before start date.' };
  if (start.slice(0, 4) !== end.slice(0, 4)) return { message: 'Leave spanning two calendar years must be split into two requests.' };
  if (!leaveType) return { message: 'Unknown leave type.' };
  if (days <= 0) return { message: 'The selected dates contain no working days.' };
  if (existing.some((r) => rangesOverlap(start, end, r.start, r.end))) return { message: 'This request overlaps an existing pending or approved leave.' };
  if (leaveType.quota != null && usedDays + days > leaveType.quota) return { message: `Insufficient ${leaveType.name} balance: ${Math.max(0, leaveType.quota - usedDays)} day(s) left, ${days} requested.` };
  return null;
}

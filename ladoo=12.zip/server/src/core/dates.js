// Pure date helpers. All business dates are 'YYYY-MM-DD' strings in the company timezone.
const pad = (n) => String(n).padStart(2, '0');

export function toDateStr(date, tz = 'Asia/Karachi') {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
}

export function minutesOfDay(date, tz = 'Asia/Karachi') {
  const parts = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(date);
  const h = Number(parts.find((p) => p.type === 'hour').value);
  const m = Number(parts.find((p) => p.type === 'minute').value);
  return h * 60 + m;
}

export function hhmmToMinutes(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

const parse = (s) => { const [y, m, d] = s.split('-').map(Number); return Date.UTC(y, m - 1, d); };
const fmt = (ms) => { const d = new Date(ms); return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`; };

export const isDateStr = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && fmt(parse(s)) === s;
export const weekdayOf = (s) => new Date(parse(s)).getUTCDay(); // 0 = Sunday
export const addDays = (s, n) => fmt(parse(s) + n * 86400000);
export const monthRange = (ym) => { const [y, m] = ym.split('-').map(Number); const last = new Date(Date.UTC(y, m, 0)).getUTCDate(); return { from: `${ym}-01`, to: `${ym}-${pad(last)}` }; };

export function* eachDate(from, to) {
  for (let t = parse(from); t <= parse(to); t += 86400000) yield fmt(t);
}

export function isWorkingDay(dateStr, weekendDays = [0, 6], holidays = new Set()) {
  return !weekendDays.includes(weekdayOf(dateStr)) && !holidays.has(dateStr);
}

export function countWorkingDays(from, to, weekendDays, holidays) {
  let n = 0;
  for (const d of eachDate(from, to)) if (isWorkingDay(d, weekendDays, holidays)) n++;
  return n;
}

// Convert a wall-clock date + 'HH:MM' in `tz` into a UTC Date.
export function zonedToUtc(dateStr, hhmm, tz = 'Asia/Karachi') {
  const [h, mi] = hhmm.split(':').map(Number);
  const [y, mo, d] = dateStr.split('-').map(Number);
  const guess = Date.UTC(y, mo - 1, d, h, mi);
  const asTz = (ms) => {
    const p = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).formatToParts(new Date(ms));
    const g = (t) => Number(p.find((x) => x.type === t).value);
    return Date.UTC(g('year'), g('month') - 1, g('day'), g('hour'), g('minute'));
  };
  const offset = asTz(guess) - guess;
  return new Date(guess - offset);
}

export const MAX_RANGE_DAYS = 400;
/** Number of calendar days in [from, to] inclusive (0 if invalid or reversed). */
export const daysBetween = (from, to) => (isDateStr(from) && isDateStr(to) && to >= from ? Math.round((parse(to) - parse(from)) / 86400000) + 1 : 0);
/** Validate/normalise a report range. Returns { from, to } or { error }. Bounds the work a single request can trigger. */
export function resolveRange(from, to, { today, defaultFrom } = {}) {
  const t = to ?? today; const f = from ?? defaultFrom;
  if (!isDateStr(t) || !isDateStr(f)) return { error: 'from/to must be valid dates (YYYY-MM-DD)' };
  if (t < f) return { error: 'The end date cannot be before the start date' };
  if (daysBetween(f, t) > MAX_RANGE_DAYS) return { error: `Date range cannot exceed ${MAX_RANGE_DAYS} days` };
  return { from: f, to: t };
}

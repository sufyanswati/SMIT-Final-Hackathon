// Express' default query parser turns `?status[$ne]=x` into an object (NoSQL operator injection) and
// `?a=1&a=2` into an array. Every query value in this API is a plain string, so anything else is rejected.
export function firstNonStringParam(query) {
  for (const [k, v] of Object.entries(query || {})) if (typeof v !== 'string') return k;
  return null;
}

import { annualTax } from './tax.js';

export const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

export function salaryStructure(basic) {
  return { basic: round2(basic), hra: round2(basic * 0.4), medical: round2(basic * 0.1), gross: round2(basic * 1.5) };
}

/**
 * Monthly payroll for one employee.
 *  workingDays   – working days in the whole month (weekends/holidays excluded)
 *  employedDays  – working days inside the employment period within the month (joiner/leaver proration)
 *  absent, unpaidLeave, halfDays – counted only inside the employment period
 * Per-day rate = full monthly gross / month working days.
 * Earned gross = gross * employedDays / workingDays.
 * Tax = annualTax(earnedGross * 12) / 12 (brief slabs on annualized gross, before attendance deductions).
 */
export function computePayroll({ basic, workingDays, employedDays, absent = 0, unpaidLeave = 0, halfDays = 0, latePenaltyDays = 0 }) {
  const s = salaryStructure(basic);
  if (workingDays <= 0) return { ...s, workingDays, employedDays: 0, earnedGross: 0, perDay: 0, deductionDays: 0, deduction: 0, annualGross: 0, tax: 0, net: 0 };
  const ratio = Math.min(1, Math.max(0, employedDays / workingDays));
  const earnedGross = s.gross * ratio;
  const perDay = s.gross / workingDays;
  const deductionDays = absent + unpaidLeave + 0.5 * halfDays + latePenaltyDays;
  const deduction = Math.min(earnedGross, perDay * deductionDays);
  const annualGross = earnedGross * 12;
  const tax = annualTax(annualGross) / 12;
  const net = Math.max(0, earnedGross - deduction - tax);
  return {
    ...s, workingDays, employedDays, absent, unpaidLeave, halfDays, latePenaltyDays,
    earnedGross: round2(earnedGross), perDay: round2(perDay), deductionDays, deduction: round2(deduction),
    annualGross: round2(annualGross), tax: round2(tax), net: round2(net),
  };
}

import { minutesOfDay, hhmmToMinutes } from './dates.js';

export const HALF_DAY_MINUTES = 5 * 60;

export function isLate(checkIn, { officeStart = '09:00', graceMinutes = 15, tz = 'Asia/Karachi' } = {}) {
  return minutesOfDay(checkIn, tz) > hhmmToMinutes(officeStart) + graceMinutes;
}

/**
 * Derive the status of one attendance record.
 * Precedence: missing_checkout (day closed, no check-out) > half_day (<5h worked) > late > present.
 * `dayClosed` is false for today so an open session is not yet "missing_checkout".
 */
export function deriveStatus(rec, opts = {}, dayClosed = true) {
  if (!rec || !rec.checkIn) return null;
  if (!rec.checkOut) return dayClosed ? 'missing_checkout' : (isLate(rec.checkIn, opts) ? 'late' : 'present');
  const worked = (new Date(rec.checkOut) - new Date(rec.checkIn)) / 60000;
  if (worked < HALF_DAY_MINUTES) return 'half_day';
  return isLate(rec.checkIn, opts) ? 'late' : 'present';
}

export const workedMinutes = (rec) => (rec?.checkIn && rec?.checkOut ? Math.max(0, Math.round((new Date(rec.checkOut) - new Date(rec.checkIn)) / 60000)) : 0);

/**
 * Status of a single calendar day for one employee.
 * Order: before joining/after exit -> n/a; weekend/holiday; approved leave; record; future; absent.
 */
export function dayStatus({ date, today, weekendDays, holidays, leaveDates, record, opts, joiningDate, exitDate }) {
  if ((joiningDate && date < joiningDate) || (exitDate && date > exitDate)) return 'n/a';
  const weekend = weekendDays.includes(new Date(`${date}T00:00:00Z`).getUTCDay());
  if (weekend) return 'weekend';
  if (holidays.has(date)) return 'holiday';
  if (leaveDates.has(date)) return 'on_leave';
  if (record) return deriveStatus(record, opts, date < today);
  if (date > today) return 'future';
  if (date === today) return 'not_checked_in';
  return 'absent';
}

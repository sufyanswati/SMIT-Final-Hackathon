// Pure rules for employee updates. No dependencies, so they are unit-testable without a database.
// Returns { patch, deactivateUser, reactivateUser } or { error: { status, message } }.
//
// Exiting an employee is an Admin-only action and always means three things together: status 'exited',
// an exit date, and a disabled login. HR may edit everything else. Reinstating (exited -> active/probation)
// is Admin-only, clears the exit date and re-enables the login.
export function planEmployeeUpdate({ actorRole, existing, patch, today }) {
  const isAdmin = actorRole === 'admin';
  const out = { ...patch };
  const wasExited = existing.status === 'exited';
  const setsExitDate = 'exitDate' in out && out.exitDate;
  const becomesExited = !wasExited && (out.status === 'exited' || (!!setsExitDate && out.status === undefined));
  const leavesExited = wasExited && out.status !== undefined && out.status !== 'exited';

  if (!isAdmin && ('exitDate' in out || out.status === 'exited')) return { error: { status: 403, message: 'Only an administrator can exit an employee or set an exit date' } };
  if (!isAdmin && leavesExited) return { error: { status: 403, message: 'Only an administrator can reinstate an exited employee' } };
  if (!wasExited && setsExitDate && out.status !== undefined && out.status !== 'exited') return { error: { status: 422, message: 'An exit date requires the status to be exited' } };

  if (becomesExited) { out.status = 'exited'; out.exitDate = out.exitDate || today; }
  if (leavesExited) out.exitDate = null;

  const joining = out.joiningDate ?? existing.joiningDate;
  const exit = 'exitDate' in out ? out.exitDate : existing.exitDate;
  if (exit && joining && exit < joining) return { error: { status: 422, message: 'Exit date cannot be before the joining date' } };

  return { patch: out, deactivateUser: becomesExited, reactivateUser: leavesExited };
}

// Pure, dependency-free HR insight rules. All thresholds are documented in docs/assumptions-and-ambiguities.md.
// Input "days" = [{ date, status }] from services/days.js::buildDays (statuses: present, late, half_day, missing_checkout, absent, on_leave, weekend, holiday, ...).

export const DEFAULT_LATE_RULE = { enabled: false, freeLates: 3, lateBlock: 3, deductionDaysPerBlock: 0.5 };

/**
 * Late-arrival penalty. Opt-in (enabled=false by default, so no policy is imposed silently).
 * First `freeLates` late days in the month are free; each full `lateBlock` of late days beyond that costs `deductionDaysPerBlock` of a day's pay.
 */
export function latePenaltyDays(lateCount, rule = {}) {
  const r = { ...DEFAULT_LATE_RULE, ...rule };
  if (!r.enabled || !(lateCount > r.freeLates) || r.lateBlock < 1) return 0;
  return Math.floor((lateCount - r.freeLates) / r.lateBlock) * r.deductionDaysPerBlock;
}

const WORKING = new Set(['present', 'late', 'half_day', 'missing_checkout', 'absent']);

/** Attendance anomaly flags for one employee over a date-sorted window. Returns [{ code, severity, message }]. */
export function anomalyFlags(days) {
  const flags = [];
  const ds = [...days].sort((a, b) => (a.date < b.date ? -1 : 1)).filter((d) => !['n/a', 'future', 'not_checked_in'].includes(d.status));
  const count = (s) => ds.filter((d) => d.status === s).length;
  // 1. three late arrivals in a row (consecutive working days)
  let run = 0, maxRun = 0;
  for (const d of ds.filter((x) => WORKING.has(x.status) || x.status === 'on_leave')) { run = d.status === 'late' ? run + 1 : 0; maxRun = Math.max(maxRun, run); }
  if (maxRun >= 3) flags.push({ code: 'consecutive_late', severity: 'medium', message: `${maxRun} late arrivals in a row` });
  // 2. repeated missing check-out
  if (count('missing_checkout') >= 3) flags.push({ code: 'repeated_missing_checkout', severity: 'low', message: `${count('missing_checkout')} days without a check-out` });
  // 3. absence glued to a weekend/holiday (Mon/Fri pattern): absent day whose neighbouring calendar day is weekend/holiday
  const byDate = new Map(ds.map((d) => [d.date, d.status]));
  const nb = (date, delta) => { const t = new Date(`${date}T00:00:00Z`); t.setUTCDate(t.getUTCDate() + delta); return t.toISOString().slice(0, 10); };
  const edgeAbsences = ds.filter((d) => d.status === 'absent' && ['weekend', 'holiday'].includes(byDate.get(nb(d.date, -1))) || d.status === 'absent' && ['weekend', 'holiday'].includes(byDate.get(nb(d.date, 1)))).length;
  if (edgeAbsences >= 3) flags.push({ code: 'weekend_adjacent_absence', severity: 'medium', message: `${edgeAbsences} absences next to a weekend or holiday` });
  // 4. many absences in any 7 calendar-day window
  const abs = ds.filter((d) => d.status === 'absent').map((d) => d.date);
  for (let i = 0; i < abs.length; i++) { const end = nb(abs[i], 6); if (abs.filter((x) => x >= abs[i] && x <= end).length >= 3) { flags.push({ code: 'absence_cluster', severity: 'high', message: '3 or more absences within 7 days' }); break; }}
  // 5. repeated short days
  if (count('half_day') >= 3) flags.push({ code: 'repeated_half_day', severity: 'low', message: `${count('half_day')} short days (under 5 hours)` });
  return flags;
}

/**
 * Per-employee attrition RISK (a heuristic score, NOT a trained model and NOT the company attrition rate).
 * Points: absenteeism up to 30, lateness up to 20, anomaly flags up to 20, tenure under 1 year 15, pay under 80% of department average 15.
 * Level: >=60 high, >=30 medium, else low. Always returns the factors so the score is explainable.
 */
export function attritionRisk({ days, tenureYears, basicSalary, deptAverageBasic, flags }) {
  const st = (s) => days.filter((d) => d.status === s).length;
  const worked = ['present', 'late', 'half_day', 'missing_checkout', 'absent'].reduce((a, s) => a + st(s), 0);
  const factors = []; let score = 0;
  const add = (pts, label) => { if (pts > 0) { score += pts; factors.push({ points: Math.round(pts), label }); } };
  if (worked >= 5) {
    const absRate = st('absent') / worked, lateRate = st('late') / worked;
    add(Math.min(30, absRate * 150), `Absent on ${Math.round(absRate * 100)}% of working days`);
    add(Math.min(20, lateRate * 80), `Late on ${Math.round(lateRate * 100)}% of working days`);
  }
  const f = flags ?? anomalyFlags(days);
  add(Math.min(20, f.reduce((a, x) => a + (x.severity === 'high' ? 10 : x.severity === 'medium' ? 6 : 3), 0)), `${f.length} attendance anomaly flag(s)`);
  if (tenureYears != null && tenureYears < 1) add(15, 'Less than 1 year of service');
  if (deptAverageBasic > 0 && basicSalary < deptAverageBasic * 0.8) add(15, 'Pay is below 80% of the department average');
  score = Math.min(100, Math.round(score));
  return { score, level: score >= 60 ? 'high' : score >= 30 ? 'medium' : 'low', factors, enoughData: worked >= 5 };
}

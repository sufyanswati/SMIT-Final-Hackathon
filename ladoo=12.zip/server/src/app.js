import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import mongoose from 'mongoose';
import { env } from './config/env.js';
import { router } from './routes/index.js';
import { errorHandler } from './middleware/http.js';

export function createApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(helmet());
  app.use(cors({ origin: env.clientOrigin.split(',').map((s) => s.trim()), credentials: false }));
  app.use(express.json({ limit: '1mb' }));
  if (!env.isTest) app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 1000, standardHeaders: true, legacyHeaders: false }));
  // Liveness: process is running. Readiness: required MongoDB dependency is connected.
  app.get('/health', (_q, r) => r.json({ ok: true, service: 'ladoo-hcm-api' }));
  app.get('/ready', (_q, r) => {
    const database = mongoose.connection.readyState === 1;
    return r.status(database ? 200 : 503).json({ ready: database, database: database ? 'connected' : 'unavailable' });
  });
  app.use('/api', router);
  app.use('/api', (_q, r) => r.status(404).json({ error: 'Endpoint not found' }));
  app.use(errorHandler);
  return app;
}

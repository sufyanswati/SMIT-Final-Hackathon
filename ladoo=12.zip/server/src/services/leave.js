import { LeaveRequest, Employee, User } from '../models/index.js';
import { HttpError } from '../middleware/http.js';
import { clock, getSettings, ctxFrom, ownEmployee, audit, notify, employeeName } from './common.js';
import { validateLeave, workingLeaveDays } from '../core/leave.js';

const sumDays = (rows) => rows.reduce((a, r) => a + r.days, 0);

export async function balances(employeeId, year, settings) {
  const reqs = await LeaveRequest.find({ employee: employeeId, start: { $gte: `${year}-01-01`, $lte: `${year}-12-31` }, status: { $in: ['approved', 'pending'] } }).lean();
  return settings.leaveTypes.map((t) => {
    const used = sumDays(reqs.filter((r) => r.type === t.key && r.status === 'approved'));
    const pending = sumDays(reqs.filter((r) => r.type === t.key && r.status === 'pending'));
    return { key: t.key, name: t.name, quota: t.quota, used, pending, remaining: t.quota == null ? null : Math.max(0, t.quota - used - pending) };
  });
}

export async function myBalances(user) {
  const emp = await ownEmployee(user); const s = await getSettings(); const ctx = ctxFrom(s);
  return balances(emp._id, ctx.today.slice(0, 4), s);
}

export async function apply(user, { type, start, end, reason }) {
  const emp = await ownEmployee(user); const s = await getSettings(); const ctx = ctxFrom(s);
  const leaveType = s.leaveTypes.find((t) => t.key === type);
  const days = start && end && end >= start ? workingLeaveDays(start, end, ctx.weekendDays, ctx.holidays) : 0;
  const existing = await LeaveRequest.find({ employee: emp._id, status: { $in: ['pending', 'approved'] }, start: { $lte: end || '9999' }, end: { $gte: start || '0000' } }).lean();
  const year = (start || ctx.today).slice(0, 4);
  const bal = (await balances(emp._id, year, s)).find((b) => b.key === type);
  if (emp.status === 'exited') throw new HttpError(403, 'Exited employees cannot apply for leave');
  if (start && start < emp.joiningDate) throw new HttpError(422, `Leave cannot start before your joining date (${emp.joiningDate}).`);
  const err = validateLeave({ start, end, type, leaveType, existing, usedDays: bal ? bal.used + bal.pending : 0, days });
  if (err) throw new HttpError(422, err.message);
  const lr = await LeaveRequest.create({ employee: emp._id, type, start, end, days, reason });
  await audit(user, 'leave.apply', 'LeaveRequest', lr._id, null, lr.toObject());
  return lr;
}

export async function cancel(user, id) {
  const emp = await ownEmployee(user); const ctx = ctxFrom(await getSettings());
  const lr = await LeaveRequest.findOne({ _id: id, employee: emp._id });
  if (!lr) throw new HttpError(404, 'Leave request not found');
  if (lr.status === 'cancelled' || lr.status === 'rejected') throw new HttpError(422, `A ${lr.status} request cannot be cancelled`);
  if (lr.status === 'approved' && lr.start <= ctx.today) throw new HttpError(422, 'Approved leave that has already started cannot be cancelled');
  const before = lr.toObject(); lr.status = 'cancelled'; await lr.save();
  await audit(user, 'leave.cancel', 'LeaveRequest', lr._id, before, lr.toObject());
  return lr;
}

export async function decide(user, id, { approve, comment }) {
  if (!approve && !comment?.trim()) throw new HttpError(422, 'A comment is required when rejecting leave');
  const lr = await LeaveRequest.findOneAndUpdate({ _id: id, status: 'pending' }, { status: approve ? 'approved' : 'rejected', decidedBy: user._id, comment, decidedAt: clock.now() }, { new: true });
  if (!lr) throw new HttpError(409, 'Leave request not found or already decided');
  await audit(user, `leave.${approve ? 'approve' : 'reject'}`, 'LeaveRequest', lr._id, { status: 'pending' }, { status: lr.status, comment });
  const emp = await Employee.findById(lr.employee); const u = emp?.user && (await User.findById(emp.user));
  if (u) await notify(u._id, `Your ${lr.type} leave (${lr.start} to ${lr.end}) was ${lr.status}${comment ? `: ${comment}` : ''}`, 'leave');
  return lr;
}

export async function list(filter, { skip, limit }) {
  const [items, total] = await Promise.all([
    LeaveRequest.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).populate('employee', 'code firstName lastName department').lean(),
    LeaveRequest.countDocuments(filter),
  ]);
  return { items: items.map((i) => ({ ...i, employeeName: i.employee ? employeeName(i.employee) : '' })), total };
}

/** Leave utilisation: approved days in range vs quota, by type (and department). */
export async function leaveSummary({ from, to, department }) {
  const s = await getSettings();
  const empFilter = department ? { department } : {};
  const emps = await Employee.find({ ...empFilter, status: { $ne: 'exited' } }).populate('department').lean();
  const ids = emps.map((e) => e._id);
  const reqs = await LeaveRequest.find({ employee: { $in: ids }, status: 'approved', start: { $lte: to }, end: { $gte: from } }).lean();
  const byType = s.leaveTypes.map((t) => {
    const approvedDays = sumDays(reqs.filter((r) => r.type === t.key));
    const quotaDays = t.quota == null ? 0 : t.quota * emps.length;
    return { type: t.key, name: t.name, approvedDays, quotaDays, utilization: quotaDays ? Math.round((approvedDays / quotaDays) * 10000) / 100 : null };
  });
  const deptBy = {}; const empDept = new Map(emps.map((e) => [String(e._id), e.department?.name || 'Unassigned']));
  for (const r of reqs) { const d = empDept.get(String(r.employee)); deptBy[d] = (deptBy[d] || 0) + r.days; }
  return { from, to, byType, byDepartment: Object.entries(deptBy).map(([department, approvedDays]) => ({ department, approvedDays })) };
}

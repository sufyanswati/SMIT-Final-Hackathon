import { Employee } from '../models/index.js';
import { getSettings, ctxFrom, employeeName, cleanDept } from './common.js';
import { buildDays, employedBetween } from './days.js';
import { addDays } from '../core/dates.js';
import { anomalyFlags, attritionRisk } from '../core/insights.js';

/** Per-employee anomaly flags + attrition RISK over the last `windowDays` (default 90). Staff only (route-guarded). */
export async function employeeInsights(q = {}) {
  const ctx = ctxFrom(await getSettings());
  const windowDays = Math.min(180, Math.max(14, parseInt(q.windowDays) || 90));
  const from = addDays(ctx.today, -(windowDays - 1)), to = ctx.today;
  const department = cleanDept(q.department);
  const emps = (await employedBetween(Employee, from, to, department)).filter((e) => e.status !== 'exited' || (e.exitDate && e.exitDate >= from));
  const live = await Employee.populate(emps, 'department');
  const { days } = await buildDays(live, from, to, ctx);
  const deptAvg = {};
  for (const e of live) { const k = String(e.department?._id); (deptAvg[k] ||= []).push(e.basicSalary); }
  const avg = (k) => { const v = deptAvg[k] || []; return v.length > 1 ? v.reduce((a, b) => a + b, 0) / v.length : 0; };
  const items = live.filter((e) => e.status !== 'exited').map((e) => {
    const ds = days.get(String(e._id)); const flags = anomalyFlags(ds);
    const tenureYears = (new Date(`${to}T00:00:00Z`) - new Date(`${e.joiningDate}T00:00:00Z`)) / 31557600000;
    const risk = attritionRisk({ days: ds, tenureYears, basicSalary: e.basicSalary, deptAverageBasic: avg(String(e.department?._id)), flags });
    return { employee: e._id, code: e.code, name: employeeName(e), department: e.department?.name, flags, risk };
  }).sort((a, b) => b.risk.score - a.risk.score);
  return { window: { from, to }, method: 'rule-based heuristic (not a trained model); see docs/assumptions-and-ambiguities.md', items };
}

import bcrypt from 'bcryptjs';
import { Setting, User } from '../models/index.js';
import { HttpError } from '../middleware/http.js';

export const isInitialized = async () => !!(await Setting.exists({ key: 'main' }));

/** First-run setup. Setting.key is unique, so concurrent callers cannot both win. */
export async function initialize({ companyName, name, email, password }) {
  try { await Setting.create({ key: 'main', companyName }); }
  catch (e) { if (e?.code === 11000) throw new HttpError(409, 'The system has already been set up'); throw e; }
  try {
    return await User.create({ name, email, passwordHash: await bcrypt.hash(password, 10), role: 'admin' });
  } catch (e) { await Setting.deleteOne({ key: 'main' }); throw e; } // roll back the lock if the Admin could not be created
}

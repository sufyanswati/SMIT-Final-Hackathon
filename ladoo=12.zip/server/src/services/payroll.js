import PDFDocument from 'pdfkit';
import { PayrollRun, Employee, LeaveRequest } from '../models/index.js';
import { HttpError } from '../middleware/http.js';
import { clock, getSettings, ctxFrom, audit, notify, employeeName } from './common.js';
import { buildDays } from './days.js';
import { computePayroll, round2 } from '../core/payroll.js';
import { monthRange, countWorkingDays } from '../core/dates.js';
import { leaveDateSet } from '../core/leave.js';
import { latePenaltyDays } from '../core/insights.js';

const MONTH_RE = /^\d{4}-(0[1-9]|1[0-2])$/;

export async function createDraft(user, month) {
  if (!MONTH_RE.test(month)) throw new HttpError(422, 'Month must be YYYY-MM');
  const s = await getSettings(); const ctx = ctxFrom(s);
  if (month > ctx.today.slice(0, 7)) throw new HttpError(422, 'Cannot run payroll for a future month');
  const { from, to } = monthRange(month);
  const monthWorking = countWorkingDays(from, to, ctx.weekendDays, ctx.holidays);
  const emps = await Employee.find({ joiningDate: { $lte: to }, $or: [{ exitDate: null }, { exitDate: { $exists: false } }, { exitDate: { $gte: from } }] }).populate('department designation');
  const { days } = await buildDays(emps, from, to, ctx);
  const unpaidKeys = s.leaveTypes.filter((t) => !t.paid).map((t) => t.key);
  const unpaidReqs = await LeaveRequest.find({ employee: { $in: emps.map((e) => e._id) }, status: 'approved', type: { $in: unpaidKeys }, start: { $lte: to }, end: { $gte: from } }).lean();

  const items = emps.map((e) => {
    const ds = days.get(String(e._id)).filter((d) => d.status !== 'n/a');
    const start = e.joiningDate > from ? e.joiningDate : from; const end = e.exitDate && e.exitDate < to ? e.exitDate : to;
    const employedDays = countWorkingDays(start, end, ctx.weekendDays, ctx.holidays);
    const mine = unpaidReqs.filter((r) => String(r.employee) === String(e._id));
    const unpaid = [...leaveDateSet(mine, ctx.weekendDays, ctx.holidays)].filter((d) => d >= start && d <= end).length;
    const c = computePayroll({ basic: e.basicSalary, workingDays: monthWorking, employedDays,
      absent: ds.filter((d) => d.status === 'absent').length, unpaidLeave: unpaid, halfDays: ds.filter((d) => d.status === 'half_day').length,
      latePenaltyDays: latePenaltyDays(ds.filter((d) => d.status === 'late').length, s.latePenalty?.toObject?.() ?? s.latePenalty) });
    return { employee: e._id, code: e.code, name: employeeName(e), department: e.department?.name, designation: e.designation?.name, ...c };
  });
  const sum = (k) => round2(items.reduce((a, i) => a + i[k], 0));
  const totals = { gross: sum('earnedGross'), deduction: sum('deduction'), tax: sum('tax'), net: sum('net') };
  let run;
  try { run = await PayrollRun.findOneAndUpdate({ month, status: 'draft' }, { month, status: 'draft', items, totals, createdBy: user._id }, { upsert: true, new: true, setDefaultsOnInsert: true }); }
  catch (e) { if (e?.code === 11000) throw new HttpError(422, `Payroll for ${month} is already finalized and locked`); throw e; }
  await audit(user, 'payroll.draft', 'PayrollRun', run._id, null, { month, totals, employees: items.length });
  return run;
}

export async function finalize(user, id) {
  const run = await PayrollRun.findOneAndUpdate({ _id: id, status: 'draft' }, { status: 'finalized', finalizedBy: user._id, finalizedAt: clock.now() }, { new: true });
  if (!run) { const ex = await PayrollRun.exists({ _id: id }); throw new HttpError(ex ? 422 : 404, ex ? 'This payroll run is already finalized and locked' : 'Payroll run not found'); }
  await audit(user, 'payroll.finalize', 'PayrollRun', run._id, { status: 'draft' }, { status: 'finalized', month: run.month, totals: run.totals });
  const emps = await Employee.find({ _id: { $in: run.items.map((i) => i.employee) }, user: { $ne: null } }).select('user');
  await Promise.all(emps.map((e) => notify(e.user, `Your payslip for ${run.month} is ready to download`, 'payslip')));
  return run;
}

export async function latestFinalized() { return PayrollRun.findOne({ status: 'finalized' }).sort({ month: -1 }); }

export async function payrollSummary({ month }) {
  const run = month ? await PayrollRun.findOne({ month }) : await PayrollRun.findOne().sort({ month: -1 });
  if (!run) return { available: false, message: 'No payroll run exists yet.' };
  const byDept = {};
  for (const i of run.items) { const d = (byDept[i.department || 'Unassigned'] ||= { department: i.department || 'Unassigned', gross: 0, net: 0, headcount: 0 }); d.gross += i.earnedGross; d.net += i.net; d.headcount++; }
  return { available: true, month: run.month, status: run.status, totals: run.totals, byDepartment: Object.values(byDept).map((d) => ({ ...d, gross: round2(d.gross), net: round2(d.net) })) };
}

export async function myPayslips(employeeId) {
  const runs = await PayrollRun.find({ status: 'finalized', 'items.employee': employeeId }).sort({ month: -1 });
  return runs.map((r) => { const i = r.items.find((x) => String(x.employee) === String(employeeId)); return { runId: r._id, month: r.month, gross: i.earnedGross, net: i.net }; });
}

export async function payslipPdf(runId, employeeId, companyName) {
  const run = await PayrollRun.findById(runId);
  if (!run) throw new HttpError(404, 'Payroll run not found');
  const item = run.items.find((i) => String(i.employee) === String(employeeId));
  if (!item) throw new HttpError(404, 'Payslip not found');
  return { run, item, stream: renderPdf(run, item, companyName) };
}

function renderPdf(run, i, company) {
  const doc = new PDFDocument({ size: 'A4', margin: 50 });
  const money = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  doc.fontSize(20).text(company || 'Ladoo', { align: 'left' }).fontSize(11).fillColor('#555').text(`Payslip – ${run.month}${run.status === 'draft' ? ' (DRAFT)' : ''}`).moveDown();
  doc.fillColor('#000').fontSize(11).text(`Employee: ${i.name} (${i.code})`).text(`Department: ${i.department || '-'}   Designation: ${i.designation || '-'}`).moveDown();
  const row = (a, b) => { const y = doc.y; doc.text(a, 50, y, { width: 300 }).text(b, 360, y, { width: 185, align: 'right' }); doc.moveDown(0.3); };
  doc.fontSize(12).text('Earnings').moveDown(0.3).fontSize(11);
  row('Basic salary', money(i.basic)); row('House rent allowance (40%)', money(i.hra)); row('Medical allowance (10%)', money(i.medical)); row('Gross (full month)', money(i.gross));
  if (i.employedDays !== i.workingDays) row(`Gross earned (prorated ${i.employedDays}/${i.workingDays} working days)`, money(i.earnedGross));
  doc.moveDown().fontSize(12).text('Attendance').moveDown(0.3).fontSize(11);
  row('Working days in month', String(i.workingDays)); row('Absent days', String(i.absent)); row('Unpaid leave days', String(i.unpaidLeave)); row('Half-days', String(i.halfDays)); row('Late-arrival penalty (days)', String(i.latePenaltyDays || 0)); row('Deduction day-equivalents', String(i.deductionDays)); row('Per-day rate', money(i.perDay));
  doc.moveDown().fontSize(12).text('Deductions').moveDown(0.3).fontSize(11);
  row('Absence / unpaid leave deduction', money(i.deduction)); row('Income tax (illustrative slabs)', money(i.tax));
  doc.moveDown().fontSize(14).text(`Net pay: ${money(i.net)}`, { align: 'right' }).moveDown().fontSize(8).fillColor('#777').text('Tax is calculated using the Saylani HCM Lite challenge brief\'s illustrative slabs and is not official tax advice.');
  doc.end();
  return doc;
}

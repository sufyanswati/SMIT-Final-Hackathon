import { Setting, AuditLog, Notification, Employee } from '../models/index.js';
import { HttpError } from '../middleware/http.js';
import { toDateStr, resolveRange } from '../core/dates.js';

export const clock = { now: () => new Date() }; // server is the only source of time (overridable in tests)

export async function getSettings() {
  const s = await Setting.findOne({ key: 'main' });
  if (!s) throw new HttpError(409, 'Company is not set up yet', { code: 'SETUP_REQUIRED' });
  return s;
}

export function ctxFrom(s) {
  return {
    tz: s.timezone,
    weekendDays: s.weekendDays,
    holidays: new Set(s.holidays.map((h) => h.date)),
    opts: { officeStart: s.officeStart, graceMinutes: s.graceMinutes, tz: s.timezone },
    today: toDateStr(clock.now(), s.timezone),
  };
}

export async function audit(actor, action, entity, entityId, before, after) {
  await AuditLog.create({ actor: actor?._id, actorName: actor?.name, action, entity, entityId: entityId ? String(entityId) : undefined, before, after });
}

export const notify = (userId, message, kind = 'info') => (userId ? Notification.create({ user: userId, message, kind }) : null);

/** The employee record owned by the authenticated user. Never trusts a client-supplied id. */
export async function ownEmployee(user) {
  if (!user.employee) throw new HttpError(403, 'No employee profile is linked to this account');
  const e = await Employee.findById(user.employee);
  if (!e) throw new HttpError(404, 'Employee profile not found');
  return e;
}

export const pageParams = (q) => {
  const page = Math.max(1, parseInt(q.page) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(q.limit) || 20));
  return { page, limit, skip: (page - 1) * limit };
};

/** Validate an optional department id coming from a query string. */
export function cleanDept(v) {
  if (v == null || v === '') return undefined;
  if (!/^[a-f\d]{24}$/i.test(String(v))) throw new HttpError(400, 'Invalid department id');
  return String(v);
}

export function rangeOrThrow(from, to, opts) {
  const r = resolveRange(from || undefined, to || undefined, opts);
  if (r.error) throw new HttpError(400, r.error);
  return r;
}

export const employeeName = (e) => `${e.firstName} ${e.lastName}`;

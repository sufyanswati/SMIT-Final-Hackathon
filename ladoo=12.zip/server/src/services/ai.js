import { z } from 'zod';
import { env } from '../config/env.js';
import { AiLog, Employee, Department } from '../models/index.js';
import { HttpError } from '../middleware/http.js';
import { getSettings, ctxFrom, ownEmployee, employeeName } from './common.js';
import * as att from './attendance.js';
import * as lv from './leave.js';
import * as pay from './payroll.js';
import { headcountAt, adminDashboard, hrDashboard } from './dashboard.js';
import { isDateStr, addDays } from '../core/dates.js';

const TIMEOUT_MS = 15000, HOURLY_LIMIT = 20;
const fn = (name, description, properties = {}) => ({ type: 'function', function: { name, description, parameters: { type: 'object', properties, additionalProperties: false } } });
const range = { from: { type: 'string', description: 'YYYY-MM-DD' }, to: { type: 'string', description: 'YYYY-MM-DD' } };
export const TOOL_DEFS = [
  fn('get_headcount', 'Current number of active and probation employees, optionally for one department name.', { department: { type: 'string' } }),
  fn('get_attendance_summary', 'Attendance totals, attendance rate, late % and absenteeism for a date range.', { ...range, department: { type: 'string' } }),
  fn('get_late_comers', 'Employees with the most late arrivals in a date range.', { ...range, limit: { type: 'number' } }),
  fn('get_leave_summary', 'Approved leave days and utilisation by leave type and department for a range.', { ...range, department: { type: 'string' } }),
  fn('get_my_leave_balance', 'The signed-in user\'s own leave balances for the current year.'),
  fn('get_payroll_summary', 'Payroll totals and department breakdown for a month (YYYY-MM). Employees only see their own latest payslip.', { month: { type: 'string' } }),
  fn('search_employees', 'Search employees by name, code or email. Returns directory info only.', { query: { type: 'string' }, department: { type: 'string' } }),
];

const isStaff = (u) => u.role === 'admin' || u.role === 'hr';
const deny = (msg = 'You are not permitted to access that information.') => ({ error: 'forbidden', message: msg });

async function deptId(name) { if (!name) return undefined; const d = await Department.findOne({ name: new RegExp(`^${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }); return d?._id ?? null; }

/** Executes a tool with the SAME services and scope as the REST API. */
export async function runTool(name, args, user) {
  const ctx = ctxFrom(await getSettings());
  const from = isDateStr(args.from) ? args.from : addDays(ctx.today, -29); const to = isDateStr(args.to) ? args.to : ctx.today;
  const dept = await deptId(args.department); if (dept === null) return { error: 'unknown_department' };
  switch (name) {
    case 'get_headcount': return isStaff(user) ? { headcount: await headcountAt(ctx.today, dept), date: ctx.today } : deny('Company headcount is only available to Admin and HR.');
    case 'get_attendance_summary': {
      if (isStaff(user)) { const s = await att.summary({ from, to, department: dept }); const { employees, trend, ...rest } = s; return rest; }
      const emp = await ownEmployee(user); const s = await att.summary({ from, to, employeeIds: [String(emp._id)] }); const { employees, trend, byDepartment, ...rest } = s; return { scope: 'your own attendance', ...rest };
    }
    case 'get_late_comers': return isStaff(user) ? att.lateComers({ from, to, department: dept, limit: Math.min(Number(args.limit) || 5, 20) }) : deny('Late-comer lists are only available to Admin and HR.');
    case 'get_leave_summary': return isStaff(user) ? lv.leaveSummary({ from, to, department: dept }) : deny('Company leave summaries are only available to Admin and HR. Ask for your own balance instead.');
    case 'get_my_leave_balance': return { balances: await lv.myBalances(user) };
    case 'get_payroll_summary': {
      if (isStaff(user)) return pay.payrollSummary({ month: args.month });
      const emp = await ownEmployee(user); const slips = await pay.myPayslips(emp._id);
      return slips[0] ? { scope: 'your own latest finalized payslip', ...slips[0] } : { available: false, message: 'You have no finalized payslip yet.' };
    }
    case 'search_employees': {
      if (!isStaff(user)) return deny('Employee search is only available to Admin and HR. I can only share your own information.');
      const q = String(args.query || '').trim(); const f = dept ? { department: dept } : {};
      if (q) { const rx = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); f.$or = [{ firstName: rx }, { lastName: rx }, { code: rx }, { email: rx }]; }
      const rows = await Employee.find(f).limit(10).populate('department designation').lean();
      return { results: rows.map((e) => ({ code: e.code, name: employeeName(e), department: e.department?.name, designation: e.designation?.name, status: e.status })) };
    }
    default: return { error: 'unknown_tool' };
  }
}

async function llm(messages, tools) {
  if (!env.ai.apiKey || !env.ai.baseUrl || !env.ai.model) throw new HttpError(503, 'AI provider is not configured');
  const ctl = new AbortController(); const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(`${env.ai.baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST', signal: ctl.signal, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${env.ai.apiKey}` },
      body: JSON.stringify({ model: env.ai.model, messages, ...(tools ? { tools, tool_choice: 'auto' } : {}), temperature: 0.2 }),
    });
    if (!res.ok) throw new Error(`LLM HTTP ${res.status}`);
    return (await res.json()).choices?.[0]?.message;
  } finally { clearTimeout(timer); }
}
const _llm = { fn: llm }; export const setLlmForTests = (f) => { _llm.fn = f ?? llm; };

async function quota(user) {
  const since = new Date(Date.now() - 3600000);
  if ((await AiLog.countDocuments({ user: user._id, createdAt: { $gte: since } })) >= HOURLY_LIMIT) throw new HttpError(429, `AI limit reached (${HOURLY_LIMIT} requests per hour). Try again later.`);
}
const logAi = (user, kind, prompt, tools, status, error, t0) => AiLog.create({ user: user._id, role: user.role, kind, prompt: String(prompt).slice(0, 500), tools, status, error, ms: Date.now() - t0 }).catch(() => {});

export async function policyText() {
  const s = await getSettings();
  return [
    `Office starts at ${s.officeStart}; grace period ${s.graceMinutes} minutes (check-in after that is late).`,
    'Working time under 5 hours counts as a half day. A record with no check-out is "missing checkout".',
    `Weekends: day numbers ${s.weekendDays.join(', ')} (0=Sunday). Public holidays are configured by Admin.`,
    'Leave quotas per year: ' + s.leaveTypes.map((t) => `${t.name} ${t.quota ?? 'unlimited'}`).join(', ') + '.',
    'Gross salary = 1.5 x basic; HRA = 40% of basic; medical = 10% of basic. Deductions for absent days, unpaid leave and half-days (0.5). HR drafts payroll; only Admin finalizes it.',
  ].join('\n');
}

export async function chat(user, message) {
  await quota(user); const t0 = Date.now(); const used = [];
  const ctx = ctxFrom(await getSettings());
  const system = `You are Ladoo's HR assistant. Today is ${ctx.today}. The signed-in user is ${user.name} (role: ${user.role}).
Rules: use tools for any data question and answer ONLY from tool results; never guess numbers. If a tool returns a forbidden error, politely refuse and explain. Never reveal another person's salary to an Employee. You cannot approve, create or change any record. For policy questions use only this policy, otherwise say the information is unavailable:\n${await policyText()}`;
  const msgs = [{ role: 'system', content: system }, { role: 'user', content: String(message).slice(0, 1000) }];
  try {
    for (let round = 0; round < 4; round++) {
      const m = await _llm.fn(msgs, TOOL_DEFS);
      if (!m) throw new Error('empty response');
      if (m.tool_calls?.length) {
        msgs.push(m);
        for (const tc of m.tool_calls.slice(0, 3)) {
          let args = {}; try { args = JSON.parse(tc.function.arguments || '{}'); } catch { /* ignore */ }
          used.push(tc.function.name);
          const result = await runTool(tc.function.name, args, user).catch((e) => ({ error: e.message }));
          msgs.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(result) });
        }
        continue;
      }
      await logAi(user, 'chat', message, used, 'ok', undefined, t0);
      return { answer: m.content, aiGenerated: true, toolsUsed: used };
    }
    throw new Error('too many tool rounds');
  } catch (e) {
    const timeout = e?.name === 'AbortError';
    await logAi(user, 'chat', message, used, timeout ? 'timeout' : 'error', e.message, t0);
    return { answer: timeout ? 'The AI assistant took too long to respond. Please try again, or use the dashboards for this information.' : 'The AI assistant is temporarily unavailable. Please use the dashboards or try again shortly.', fallback: true, aiGenerated: false, toolsUsed: used };
  }
}

async function jsonCall(system, user, schema) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const m = await _llm.fn([{ role: 'system', content: system }, { role: 'user', content: user }]);
    try { const raw = (m?.content || '').replace(/```json|```/g, '').trim(); const r = schema.safeParse(JSON.parse(raw)); if (r.success) return r.data; } catch { /* retry */ }
  }
  return null;
}

export async function smartLeave(user, text) {
  await quota(user); const t0 = Date.now();
  const s = await getSettings(); const ctx = ctxFrom(s); const keys = s.leaveTypes.map((t) => t.key);
  const wd = new Date(`${ctx.today}T00:00:00Z`).toLocaleDateString('en-US', { weekday: 'long', timeZone: 'UTC' });
  const schema = z.object({ type: z.enum(keys), start: z.string().refine(isDateStr), end: z.string().refine(isDateStr), reason: z.string().max(300) }).refine((v) => v.end >= v.start);
  try {
    const out = await jsonCall(`Convert the employee's leave request into JSON ONLY with keys type, start, end, reason. type must be one of ${keys.join(', ')}. Dates are ISO YYYY-MM-DD. Today is ${ctx.today} (${wd}). "Next Monday" means the first Monday after today. Output no prose.`, String(text).slice(0, 500), schema);
    await logAi(user, 'smart_leave', text, [], out ? 'ok' : 'invalid', undefined, t0);
    if (!out) throw new HttpError(422, 'Could not understand the request. Please fill in the leave form manually.');
    return { prefill: out, note: 'Review the details and confirm. Nothing has been submitted.', aiGenerated: true };
  } catch (e) {
    if (e instanceof HttpError) throw e;
    await logAi(user, 'smart_leave', text, [], 'error', e.message, t0);
    throw new HttpError(503, 'AI is unavailable right now. Please fill in the leave form manually.');
  }
}

export async function summarizeDashboard(user, filters) {
  await quota(user); const t0 = Date.now();
  const kpis = user.role === 'admin' ? await adminDashboard(filters) : await hrDashboard(filters);
  delete kpis.audit; // keep the model input to KPI numbers only
  const schema = z.object({ bullets: z.array(z.string().min(3).max(300)).min(3).max(5) });
  try {
    const out = await jsonCall('You write 3 to 5 short insight bullets for an HR dashboard. Use ONLY the numbers in the supplied JSON. Do not infer trends over time, causes or anything not present. If data is empty, say so. Respond with JSON ONLY: {"bullets":["..."]}.', JSON.stringify(kpis), schema);
    await logAi(user, 'summary', JSON.stringify(filters), [], out ? 'ok' : 'invalid', undefined, t0);
    if (!out) return { bullets: [], fallback: true, message: 'The AI returned an unusable response. The dashboard figures above remain accurate.' };
    return { bullets: out.bullets, aiGenerated: true };
  } catch (e) {
    await logAi(user, 'summary', JSON.stringify(filters), [], e?.name === 'AbortError' ? 'timeout' : 'error', e.message, t0);
    return { bullets: [], fallback: true, message: 'AI summary is unavailable right now. The dashboard figures above remain accurate.' };
  }
}

import { Employee, AuditLog, Announcement, LeaveRequest, Correction, PayrollRun, Attendance } from '../models/index.js';
import { getSettings, ctxFrom, ownEmployee, employeeName, cleanDept, rangeOrThrow } from './common.js';
import * as att from './attendance.js';
import * as lv from './leave.js';
import { myPayslips } from './payroll.js';
import { attritionRate } from '../core/analytics.js';
import { addDays, weekdayOf } from '../core/dates.js';
import { workedMinutes } from '../core/attendance.js';

/** Active + probation employees on `date`. */
export const headcountAt = async (date, department) => {
  const f = { joiningDate: { $lte: date }, $or: [{ exitDate: null }, { exitDate: { $exists: false } }, { exitDate: { $gt: date } }] };
  if (department) f.department = department;
  return Employee.countDocuments(f);
};

const range = (q, ctx) => ({ ...rangeOrThrow(q.from, q.to, { today: ctx.today, defaultFrom: `${ctx.today.slice(0, 4)}-01-01` }), department: cleanDept(q.department) });

export async function adminDashboard(q) {
  const ctx = ctxFrom(await getSettings()); const { from, to, department } = range(q, ctx);
  const deptF = department ? { department } : {};
  const [start, end, exits] = await Promise.all([headcountAt(addDays(from, -1), department), headcountAt(to, department), Employee.countDocuments({ ...deptF, exitDate: { $gte: from, $lte: to } })]);
  const emps = await Employee.find({ ...deptF, joiningDate: { $lte: to }, $or: [{ exitDate: null }, { exitDate: { $exists: false } }, { exitDate: { $gt: to } }] }).populate('department designation').lean();
  const byDeptHead = {}, salByDept = {}, gender = { male: 0, female: 0, other: 0, unknown: 0 }, tenure = { '<1y': 0, '1-3y': 0, '3-5y': 0, '5y+': 0 };
  for (const e of emps) {
    const d = e.department?.name || 'Unassigned';
    byDeptHead[d] = (byDeptHead[d] || 0) + 1; (salByDept[d] ||= []).push(e.basicSalary * 1.5);
    gender[e.gender || 'unknown']++;
    const yrs = (new Date(to) - new Date(e.joiningDate)) / 31557600000;
    tenure[yrs < 1 ? '<1y' : yrs < 3 ? '1-3y' : yrs < 5 ? '3-5y' : '5y+']++;
  }
  const runs = await PayrollRun.find({ status: 'finalized' }).sort({ month: 1 }).lean();
  const latest = runs[runs.length - 1];
  const costByDept = {};
  if (latest) for (const i of latest.items) if (!department || emps.some((e) => String(e._id) === String(i.employee))) { const d = i.department || 'Unassigned'; costByDept[d] = (costByDept[d] || 0) + i.earnedGross; }
  const allGross = emps.map((e) => e.basicSalary * 1.5);
  return {
    filters: { from, to, department }, headcount: end,
    attritionYtd: { exits, rate: attritionRate({ exits, startHeadcount: start, endHeadcount: end }) },
    payrollCost: latest ? { month: latest.month, gross: latest.totals.gross, net: latest.totals.net } : null,
    payrollTrend: runs.map((r) => ({ month: r.month, gross: r.totals.gross, net: r.totals.net })),
    averageGrossSalary: allGross.length ? Math.round(allGross.reduce((a, b) => a + b, 0) / allGross.length) : 0,
    headcountByDepartment: Object.entries(byDeptHead).map(([department, count]) => ({ department, count })),
    payrollCostByDepartment: Object.entries(costByDept).map(([department, gross]) => ({ department, gross: Math.round(gross) })),
    averageGrossByDepartment: Object.entries(salByDept).map(([department, v]) => ({ department, average: Math.round(v.reduce((a, b) => a + b, 0) / v.length) })),
    gender, tenure,
    audit: await AuditLog.find().sort({ createdAt: -1 }).limit(10).lean(),
  };
}

export async function hrDashboard(q) {
  const ctx = ctxFrom(await getSettings());
  const f = q.from ? range(q, ctx) : { from: addDays(ctx.today, -29), to: ctx.today, department: cleanDept(q.department) };
  const [headcount, todayBoard, summary, leaves, late, pendingLeave, pendingCorr] = await Promise.all([
    headcountAt(ctx.today, f.department), att.board(ctx.today, f.department), att.summary(f), lv.leaveSummary(f), att.lateComers({ ...f, limit: 5 }),
    LeaveRequest.countDocuments({ status: 'pending' }), Correction.countDocuments({ status: 'pending' }),
  ]);
  const c = (s) => todayBoard.filter((b) => b.status === s).length;
  return {
    filters: f, headcount,
    today: { present: c('present') + c('late') + c('half_day') + c('missing_checkout'), onLeave: c('on_leave'), late: c('late'), absentSoFar: c('absent') },
    pendingApprovals: { leave: pendingLeave, corrections: pendingCorr, total: pendingLeave + pendingCorr },
    attendanceRate: summary.attendanceRate, latePercentage: summary.latePercentage, absenteeismRate: summary.absenteeismRate,
    attendanceTrend: summary.trend, absenteeismByDepartment: summary.byDepartment.map((d) => ({ department: d.department, absenteeismRate: d.absenteeismRate })),
    leaveByType: leaves.byType.map((t) => ({ type: t.name, approvedDays: t.approvedDays, utilization: t.utilization })),
    topLateComers: late,
  };
}

export async function employeeDashboard(user) {
  const s = await getSettings(); const ctx = ctxFrom(s); const emp = await ownEmployee(user);
  const monday = addDays(ctx.today, -((weekdayOf(ctx.today) + 6) % 7));
  const [recs, month, balances, slips, announcements] = await Promise.all([
    Attendance.find({ employee: emp._id, date: { $gte: monday, $lte: ctx.today } }).lean(),
    att.myMonth(user, `${ctx.today.slice(0, 7)}-01`, ctx.today),
    lv.balances(emp._id, ctx.today.slice(0, 4), s), myPayslips(emp._id),
    Announcement.find().sort({ createdAt: -1 }).limit(5).lean(),
  ]);
  const today = month.days.find((d) => d.date === ctx.today);
  return {
    employee: { name: employeeName(emp), code: emp.code }, today: today || null, todayDate: ctx.today,
    hoursThisWeek: Math.round((recs.reduce((a, r) => a + workedMinutes(r), 0) / 60) * 10) / 10, weeklyTargetHours: 40,
    lateCountThisMonth: month.summary.late, leaveBalances: balances, lastPayslip: slips[0] || null, announcements,
  };
}

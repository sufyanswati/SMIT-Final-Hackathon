import { Attendance, Correction, Employee, User } from '../models/index.js';
import { HttpError } from '../middleware/http.js';
import { clock, getSettings, ctxFrom, ownEmployee, audit, notify, employeeName } from './common.js';
import { buildDays, employedBetween } from './days.js';
import { deriveStatus, workedMinutes } from '../core/attendance.js';
import { decideProof } from '../core/geo.js';
import { zonedToUtc, isDateStr, isWorkingDay } from '../core/dates.js';
import { tally, attendanceRate, latePercentage, absenteeismRate } from '../core/analytics.js';

function checkProof(settings, body) {
  const d = decideProof({ requireLocation: settings.requireLocation, office: settings.office?.toObject?.() ?? settings.office, body });
  if (d.error) throw new HttpError(d.error.status, d.error.message);
  return d;
}

export async function checkIn(user, body) {
  const emp = await ownEmployee(user);
  if (emp.status === 'exited') throw new HttpError(403, 'Exited employees cannot check in');
  const s = await getSettings(); const ctx = ctxFrom(s);
  const { days } = await buildDays([emp], ctx.today, ctx.today, ctx);
  if (days.get(String(emp._id))[0].status === 'on_leave') throw new HttpError(422, 'You are on approved leave today');
  const proof = checkProof(s, body);
  try {
    const rec = await Attendance.create({ employee: emp._id, date: ctx.today, checkIn: clock.now(), ...proof });
    return view(rec, ctx);
  } catch (e) {
    if (e?.code === 11000) throw new HttpError(409, 'You have already checked in today');
    throw e;
  }
}

export async function checkOut(user, body) {
  const emp = await ownEmployee(user);
  const s = await getSettings(); const ctx = ctxFrom(s);
  const rec = await Attendance.findOne({ employee: emp._id, date: ctx.today });
  if (!rec) throw new HttpError(422, 'You have not checked in today');
  if (rec.checkOut) throw new HttpError(409, 'You have already checked out today');
  checkProof(s, body);
  const upd = await Attendance.findOneAndUpdate({ _id: rec._id, checkOut: null }, { checkOut: clock.now() }, { new: true });
  if (!upd) throw new HttpError(409, 'You have already checked out today');
  return view(upd, ctx);
}

const view = (rec, ctx) => ({ date: rec.date, checkIn: rec.checkIn, checkOut: rec.checkOut, source: rec.source, workedMinutes: workedMinutes(rec), status: deriveStatus(rec, ctx.opts, rec.date < ctx.today) });

export async function myMonth(user, from, to) {
  const emp = await ownEmployee(user);
  const ctx = ctxFrom(await getSettings());
  const { days } = await buildDays([emp], from, to, ctx);
  const list = days.get(String(emp._id)).map((d) => ({ date: d.date, status: d.status, checkIn: d.record?.checkIn, checkOut: d.record?.checkOut, workedMinutes: workedMinutes(d.record) }));
  return { days: list, summary: tally(list.map((d) => d.status)), today: ctx.today };
}

export async function board(date, departmentId) {
  const ctx = ctxFrom(await getSettings());
  const emps = await employedBetween(Employee, date, date, departmentId).populate('department designation');
  const { days } = await buildDays(emps, date, date, ctx);
  return emps.map((e) => { const d = days.get(String(e._id))[0]; return { employee: e._id, code: e.code, name: employeeName(e), department: e.department?.name, status: d.status, checkIn: d.record?.checkIn, checkOut: d.record?.checkOut }; });
}

/** Aggregated attendance metrics for employees (all or one). */
export async function summary({ from, to, department, employeeIds }) {
  const ctx = ctxFrom(await getSettings());
  let emps = await employedBetween(Employee, from, to, department).populate('department');
  if (employeeIds) emps = emps.filter((e) => employeeIds.includes(String(e._id)));
  const { days } = await buildDays(emps, from, to, ctx);
  const overall = []; const byDept = {}; const perEmp = []; const trend = {};
  for (const e of emps) {
    const ds = days.get(String(e._id)); const st = ds.map((d) => d.status);
    overall.push(...st);
    const dn = e.department?.name || 'Unassigned';
    (byDept[dn] ||= []).push(...st);
    perEmp.push({ employee: e._id, code: e.code, name: employeeName(e), department: dn, ...tally(st) });
    for (const d of ds) (trend[d.date] ||= []).push(d.status);
  }
  const t = tally(overall);
  const expected = t.working - t.on_leave;
  return {
    from, to, totals: t,
    attendanceRate: attendanceRate(t), latePercentage: latePercentage(t), absenteeismRate: absenteeismRate({ absent: t.absent, expected }),
    byDepartment: Object.entries(byDept).map(([name, st]) => { const x = tally(st); return { department: name, ...x, absenteeismRate: absenteeismRate({ absent: x.absent, expected: x.working - x.on_leave }), attendanceRate: attendanceRate(x) }; }),
    trend: Object.entries(trend).map(([date, st]) => ({ date, ...(() => { const x = tally(st); return { attendanceRate: attendanceRate(x), present: x.present + x.late, absent: x.absent }; })() })).filter((r) => r.present || r.absent),
    employees: perEmp,
  };
}

export const lateComers = async ({ from, to, department, limit = 5 }) => {
  const s = await summary({ from, to, department });
  return s.employees.filter((e) => e.late > 0).sort((a, b) => b.late - a.late).slice(0, limit).map(({ code, name, department: d, late }) => ({ code, name, department: d, lateCount: late }));
};

// ---- corrections ----
export async function requestCorrection(user, { date, checkIn, checkOut, reason }) {
  const emp = await ownEmployee(user); const ctx = ctxFrom(await getSettings());
  if (!isDateStr(date) || date > ctx.today) throw new HttpError(422, 'Corrections can only be requested for today or past dates');
  if (!isWorkingDay(date, ctx.weekendDays, ctx.holidays)) throw new HttpError(422, 'That date is not a working day');
  if (checkOut && checkOut <= checkIn) throw new HttpError(422, 'Check-out must be after check-in');
  try { return await Correction.create({ employee: emp._id, date, checkIn, checkOut, reason }); }
  catch (e) { if (e?.code === 11000) throw new HttpError(409, 'A pending correction already exists for this date'); throw e; }
}

export async function decideCorrection(user, id, { approve, comment }) {
  const c = await Correction.findOneAndUpdate({ _id: id, status: 'pending' }, { status: approve ? 'approved' : 'rejected', decidedBy: user._id, comment, decidedAt: clock.now() }, { new: true });
  if (!c) throw new HttpError(409, 'Correction not found or already decided');
  const emp = await Employee.findById(c.employee);
  if (approve) {
    const ctx = ctxFrom(await getSettings());
    const existing = await Attendance.findOne({ employee: c.employee, date: c.date });
    const ci = zonedToUtc(c.date, c.checkIn, ctx.tz); const co = c.checkOut ? zonedToUtc(c.date, c.checkOut, ctx.tz) : undefined;
    const before = existing ? { checkIn: existing.checkIn, checkOut: existing.checkOut } : null;
    if (existing) {
      if (!existing.original?.checkIn) existing.original = { checkIn: existing.checkIn, checkOut: existing.checkOut }; // keep first originals
      existing.checkIn = ci; existing.checkOut = co; existing.source = 'correction'; await existing.save();
    } else await Attendance.create({ employee: c.employee, date: c.date, checkIn: ci, checkOut: co, source: 'correction' });
    await audit(user, 'attendance.correction.approve', 'Attendance', `${c.employee}|${c.date}`, before, { checkIn: ci, checkOut: co, correction: c._id });
  } else await audit(user, 'attendance.correction.reject', 'Correction', c._id, { status: 'pending' }, { status: 'rejected', comment });
  const u = emp?.user && (await User.findById(emp.user));
  if (u) await notify(u._id, `Your attendance correction for ${c.date} was ${approve ? 'approved' : 'rejected'}${comment ? `: ${comment}` : ''}`, 'attendance');
  return c;
}

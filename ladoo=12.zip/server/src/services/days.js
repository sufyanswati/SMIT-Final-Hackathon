import { Attendance, LeaveRequest } from '../models/index.js';
import { eachDate } from '../core/dates.js';
import { dayStatus } from '../core/attendance.js';
import { leaveDateSet } from '../core/leave.js';

/**
 * Single source of truth for per-day status. Used by attendance views, payroll, dashboards and AI tools.
 * Returns Map(employeeId -> [{ date, status, record }]).
 */
export async function buildDays(employees, from, to, ctx) {
  const ids = employees.map((e) => e._id);
  const [records, leaves] = await Promise.all([
    Attendance.find({ employee: { $in: ids }, date: { $gte: from, $lte: to } }).lean(),
    LeaveRequest.find({ employee: { $in: ids }, status: 'approved', start: { $lte: to }, end: { $gte: from } }).lean(),
  ]);
  const recBy = new Map(records.map((r) => [`${r.employee}|${r.date}`, r]));
  const leaveBy = new Map();
  for (const l of leaves) { const k = String(l.employee); (leaveBy.get(k) || leaveBy.set(k, []).get(k)).push(l); }
  const out = new Map();
  for (const e of employees) {
    const leaveDates = leaveDateSet(leaveBy.get(String(e._id)) || [], ctx.weekendDays, ctx.holidays);
    const days = [];
    for (const date of eachDate(from, to)) {
      const record = recBy.get(`${e._id}|${date}`);
      days.push({ date, record, status: dayStatus({ date, today: ctx.today, weekendDays: ctx.weekendDays, holidays: ctx.holidays, leaveDates, record, opts: ctx.opts, joiningDate: e.joiningDate, exitDate: e.exitDate }) });
    }
    out.set(String(e._id), days);
  }
  return { days: out, leaves };
}

/** Employees employed at any point in [from, to], optionally filtered by department. */
export const employedBetween = (Employee, from, to, department) => {
  const q = { joiningDate: { $lte: to }, $or: [{ exitDate: null }, { exitDate: { $exists: false } }, { exitDate: { $gte: from } }] };
  if (department) q.department = department;
  return Employee.find(q);
};

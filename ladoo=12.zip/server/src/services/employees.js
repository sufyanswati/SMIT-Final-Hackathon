import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { Employee, User, Department, Designation } from '../models/index.js';
import { HttpError } from '../middleware/http.js';
import { audit, employeeName, pageParams, cleanDept } from './common.js';
import { parseCsv, toCsv } from '../core/csv.js';
import { isDateStr } from '../core/dates.js';
import { salaryStructure } from '../core/payroll.js';

export const tempPassword = () => crypto.randomBytes(9).toString('base64url') + '#7';
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function listEmployees(q) {
  const { page, limit, skip } = pageParams(q);
  const f = {};
  if (q.department) f.department = cleanDept(q.department);
  if (q.status) f.status = q.status;
  if (q.q) { const rx = new RegExp(String(q.q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i'); f.$or = [{ firstName: rx }, { lastName: rx }, { code: rx }, { email: rx }]; }
  const sortKey = ['firstName', 'code', 'joiningDate', 'createdAt'].includes(q.sort) ? q.sort : 'createdAt';
  const [items, total] = await Promise.all([
    Employee.find(f).sort({ [sortKey]: q.order === 'desc' ? -1 : 1 }).skip(skip).limit(limit).populate('department designation').lean(),
    Employee.countDocuments(f),
  ]);
  return { items, total, page, pages: Math.ceil(total / limit) };
}

async function resolveDept(name) { return Department.findOne({ name: new RegExp(`^${String(name).trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }); }

export async function registerEmployee(actor, d) {
  if (!(await Department.exists({ _id: d.department }))) throw new HttpError(422, 'Unknown department');
  if (d.designation && !(await Designation.exists({ _id: d.designation }))) throw new HttpError(422, 'Unknown designation');
  const temp = tempPassword();
  let user, emp;
  try {
    user = await User.create({ name: `${d.firstName} ${d.lastName}`, email: d.email, passwordHash: await bcrypt.hash(temp, 10), role: 'employee', mustChangePassword: true });
    emp = await Employee.create({ ...d, user: user._id });
    user.employee = emp._id; await user.save();
  } catch (e) {
    if (user && !emp) await User.deleteOne({ _id: user._id }); // roll back the login if employee creation failed
    throw e;
  }
  await audit(actor, 'employee.create', 'Employee', emp._id, null, { code: emp.code, email: emp.email });
  return { employee: emp, temporaryPassword: temp };
}

export async function updateEmployee(actor, id, patch) {
  const emp = await Employee.findById(id);
  if (!emp) throw new HttpError(404, 'Employee not found');
  const before = emp.toObject();
  Object.assign(emp, patch);
  await emp.save();
  if (patch.email || patch.firstName || patch.lastName) await User.updateOne({ _id: emp.user }, { email: emp.email, name: employeeName(emp) });
  await audit(actor, patch.basicSalary != null ? 'employee.salary.update' : 'employee.update', 'Employee', emp._id, pick(before, patch), pick(emp.toObject(), patch));
  return emp;
}
const pick = (o, p) => Object.fromEntries(Object.keys(p).map((k) => [k, o[k]]));

export const withSalary = (e) => ({ ...(e.toObject ? e.toObject() : e), salaryStructure: salaryStructure(e.basicSalary) });

/** Dry-run or commit CSV import. Columns: code,firstName,lastName,email,department,designation,joiningDate,basicSalary,gender,phone */
export async function importCsv(actor, text, dryRun) {
  const rows = parseCsv(text);
  if (!rows.length) throw new HttpError(422, 'CSV is empty or has no data rows');
  const errors = []; const valid = []; const seenCode = new Set(); const seenEmail = new Set();
  const depts = new Map((await Department.find()).map((d) => [d.name.toLowerCase(), d]));
  const desigs = new Map((await Designation.find()).map((d) => [d.name.toLowerCase(), d]));
  const [codes, emails] = await Promise.all([Employee.find({}, 'code').lean(), User.find({}, 'email').lean()]);
  const existingCodes = new Set(codes.map((c) => c.code)); const existingEmails = new Set(emails.map((e) => e.email));
  for (const r of rows) {
    const bad = (field, reason) => errors.push({ row: r.__row, field, reason });
    const n0 = errors.length;
    for (const f of ['code', 'firstName', 'lastName', 'email', 'department', 'joiningDate', 'basicSalary']) if (!r[f]) bad(f, 'Required');
    const email = (r.email || '').toLowerCase();
    if (r.email && !EMAIL_RE.test(r.email)) bad('email', 'Invalid email format');
    if (r.code && (existingCodes.has(r.code) || seenCode.has(r.code))) bad('code', 'Duplicate employee code');
    if (email && (existingEmails.has(email) || seenEmail.has(email))) bad('email', 'Duplicate email');
    const dept = r.department && depts.get(r.department.toLowerCase());
    if (r.department && !dept) bad('department', `Unknown department "${r.department}"`);
    if (r.joiningDate && !isDateStr(r.joiningDate)) bad('joiningDate', 'Must be an ISO date (YYYY-MM-DD)');
    const sal = Number(r.basicSalary);
    if (r.basicSalary && !(sal > 0)) bad('basicSalary', 'Must be a number greater than zero');
    if (r.designation && !desigs.get(r.designation.toLowerCase())) bad('designation', `Unknown designation "${r.designation}"`);
    if (errors.length === n0) { seenCode.add(r.code); seenEmail.add(email); valid.push({ r, dept, desig: desigs.get((r.designation || '').toLowerCase()), sal, email }); }
  }
  const result = { dryRun, totalRows: rows.length, validRows: valid.length, errors, created: [] };
  if (dryRun || errors.length) { if (!dryRun) result.message = 'Nothing was imported because some rows are invalid. Fix them or run a dry run first.'; return result; }
  for (const v of valid) {
    const { employee, temporaryPassword } = await registerEmployee(actor, { code: v.r.code, firstName: v.r.firstName, lastName: v.r.lastName, email: v.email, department: v.dept._id, designation: v.desig?._id, joiningDate: v.r.joiningDate, basicSalary: v.sal, gender: ['male', 'female', 'other'].includes(v.r.gender) ? v.r.gender : '', phone: v.r.phone });
    result.created.push({ code: employee.code, email: employee.email, temporaryPassword });
  }
  return result;
}

export async function exportCsv() {
  const emps = await Employee.find().populate('department designation').lean();
  const headers = ['code', 'firstName', 'lastName', 'email', 'department', 'designation', 'joiningDate', 'status', 'gender', 'phone'];
  return toCsv(headers, emps.map((e) => ({ ...e, department: e.department?.name, designation: e.designation?.name })));
}

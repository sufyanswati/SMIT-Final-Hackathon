import mongoose from 'mongoose';
import { env } from './config/env.js';
import { createApp } from './app.js';
import { isInitialized, initialize } from './services/setup.js';

await mongoose.connect(env.mongoUri);
// Create missing schema indexes without dropping any index that may be managed externally.
await mongoose.createIndexes();

// Optional non-interactive first-run: only if both env vars are set. There is no default password.
if (!(await isInitialized()) && env.adminEmail && env.adminPassword) {
  await initialize({ companyName: env.companyName, name: env.adminName, email: env.adminEmail.toLowerCase(), password: env.adminPassword });
  console.log('[setup] First Admin created from environment variables');
}

const server = createApp().listen(env.port, () => console.log(`Ladoo HCM API listening on :${env.port}`));

const shutdown = async (signal) => {
  console.log(`[shutdown] ${signal} received`);
  server.close(async () => { await mongoose.disconnect(); process.exit(0); });
  setTimeout(() => process.exit(1), 10000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
